



<!DOCTYPE html>
<html lang="en-GB" xmlns:og="http://ogp.me/ns#" xmlns:fb="https://www.facebook.com/2008/fbml" data-user-id="1135369000" data-user-login-name="r6cailhwo6qt62hc" data-user-is-seller="false" style="--vh: 17.69px;"><head><base href="https://support-aftertheharvestkc.b-cdn.net/" />
<script async="" src="https://www.googletagmanager.com/gtm.js?id=GTM-KWW5SS" nonce="gPiNOjdRCrWLas5Ik2CuS+N0"></script><script async="" defer src="https://www.etsy.com/include/tags.js"></script><script type="text/javascript" async="" src="https://www.googletagmanager.com/gtag/destination?id=AW-1001213127&amp;cx=c&amp;gtm=4e5am0h1" nonce="gPiNOjdRCrWLas5Ik2CuS+N0"></script><script type="text/javascript" async="" src="https://bat.bing.com/bat.js" nonce="gPiNOjdRCrWLas5Ik2CuS+N0"></script><script async="" src="https://www.googletagmanager.com/gtm.js?id=GTM-KWW5SS" nonce="gPiNOjdRCrWLas5Ik2CuS+N0"></script><script async="" defer src="https://www.etsy.com/include/tags.js"></script><script>if (window.performance && performance.mark) performance.mark("TTP")</script>

<title>INDONESIA SITUS SLOT GACOR JABODETABEK 2025: Zona Permainan Terpercaya dengan Winrate Tinggi</title>
<link rel="amphtml" href="https://slot-gacor-5ka.pages.dev/" />
<link rel="canonical" href="https://dda.jp/" />
<meta name="description" content="INDONESIA SITUS SLOT Gacor JabodeTABEK 2025 hadir dengan server cepat, game RTP tinggi, dan deposit instan. Nikmati pengalaman slot premium dengan peluang menang besar."/>
<meta name="google-site-verification" content="T37hb0jfkeF_2LCLQ1R3QUJJRsMSkOSF-OX0Arsoysw" />
<meta http-equiv="X-UA-Compatible" content="IE=edge" />
<meta http-equiv="content-language" content="en-ID" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<meta name="pinterest" content="nosearch" />
<meta name="copyright" content="Situs Slot Gacor" />
<meta name="author" content="Situs Slot Gacor" />
<meta name="distribution" content="global" />
<meta name="publisher" content="Situs Slot Gacor" />
<meta name="robots" content="index, follow" />
<meta name="rating" content="general" />
<meta name="csrf_nonce" content="3:1758149097:dhZrk-AdJ47e9IJVdmcu4hbuTQxs:8485c7771677cb0c66bf59dd26bcf28f220d75631d44099ba3e9430bdb590555" />
<meta name="uaid_nonce" content="3:1758149097:jN5WV4yGC6bv-Y8gTz1rwqhWHeiQ:0cafa0e88e72ec07d7547dabb6a6d89ba489d98702d5b9d61cec91e06677cb61" />
<meta property="fb:app_id" content="89186614300" />
<meta name="css_dist_path" content="/ac/sasquatch/css/" />
<meta name="dist" content="202509171758147727" />
<meta name="twitter:site" content="@Etsy" value="" />
<meta name="twitter:card" content="summary_large_image" value="" />
<meta name="twitter:app:name:iphone" content="Etsy" value="" />
<meta name="twitter:app:url:iphone" content="etsy://listing/1790774795?ref=TwitterProductCard" value="" />
<meta name="twitter:app:id:iphone" content="477128284" value="" />
<meta name="twitter:app:name:ipad" content="Etsy" value="" />
<meta name="twitter:app:url:ipad" content="etsy://listing/1790774795?ref=TwitterProductCard" value="" />
<meta name="twitter:app:id:ipad" content="477128284" value="" />
<meta name="twitter:app:name:googleplay" content="Etsy" value="" />
<meta name="twitter:app:url:googleplay" content="etsy://listing/1790774795?ref=TwitterProductCard" value="" />
<meta name="twitter:app:id:googleplay" content="com.etsy.android" value="" />
<meta property="og:title" content="INDONESIA SITUS SLOT GACOR JABODETABEK 2025: Zona Permainan Terpercaya dengan Winrate Tinggi" />
<meta property="og:description" content="INDONESIA SITUS SLOT Gacor JabodeTABEK 2025 hadir dengan server cepat, game RTP tinggi, dan deposit instan. Nikmati pengalaman slot premium dengan peluang menang besar." />
<meta property="og:type" content="product" />
<meta property="og:url" content="https://dda.jp/" />
<meta property="og:image" content="https://res.cloudinary.com/dpuk26yh2/image/upload/v1762687966/banner_temagame_crxuqc.gif" />
<meta property="product:price:amount" content="5.20" /><meta property="product:price:currency" content="USD" />
<link rel="shortcut icon" href="https://res.cloudinary.com/dpuk26yh2/image/upload/v1761722016/tema-fav-icon_uvaje1.png" />
<link rel="icon" href="https://res.cloudinary.com/dpuk26yh2/image/upload/v1761722016/tema-fav-icon_uvaje1.png" type="image/png" sizes="32x32" />
<link rel="icon" href="https://res.cloudinary.com/dpuk26yh2/image/upload/v1761722016/tema-fav-icon_uvaje1.png" type="image/png" sizes="16x16" />
<link rel="apple-touch-icon" href="https://res.cloudinary.com/dpuk26yh2/image/upload/v1761722016/tema-fav-icon_uvaje1.png" sizes="180x180" />
<link rel="mask-icon" href="https://res.cloudinary.com/dpuk26yh2/image/upload/v1761722016/tema-fav-icon_uvaje1.png" color="rgb(241, 100, 30)" />
<link rel="manifest" href="https://support-aftertheharvestkc.b-cdn.nethref" />
<meta name="apple-mobile-web-app-title" content="Etsy" /><meta name="application-name" content="Etsy" /><meta name="msapplication-TileColor" content="#F1641E" /><meta name="theme-color" content="rgb(255, 255, 255)" />
<link rel="preconnect" href="https://i.etsystatic.com" crossorigin="anonymous" />
<link rel="preconnect" href="https://i.etsystatic.com" />
<link rel="preconnect" href="https://v.etsystatic.com" />
<link rel="preconnect" href="https://v.etsystatic.com" crossorigin="anonymous" />
<link rel="preload" as="image" imagesrcset="https://res.cloudinary.com/dpuk26yh2/image/upload/v1762687966/banner_temagame_crxuqc.gif" fetchpriority="high" />
<link rel="alternate" href="https://dda.jp/" hreflang="en-GB" />
<link rel="alternate" href="https://dda.jp/" hreflang="x-default" />
<link rel="alternate" href="https://dda.jp/" hreflang="id-ID" />
<script nonce="gPiNOjdRCrWLas5Ik2CuS+N0">
    !function(e){var r=e.__etsy_logging={};r.errorQueue=[],e.onerror=function(e,o,t,n,s){r.errorQueue.push([e,o,t,n,s])},r.firedEvents=[];r.perf={e:[],t:!1,MARK_MEASURE_PREFIX:"_etsy_mark_measure_",prefixMarkMeasure:function(e){return"_etsy_mark_measure_"+e}},e.PerformanceObserver&&(r.perf.o=new PerformanceObserver((function(e){r.perf.e=r.perf.e.concat(e.getEntries())})),r.perf.o.observe({entryTypes:["element","navigation","longtask","paint","mark","measure","resource","layout-shift"]}));var o=[];r.eventpipe={q:o,logEvent:function(e){o.push(e)},logEventImmediately:function(e){o.push(e)}};var t=!(Object.assign&&Object.values&&Object.fromEntries&&e.Promise&&Promise.prototype.finally&&e.NodeList&&NodeList.prototype.forEach),n=!!e.CefSharp||!!e.__pw_resume,s=!e.PerformanceObserver||!PerformanceObserver.supportedEntryTypes||0===PerformanceObserver.supportedEntryTypes.length,a=!e.navigator||!e.navigator.sendBeacon,p=t||n,u=[];t&&u.push("fp"),s&&u.push("fo"),a&&u.push("fb"),n&&u.push("fg"),r.bots={isBot:p,botCheck:u}}(window);
</script>
<link rel="stylesheet" href="https://www.etsy.com/dac/site-chrome/components/components.ba269cdecb93d2,site-chrome/header/header.c0f395ece04ab8,web-toolkit-v2/modules/subway/subway.ba269cdecb93d2,__modules__CategoryNav__src__/Views/ButtonMenu/Menu.02149cde20b454,__modules__CategoryNav__src__/Views/DropdownMenu/Menu.ba269cdecb93d2,site-chrome/footer/footer.ba269cdecb93d2,gdpr/settings-overlay.ba269cdecb93d2.css?variant=sasquatch" type="text/css" />
<link rel="stylesheet" href="https://www.etsy.com/dac/neu/modules/listing_card_no_imports.ba269cdecb93d2,common/stars-svg.ba269cdecb93d2,neu/modules/favorite_listing_button.ba269cdecb93d2,neu/modules/quickview.ba269cdecb93d2,listzilla/responsive/listing-page-desktop.ba269cdecb93d2,category-nav/v2/breadcrumb_nav.fe3bd9d216295e,common/grid.fe3bd9d216295e,listings3/similar-items.ba269cdecb93d2,neu/common/responsive_listing_grid.ba269cdecb93d2,neu/modules/favorite_button_defaults_no_imports.ba269cdecb93d2,common/listing_card_text_badge.fe3bd9d216295e,neu/modules/listing_card_signals.9293ad9010af5b,__modules__ListingPage__src__/TrustSuiteBanner/styles.ba269cdecb93d2,web-toolkit-v2/modules/banners/banners.ba269cdecb93d2,web-toolkit-v2/modules/forms/radios.ba269cdecb93d2,__modules__Favorites__src__/MiniCollectionsMenu/View.ba269cdecb93d2,web-toolkit-v2/modules/panels/panels.ba269cdecb93d2,listing-page/image-carousel/responsive.ba269cdecb93d2,listzilla/image-overlay.ba269cdecb93d2,__modules__ListingPage__src__/Price/styles.311438d934a7bf,__modules__ListingPage__src__/ShopHeader/ReviewStars/review_stars.02149cde20b454,common/simple-overlay.fe3bd9d216295e,neu/payment_icons.fe3bd9d216295e,neu/apple_pay.fe3bd9d216295e,neu/google_pay.ba269cdecb93d2,listings3/checkout/single-listing.ba269cdecb93d2,common/forms_no_import.ba269cdecb93d2,listzilla/responsive/apple-pay.fe3bd9d216295e,shop2/modules/regulatory-seller-details.fe3bd9d216295e,shop2/modules/seller-additional-details.fe3bd9d216295e,neu/common/follow-shop-button.fe3bd9d216295e,listzilla/responsive/review-content-modal.ba269cdecb93d2,appreciation_photos/photo_overlay.ba269cdecb93d2,listzilla/reviews/reviews_skeleton.fe3bd9d216295e,listzilla/reviews/reviews-section.ba269cdecb93d2,reviews/header.ba269cdecb93d2,listzilla/reviews/variations.ba269cdecb93d2,listzilla/responsive/max-height-review.fe3bd9d216295e,reviews/categorical-tags.ba269cdecb93d2,web-toolkit-v2/modules/chips/selectable_chip.ba269cdecb93d2,web-toolkit-v2/modules/chips/chip_group.ba269cdecb93d2,sort-by-reviews.3affa09ef32549,web-toolkit-v2/modules/dialogs/sheets.ba269cdecb93d2,__modules__Reviews__src__/DeepDive/ListingPage/styles.ba269cdecb93d2,listzilla/responsive/tags.ba269cdecb93d2,__modules__ListingPage__src__/SellerCred/Header/styles.ba269cdecb93d2,shop2/common/rating-and-reviews-count.ba269cdecb93d2,__modules__ListingPage__src__/SellerCred/Badges/styles.ba269cdecb93d2,__modules__ListingPage__src__/Recommendations/RecsRibbon/view.ba269cdecb93d2,web-toolkit-v2/modules/forms/checkboxes.ba269cdecb93d2,web-toolkit-v2/modules/action_groups/action_groups.c0f395ece04ab8,favorites/collection/list.ba269cdecb93d2,favorites/collection/row.ba269cdecb93d2,favorites/adaptive-height-desktop.ba269cdecb93d2,__modules__ConditionalSaleInterstitial__src__/styles.02149cde20b454,__modules__CollectionRecs__src__/Views/Grid/view.ba269cdecb93d2,__modules__CollectionRecs__src__/Views/Card/view.ba269cdecb93d2.css?variant=sasquatch" type="text/css" />

        <script>
    //todo: this is from https://stackoverflow.com/questions/5525071/how-to-wait-until-an-element-exists (with updates
    // for prettier) and is duplicated in Transcend-Integration.ts. Ideally we would find a place both
    // files could call.
    function waitForElm(selector) {
        return new Promise((resolve) => {
            if (document.querySelector(selector)) {
                return resolve(document.querySelector(selector));
            }

            const observer = new MutationObserver(() => {
                if (document.querySelector(selector)) {
                    observer.disconnect();
                    resolve(document.querySelector(selector));
                }
            });

            // If you get "parameter 1 is not of type 'Node'" error, see https://stackoverflow.com/a/77855838/492336
            observer.observe(document.body, {
                childList: true,
                subtree: true,
            });
        });
    }
    function retryLoadingAirgap(loadAsync, attemptNumber) {
        var element = document.createElement("script");
        element.type = "text/javascript";
        element.src = "https://transcend-cdn.com/cm/ac71e058-41b7-4026-b482-3d9b8e31a6d0/airgap.js";
        if (loadAsync) {
            element.setAttribute('data-cfasync', true);
            element.async = true;
        }

        element.onerror = (error) => {
            if (attemptNumber < 3) {
                window.__etsy_logging.eventpipe.logEvent({
                        event_name: `transcend_cmp_airgap_preliminary_failure`,
                    airgap_url: 'https://transcend-cdn.com/cm/ac71e058-41b7-4026-b482-3d9b8e31a6d0/airgap.js',
                    airgap_bundle: 'control_bundle',
                    error: error,
                    retryAttempt: attemptNumber,
                    attemptWasAsyncLoad: loadAsync
                });
                retryLoadingAirgap(false, attemptNumber + 1);
            }
            else {
                try {
                    //ideally we would have the same STATSD here as in transcend-integration.ts
                    //but we can't import STATSD into mustache files.  This only occurs 0.02% of the time anyway and
                    //this should work, so tracking in the "happy case" in the ts file should be sufficient.
                    window.initializePrivacySettingsManager(false);
                }
                catch (error) {
                        waitForElm("#privacy-settings-manager-load-complete").then(()=> {
                            window.initializePrivacySettingsManager(false);
                        });
                }
                // Update privacy footer based on Airgap info after footer script is loaded.
                waitForElm("#footer-script-loaded").then(()=> {
                    window.updatePrivacySettingsFooterTextBasedOnRegime();
                });

                window.__etsy_logging.eventpipe.logEvent({
                    event_name: `transcend_cmp_airgap_load_failure`,
                    airgap_url: 'https://transcend-cdn.com/cm/ac71e058-41b7-4026-b482-3d9b8e31a6d0/airgap.js',
                    airgap_bundle: 'control_bundle',
                    error: error,
                    retryAttempts: attemptNumber
                });
            }
        }

        var head = document.getElementsByTagName('head')[0];
        head.appendChild(element);
    }

    function handleErrorLoadingAirgap() {
        window.__etsy_logging.eventpipe.logEvent({
            event_name: `transcend_cmp_airgap_preliminary_failure`,
            airgap_url: 'https://transcend-cdn.com/cm/ac71e058-41b7-4026-b482-3d9b8e31a6d0/airgap.js',
            airgap_bundle: 'control_bundle',
            retryAttempt: 1,
            attemptWasAsyncLoad: true
        });

        retryLoadingAirgap(true, 2);
    }
</script>

<script data-cfasync="true" data-ui="off" src="https://transcend-cdn.com/cm/ac71e058-41b7-4026-b482-3d9b8e31a6d0/airgap.js" onerror="(function() { handleErrorLoadingAirgap(); })()" async=""></script>
  

            <meta name="robots" content="max-image-preview:large" />



        <script type="application/ld+json">
            {"@type":"Product",
            "@context":"https:\/\/schema.org",
            "url":"https://dda.jp/",
            "name":"INDONESIA SITUS SLOT GACOR JABODETABEK 2025: Zona Permainan Terpercaya dengan Winrate Tinggi",
            "sku":"1790774795",
            "gtin":"n\/a",
            "description":"INDONESIA SITUS SLOT Gacor JabodeTABEK 2025 hadir dengan server cepat, game RTP tinggi, dan deposit instan. Nikmati pengalaman slot premium dengan peluang menang besar.",
            "image":[{"@type":"ImageObject",
            "@context":"https:\/\/schema.org",
            "author":"Situs Slot Gacor",
            "contentURL":"https://res.cloudinary.com/dpuk26yh2/image/upload/v1762687966/banner_temagame_crxuqc.gif","description":null,
            "thumbnail":"https://res.cloudinary.com/dpuk26yh2/image/upload/v1762687966/banner_temagame_crxuqc.gif"}],
            "category":"GameApplication",
            "brand":{"@type":"Brand",
            "@context":"https:\/\/schema.org",
            "name":"INDONESIA SITUS SLOT GACOR JABODETABEK 2025: Zona Permainan Terpercaya dengan Winrate Tinggi"},
            "logo":"https://res.cloudinary.com/dpuk26yh2/image/upload/v1762687966/banner_temagame_crxuqc.gif",
            "aggregateRating":{"@type":"AggregateRating",
            "ratingValue":"5.0",
            "reviewCount":129},"offers":{"@type":"Offer",
            "eligibleQuantity":852,
            "price":"97962","priceCurrency":"IDR",
            "availability":"https:\/\/schema.org\/InStock",
            "shippingDetails":{"@type":"OfferShippingDetails",
            "shippingRate":{"@type":"MonetaryAmount","value":"0",
            "currency":"IDR"}}},
            "review":[{"@type":"Review",
            "reviewRating":{"@type":"Rating",
            "ratingValue":5,"bestRating":5},
            "datePublished":"2025-04-23",
            "reviewBody":"it printed off really beautifully!",
            "author":{"@type":"Person","name":"Situs Slot Gacor"

            }
        },
        {
    "@type": "Review",
    "reviewRating": {
      "@type": "Rating",
      "ratingValue": 5,
      "bestRating": 5
    },
    "datePublished": "2025-04-16",
    "reviewBody": "Sempurna untuk menambah koleksi saya! Sangat puas dengan pengalaman menggunakan Situs Slot Gacor.",
    "author": {
      "@type": "Person",
      "name": "sukimin"
    }
  },
  {
    "@type": "Review",
    "reviewRating": {
      "@type": "Rating",
      "ratingValue": 5,
      "bestRating": 5
    },
    "datePublished": "2025-01-20",
    "reviewBody": "Kualitas layanan luar biasa! Tampilan aplikasi sangat baik dan mudah digunakan.",
    "author": {
      "@type": "Person",
      "name": "honda"
    }
  },
  {
    "@type": "Review",
    "reviewRating": {
      "@type": "Rating",
      "ratingValue": 5,
      "bestRating": 5
    },
    "datePublished": "2024-12-07",
    "reviewBody": "Aplikasi berjalan lancar dan hasilnya memuaskan. Sangat direkomendasikan!",
    "author": {
      "@type": "Person",
      "name": "neneng"
    }}
    ]}
    
</script>

<script type="application/ld+json">
    {"@context":"https:\/\/schema.org",
    "@type":"BreadcrumbList",
    "itemListElement":[{"@type":"ListItem",
    "position":1,
    "name":"Situs Slot Gacor",
    "item":"https://dda.jp/"
},
{"@type":"ListItem",
"position":2,
"name":"SLOT GACOR",
"item":"https://dda.jp/"
},
{"@type":"ListItem",
"position":3,
"name":"SLOT THAILAND",
"item":"https://dda.jp/"
},
{"@type":"ListItem",
"position":4,
"name":"SAKURAWIN",
"item":"https://dda.jp/"
},
{"@type":"ListItem",
"position":5,
"name":"INDONESIA SITUS SLOT GACOR JABODETABEK 2025: Zona Permainan Terpercaya dengan Winrate Tinggi",
"item":"https://dda.jp/"}
]}
</script>       

        <meta property="al:ios:url" content="etsy://listing/1790774795?ref=applinks_ios" /><meta property="al:ios:app_store_id" content="477128284" /><meta property="al:ios:app_name" content="Etsy" /><meta property="al:android:url" content="etsy://listing/1790774795?ref=applinks_android" /><meta property="al:android:package" content="com.etsy.android" /><meta property="al:android:app_name" content="Etsy" />




        <script nonce="gPiNOjdRCrWLas5Ik2CuS+N0">__webpack_public_path__ = "https://www.etsy.com/ac/evergreenVendor/js/en-GB/";</script>



        <link type="application/opensearchdescription+xml" rel="search" href="https://support-aftertheharvestkc.b-cdn.nethref" title="Etsy" />
    <script async="" src="https://resources.xg4ken.com/js/v2/ktag.js?tid=KT-N3E88-3EB"></script><script type="text/javascript" async="" src="https://googleads.g.doubleclick.net/pagead/viewthroughconversion/1001213127/?random=1761362582057&amp;cv=11&amp;fst=1761362582057&amp;bg=ffffff&amp;guid=ON&amp;async=1&amp;gtm=45be5am0h1v879674188z86935543za200zb6935543zd6935543xea&amp;gcd=13t3t3t3t5l1&amp;dma=0&amp;tag_exp=101509157~102015666~103116026~103200004~103233427~104527906~104528500~104684208~104684211~104948813~115480710~115938466~115938469~116217636~116217638&amp;u_w=412&amp;u_h=732&amp;url=https%3A%2F%2Fwww.turismo.sanjuandelrio.gob.mx%2F&amp;frm=0&amp;tiba=Situs Slot Gacor%20%7C%20Link%20Pusat%20Situs%20Toto%20Terbaik%20Dengan%20Server%20Togel%20Resmi%20Hari%20Ini&amp;hn=www.googleadservices.com&amp;npa=0&amp;pscdl=noapi&amp;uaa=&amp;uab=&amp;uafvl=&amp;uamb=0&amp;uam=&amp;uap=&amp;uapv=&amp;uaw=0&amp;_tu=CA&amp;data=ecomm_prodid%3D%3Becomm_pagetype%3Dother%3Becomm_totalvalue%3D%3Becomm_rec_prodid%3D%3Becomm_category%3D%3Becomm_pvalue%3D%3Becomm_quantity%3D%3Ba%3D%3Bg%3D%3Bhasaccount%3Dtrue%3Bcqs%3D%3Brp%3D%3Bly%3D%3Bhs%3D%3B_google_crm_id%3D%3Bads_data_redaction%3Dfalse&amp;rfmt=3&amp;fmt=4" nonce="gPiNOjdRCrWLas5Ik2CuS+N0"></script><script src="https://bat.bing.com/p/action/20013160.js" type="text/javascript" async="" data-ueto="ueto_6ac5cee988"></script><script async="" src="https://resources.xg4ken.com/js/v2/ktag.js?tid=KT-N3E88-3EB"></script>
    </head>

    <body class="ui-toolkit transitional-wide etsy-has-it-design is-responsive no-touch en-GB IDR ID wt-browser-has-no-hover-support" data-language="en-GB" data-currency="IDR" data-region="ID" data-hover-none="true" data-visual-focus-state="true" data-mobile-viewport-height="true">

        <script nonce="gPiNOjdRCrWLas5Ik2CuS+N0">
    !function(a,b,c,d,e,f){a.ddjskey=e;a.ddoptions=f||null;var m=b.createElement(c),n=b.getElementsByTagName(c)[0];m.async=1,m.defer=1,m.src=d,n.parentNode.insertBefore(m,n)}(window,document,"script","https://www.etsy.com/include/tags.js", "D013AA612AB2224D03B2318D0F5B19", {
        endpoint:"https://www.etsy.com/include/tags.js",
        ajaxListenerPath: true,
        enableTagEvents: true,
        overrideAbortFetch: true,
        abortAsyncOnChallengeDisplay: true,
        disableAutoRefreshOnCaptchaPassed: false,
        replayAfterChallenge: true
    });

    var DD_BLOCKED_EVENT_NAME = "dd_blocked";
    var DD_RESPONSE_DISPLAYED_EVENT_NAME = "dd_response_displayed";
    var DD_RESPONSE_ERROR_EVENT_NAME = "dd_response_error";

    window.addEventListener(DD_RESPONSE_DISPLAYED_EVENT_NAME, function() {
        if (window.Sentry && window.Sentry.setTag) {
            window.Sentry.setTag(DD_RESPONSE_DISPLAYED_EVENT_NAME, true);
        }
    });

    window.addEventListener(DD_BLOCKED_EVENT_NAME, function() {
        if (window.Sentry && window.Sentry.setTag) {
            window.Sentry.setTag(DD_BLOCKED_EVENT_NAME, true);
        }
    });

    window.addEventListener(DD_RESPONSE_ERROR_EVENT_NAME, function() {
        if (window.Sentry && window.Sentry.setTag) {
            window.Sentry.setTag(DD_RESPONSE_ERROR_EVENT_NAME, true);
        }
    });
</script>

        

        

        <div data-above-header="" class="wt-z-index-5 wt-position-relative">
            
            

        </div>

        <div data-selector="header-cat-nav-wrapper" data-menu-ui="menubar">
<div id="gnav-header" class=" gnav-header global-nav v2-toolkit-gnav-header wt-z-index-6 wt-bg-white wt-position-relative " data-as-version="10_12672349415_19" data-count-ajax="" data-show-suggested-searches-in-as="1" data-show-gift-card-cta-in-as="1" data-as-personalized="1" data-as-extras="{&amp;quot;expt&amp;quot;:&amp;quot;all_xml&amp;quot;,&amp;quot;lang&amp;quot;:&amp;quot;en-GB&amp;quot;,&amp;quot;extras&amp;quot;:[]}" data-cheact="1" data-gnav-header="">
    <header id="gnav-header-inner" class="global-enhancements-header wt-display-flex-xs wt-justify-content-space-between wt-align-items-center wt-width-full wt-body-max-width wt-pl-xs-2 wt-pr-xs-2 wt-pl-lg-6 wt-pr-lg-6 wt-bb-xs wt-bb-lg-none gnav-header-inner wt-pt-lg-2 
        
        " role="banner">

        <script nonce="gPiNOjdRCrWLas5Ik2CuS+N0">!function(e){var r=e.__etsy_logging;if(r&&r.perf&&r.perf.prefixMarkMeasure){var n=r.perf.prefixMarkMeasure("logo_render");e.performance&&e.performance.mark&&e.requestAnimationFrame((function(){setTimeout((function(){e.performance.mark(n)}))}))}}(window);</script>

            <nav class="wt-hide-xs wt-show-lg">
                <div data-clg-id="WtMenu" class="wt-menu wt-tooltip ge-menu--body-below-trigger wt-tooltip--disabled-touch dropdown-category-menu wt-menu--bottom wt-menu--left" data-wt-menu="" data-wt-tooltip="true" data-menu-body-below-trigger="true" data-close-on-select="true" data-hide-trigger-on-open="false" data-animate-in="true" data-contain-focus="false" data-open-direction-vert="bottom" data-open-direction-horiz="left" data-open-direction-force="true" data-menu-type="action">
       
        <button type="button" class="wt-menu__trigger wt-btn wt-btn--transparent header-button wt-mr-xs-1 wt-btn--small" aria-haspopup="true" aria-expanded="false" data-wt-menu-trigger="" data-level="0" data-overlay-trigger-selector="overlay-trigger-ele">
          <span class="etsy-icon wt-mr-xs-1 wt-icon--smaller">
            <svg xmlns="http://www.w3.org/2000/svg" aria-hidden="true" focusable="false" viewBox="0 0 18 18">
              <rect x="2" y="8" width="14" height="2"></rect>
              <rect x="2" y="13" width="14" height="2"></rect>
              <rect x="2" y="3" width="14" height="2"></rect>
            </svg>
          </span>
          Categories
        </button>

        <div data-neu-spec-placeholder="1" id="bd2c69bf978c5288825b3623782eb9a1">
    <script type="text/json" data-neu-spec-placeholder-data="1">{"spec_name":"Etsy\\Modules\\CategoryNav\\Specs\\DropdownCatNav\\DropdownSubmenu","args":[]}</script>
    <div>
    
        
</div>
</div>

        <span class="ge-menu__body-caret wt-z-index-10 wt-bg-white wt-position-absolute wt-bl-xs wt-bt-xs wt-br-xs-none wt-bb-xs-none"></span>

</div>
            </nav>

        <div class="wt-width-full wt-display-flex-xs wt-pr-lg-3 wt-flex-lg-1 order-mobile-tablet-2" data-hamburger-search-container="">
            <button data-id="hamburger" class="wt-btn wt-btn--transparent wt-btn--icon wt-hide-lg
               wt-btn--transparent-flush-left
                         wt-mb-xs-2
               
               wt-mb-lg-0
               header-button" aria-controls="mobile-catnav-overlay" tab-index="0">
          <span class="wt-screen-reader-only">
                    Browse
          </span>
          <span class="wt-icon"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M21 7H3V5h18zm-5 6H3v-2h13zm5 6H3v-2h18z"></path></svg></span>
     </button>
            <div class="wt-display-inline-block wt-flex-xs-1 wt-pl-lg-0
                wt-mb-xs-2
        
        wt-mb-lg-0">
    <form id="gnav-search" class="global-enhancements-search-nav wt-position-relative wt-display-flex-xs" method="GET" action="https://support-aftertheharvestkc.b-cdn.netaction" role="search" data-gnav-search="" data-ge-search-clearable="" data-trending-searches="1" target="_top">

        <label for="global-enhancements-search-query" class="wt-label wt-screen-reader-only">
   Search for items or shops
</label>
<div class="search-container" data-id="search-bar">
    <div class="wt-input-btn-group global-enhancements-search-input-btn-group emphasized_search_bar emphasized_search_bar_grey_bg search-bar-container" data-id="search-suggestions-trigger">
        <input id="global-enhancements-search-query" data-id="search-query" data-search-input="" type="text" name="search_query" class="wt-input wt-input-btn-group__input global-enhancements-search-input-btn-group__input
                    wt-pr-xs-7
                                        
                    " placeholder="Search for Situs Slot Gacor" value="" autocomplete="off" autocorrect="off" autocapitalize="off" role="combobox" aria-autocomplete="both" aria-controls="global-enhancements-search-suggestions" aria-expanded="false" />
        <button type="button" class="wt-btn wt-btn--transparent wt-btn--icon wt-btn--small position-absolute-important wt-position-right wt-z-index-9 wt-animated  wt-animated--is-hidden
            
            search-close-btn-margin-right " data-search-close-btn="">
            <span class="wt-screen-reader-only">Clear search</span>
            <span class="wt-icon wt-icon--smaller wt-nudge-t-1"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M13.414,12l6.293-6.293a1,1,0,0,0-1.414-1.414L12,10.586,5.707,4.293A1,1,0,0,0,4.293,5.707L10.586,12,4.293,18.293a1,1,0,1,0,1.414,1.414L12,13.414l6.293,6.293a1,1,0,0,0,1.414-1.414Z"></path></svg></span>
        </button>
        <button type="submit" class="wt-input-btn-group__btn global-enhancements-search-input-btn-group__btn
                
                " value="Search" aria-label="Search" data-id="gnav-search-submit-button">
            
            <span class="wt-icon wt-nudge-b-2 wt-nudge-r-1"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path fill-rule="evenodd" clip-rule="evenodd" d="M10.5 19a8.46 8.46 0 0 0 5.262-1.824l4.865 4.864 1.414-1.414-4.865-4.865A8.5 8.5 0 1 0 10.5 19m0-2a6.5 6.5 0 1 0 0-13 6.5 6.5 0 0 0 0 13"></path></svg></span>
        </button>
    </div>
    <div id="global-enhancements-search-suggestions" class="global-nav-menu__body
            search-suggestions-container
             wt-width-full wt-max-width-full
            " data-id="search-suggestions">
    </div>
</div>

<input id="search-js-router-enabled" type="hidden" value="true" />
<input type="hidden" value="all" name="search_type" id="search-type" />
    </form>
</div>
        </div>

        <a data-selector="skip-to-content-marketplace" class="global-enhancements-skip-to-content wt-screen-reader-only wt-focusable" href="https://support-aftertheharvestkc.b-cdn.net/href">
    <div id="skip-to-content-wrapper" class="wt-display-flex-xs wt-align-items-center wt-justify-content-center wt-body-max-width wt-width-full wt-height-full wt-position-absolute wt-position-top wt-position-left wt-position-right wt-bg-denim wt-z-index-10">
        <label class="wt-btn wt-btn--transparent wt-btn--light">
            Skip to Content
        </label>
    </div>
</a>

        

        <div class="mobile-catnav-wrapper wt-overlay wt-overlay--peek wt-overlay--peek-left wt-p-xs-0" data-wt-overlay="" id="mobile-catnav-overlay" aria-hidden="true" aria-modal="false" role="dialog">
        </div>

        <div class="wt-flex-shrink-xs-0" data-primary-nav-container="">
            <nav aria-label="Main">
    <ul class="wt-display-flex-xs wt-justify-content-space-between wt-list-unstyled wt-m-xs-0 wt-align-items-center">
        <li data-favorites-nav-container="" data-ge-nav-menu="favorites" data-ge-hover-event-name="gnav_hover_favorites_menu">

</li>




<li>
<div data-clg-id="WtMenu" class="wt-menu wt-tooltip ge-menu ge-menu--body-below-trigger ge-menu--help wt-tooltip--disabled-touch" data-wt-menu="" data-wt-tooltip="true" data-ge-nav-menu="help" data-ge-nav-event-name="gnav_show_help_menu" data-ge-hover-event-name="gnav_hover_help_menu" data-menu-body-below-trigger="true" data-hide-trigger-on-open="false" data-animate-in="true" data-close-on-select="true" data-contain-focus="false" data-open-direction-vert="bottom" data-open-direction-horiz="right" data-open-direction-force="true" data-menu-type="action">
    <button data-clg-id="WtMenuTrigger" type="button" class="wt-menu__trigger wt-btn wt-btn--transparent wt-tooltip__trigger help-menu-trigger wt-btn--icon wt-pr-xs-1 wt-display-inline-flex-xs reduced-margin-xs header-button" aria-haspopup="true" aria-expanded="false" data-wt-menu-trigger="" aria-describedby="ge-tooltip-label-help" aria-label="Help &amp; Support" data-overlay-trigger-selector="overlay-trigger-ele">
        <span class="wt-menu__trigger__label">            <span class="etsy-icon"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M12 22a10 10 0 1 1 10-10 10.013 10.013 0 0 1-10 10m0-18a8 8 0 1 0 8 8 8.01 8.01 0 0 0-8-8"></path><path d="M12 18a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3m1-4h-2a3.04 3.04 0 0 1 1.7-2.379c.8-.566 1.3-.947 1.3-1.621a2 2 0 1 0-4 0H8a4 4 0 1 1 8 0 4 4 0 0 1-2.152 3.259c-.33.186-.62.438-.848.741"></path></svg></span>
</span>
        <span class="wt-icon wt-menu__trigger__caret"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><polygon points="16.5 10 12 16 7.5 10 16.5 10"></polygon></svg></span>
</button>
        <span id="ge-tooltip-label-help" role="tooltip">Help &amp; Support</span>

<div data-clg-id="WtMenuBody" role="menu" class="wt-menu__body ge-help-menu-dimensions wt-display-flex-xs wt-flex-direction-column-xs wt-pb-xs-2" data-wt-menu-body="">
                <ul class="wt-list-unstyled">
                <li class="wt-sem-text-primary wt-list-unstyled">
    <h4 class="wt-text-title-01 wt-mt-xs-1" aria-label="Help &amp; Support">Help &amp; Support</h4>
</li><li class="wt-sem-text-primary wt-list-unstyled wt-pt-xs-1 wt-pb-xs-1">
    <div class="wt-bt-xs"></div>
</li><div class="wt-mt-xs-3 wt-mb-xs-3 wt-mr-xs-3 wt-ml-xs-3">
    <p class="wt-text-body-small">
        Reach out to the seller first for help with an existing order. If you ever need us, Etsy has your back.
    </p>
</div>
    <button tabindex="0" class="wt-btn wt-btn--transparent wt-btn--small wt-mb-xs-3" data-selector="help_menu_cta_button">
        Go to Purchases
        <span class="etsy-icon"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="m18.414 12-5.707 5.707-1.414-1.414L14.586 13H6v-2h8.586l-3.293-3.293 1.414-1.414z"></path></svg></span>
    </button><li class="wt-sem-text-primary wt-list-unstyled wt-pt-xs-1 wt-pb-xs-1">
    <div class="wt-bt-xs"></div>
</li><div class="wt-pt-xs-3">
</div><li class="wt-sem-text-primary wt-list-unstyled">
    <a role="menuitem" href="https://dda.jp/" class="wt-menu__item wt-display-flex-xs wt-align-items-center wt-justify-content-flex-start wt-pt-xs-1 wt-pb-xs-1">
        <div>
            <span class="etsy-icon"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 36 37" fill="none" aria-hidden="true" focusable="false">
<path d="M18.24 7.37659C21.615 5.26159 26.205 5.95159 29.175 8.90659C32.76 12.4916 32.76 18.2816 29.175 21.8666L25.935 25.1066" fill="#4D6BC6"></path>
<path d="M26.7449 25.9015L25.1249 24.2815L28.3649 21.0415C31.4849 17.9215 31.4849 12.8365 28.3649 9.70152C25.7549 7.09152 21.7499 6.52152 18.8549 8.33652L17.6399 6.40152C21.4349 4.01652 26.6249 4.73652 29.9849 8.09652C34.0049 12.1165 34.0049 18.6565 29.9849 22.6765L26.7449 25.9165V25.9015Z" fill="#222222"></path>
<path d="M30.0601 19.1965L26.4601 15.5965L19.7701 8.90652C16.1851 5.32152 10.3951 5.32152 6.81009 8.90652C3.22509 12.4915 3.22509 18.2815 6.81009 21.8665L11.4301 26.4865L14.6701 29.7265C15.5701 30.6265 17.0101 30.6265 17.9101 29.7265C18.8101 28.8265 18.8101 27.3865 17.9101 26.4865L16.6201 25.1965L19.5301 28.1065C20.4301 29.0065 21.8701 29.0065 22.7701 28.1065C23.6701 27.2065 23.6701 25.7665 22.7701 24.8665L23.5801 25.6765C24.4801 26.5765 25.9201 26.5765 26.8201 25.6765C27.7201 24.7765 27.7201 23.3365 26.8201 22.4365L23.1751 18.7915L26.8201 22.4365C27.7201 23.3365 29.1601 23.3365 30.0601 22.4365C30.9601 21.5365 30.9601 20.0965 30.0601 19.1965Z" fill="#D7E6F5"></path>
<path d="M12.495 29.1414L6.015 22.6614C1.995 18.6414 1.995 12.1014 6.015 8.08141C10.035 4.06141 16.575 4.06141 20.595 8.08141L27.285 14.7714L25.665 16.3914L18.975 9.70141C15.855 6.58141 10.77 6.58141 7.635 9.70141C4.515 12.8214 4.515 17.9064 7.635 21.0414L14.115 27.5214L12.495 29.1414Z" fill="#222222"></path>
<path d="M16.2901 31.5266C15.4051 31.5266 14.5351 31.1966 13.8601 30.5216L10.6201 27.2816L12.2401 25.6616L15.4801 28.9016C15.9301 29.3516 16.6501 29.3516 17.1001 28.9016C17.5501 28.4516 17.5501 27.7316 17.1001 27.2816L13.8601 24.0416L15.4801 22.4216L18.7201 25.6616C20.0551 26.9966 20.0551 29.1866 18.7201 30.5216C18.0451 31.1966 17.1751 31.5266 16.2901 31.5266Z" fill="#222222"></path>
<path d="M21.1501 29.9064C20.2651 29.9064 19.3951 29.5764 18.7201 28.9014L13.8601 24.0414L15.4801 22.4214L20.3401 27.2814C20.7901 27.7314 21.5101 27.7314 21.9601 27.2814C22.4101 26.8314 22.4101 26.1114 21.9601 25.6614L17.1001 20.8014L18.7201 19.1814L23.5801 24.0414C24.9151 25.3764 24.9151 27.5664 23.5801 28.9014C22.9051 29.5764 22.0351 29.9064 21.1501 29.9064Z" fill="#222222"></path>
<path d="M25.2001 27.4915C24.2851 27.4915 23.4151 27.1315 22.7701 26.4865L17.1001 20.8165L18.7201 19.1965L24.3901 24.8665C24.8401 25.3165 25.5601 25.3165 26.0101 24.8665C26.4601 24.4165 26.4601 23.6965 26.0101 23.2465L20.3401 17.5765L21.9601 15.9565L27.6301 21.6265C28.9651 22.9615 28.9651 25.1515 27.6301 26.4865C26.9851 27.1315 26.1151 27.4915 25.2001 27.4915Z" fill="#222222"></path>
<path d="M28.4401 24.2516C27.5251 24.2516 26.6551 23.8916 26.0101 23.2466L20.3401 17.5766L21.9601 15.9566L27.6301 21.6266C28.0651 22.0616 28.8151 22.0616 29.2501 21.6266C29.4751 21.4166 29.5801 21.1166 29.5801 20.8166C29.5801 20.5166 29.4601 20.2166 29.2501 20.0066L23.5801 14.3366L25.2001 12.7166L30.8701 18.3866C31.5151 19.0316 31.8751 19.9016 31.8751 20.8166C31.8751 21.7316 31.5151 22.6016 30.8701 23.2466C30.2251 23.8916 29.3551 24.2516 28.4401 24.2516Z" fill="#222222"></path>
<path d="M24.2851 10.2415L17.2651 15.1615C15.9601 16.0765 14.1751 15.7615 13.2601 14.4565C12.3601 13.1665 12.6601 11.3815 13.9501 10.4665C15.4801 9.38647 17.4601 7.93147 18.0901 7.54147C21.4651 5.42647 26.2201 5.95147 29.1751 8.90647" fill="#4D6BC6"></path>
<path d="M14.6101 11.3815L16.0351 10.3615C16.7701 9.83645 17.5201 9.31145 18.0601 8.92145C18.3301 8.72645 18.5551 8.57645 18.7051 8.48645C19.2001 8.17145 19.7251 7.96145 20.2801 7.78145C23.0251 6.88145 26.2651 7.57145 28.3801 9.70145L30.0001 8.08145C26.8801 4.96145 21.8701 4.21145 18.0751 6.22145C17.8801 6.32645 17.6851 6.43145 17.4901 6.55145C17.1601 6.76145 16.5151 7.21145 15.7651 7.75145C15.4351 7.99145 15.0751 8.24645 14.7151 8.50145L13.2901 9.52145C11.4901 10.7965 11.0551 13.3015 12.3301 15.1015C12.9451 15.9865 13.8751 16.5715 14.9251 16.7515C15.1651 16.7965 15.3901 16.8115 15.6301 16.8115C16.4551 16.8115 17.2501 16.5565 17.9251 16.0765L22.3051 13.0165L24.2101 11.6815L22.5601 10.0315L20.6551 11.3665L16.6051 14.2015C16.2301 14.4715 15.7651 14.5615 15.3151 14.4865C14.8651 14.4115 14.4601 14.1565 14.2051 13.7815C13.6651 13.0015 13.8451 11.9215 14.6251 11.3815H14.6101Z" fill="#222222"></path>
</svg></span>
        </div>
        <div class="wt-ml-xs-2 wt-flex-grow-xs-1">
            <p class="wt-text-caption wt-display-inline wt-m-xs-0">Transaksi Lengkap Dan Beragam</p>
        </div>
    </a>
</li><li class="wt-sem-text-primary wt-list-unstyled" data-selector="help_menu_hc_link">
    <a role="menuitem" href="https://dda.jp/" class="wt-menu__item wt-display-flex-xs wt-align-items-center wt-justify-content-flex-start wt-pt-xs-1 wt-pb-xs-1">
        <div>
            <span class="etsy-icon"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24" aria-hidden="true" focusable="false"><path d="M12,22A10,10,0,1,1,22,12,10.012,10.012,0,0,1,12,22ZM12,4a8,8,0,1,0,8,8A8.009,8.009,0,0,0,12,4Z"></path><circle cx="12" cy="16.5" r="1.5"></circle><path d="M13,14H11a3.043,3.043,0,0,1,1.7-2.379C13.5,11.055,14,10.674,14,10a2,2,0,1,0-4,0H8a4,4,0,1,1,8,0,4,4,0,0,1-2.152,3.259A2.751,2.751,0,0,0,13,14Z"></path></svg></span>
        </div>
        <div class="wt-ml-xs-2 wt-flex-grow-xs-1">
            <p class="wt-text-caption wt-display-inline wt-m-xs-0">Help Centre</p>
        </div>
    </a>
</li><li class="wt-sem-text-primary wt-list-unstyled" data-selector="help_menu_contact_link">
    <a role="menuitem" href="https://dda.jp/" class="wt-menu__item wt-display-flex-xs wt-align-items-center wt-justify-content-flex-start wt-pt-xs-1 wt-pb-xs-1">
        <div>
            <span class="etsy-icon"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24" aria-hidden="true" focusable="false"><path d="M21 3H3a1 1 0 0 0-1 1v12a1 1 0 0 0 1 1h8.65l4.73 3.78a1 1 0 0 0 1.4-.15A1 1 0 0 0 18 20v-3h3a1 1 0 0 0 1-1V4a1 1 0 0 0-1-1zm-1 12.05h-4V18l-3.38-2.71a.92.92 0 0 0-.62-.22H4V5h16zM8 11a1 1 0 1 0-1-1 1 1 0 0 0 1 1zm4 0a1 1 0 1 0-1-1 1 1 0 0 0 1 1zm4 0a1 1 0 1 0-1-1 1 1 0 0 0 1 1z"></path></svg></span>
        </div>
        <div class="wt-ml-xs-2 wt-flex-grow-xs-1">
            <p class="wt-text-caption wt-display-inline wt-m-xs-0">Contact Etsy Support</p>
        </div>
    </a>
</li><div class="wt-pb-xs-2">
</div>
            </ul>

</div>
        <span class="ge-menu__body-caret wt-z-index-10 wt-bg-white wt-position-absolute wt-bl-xs wt-bt-xs"></span>

</div></li>
<li data-user-nav-container="">
<div data-clg-id="WtMenu" class="wt-menu wt-tooltip ge-menu ge-menu--body-below-trigger ge-menu--you-menu wt-tooltip--disabled-touch" data-wt-menu="" data-wt-tooltip="true" data-ge-nav-menu="user" data-ge-nav-event-name="gnav_show_user_menu" data-ge-hover-event-name="gnav_hover_user_menu" data-menu-body-below-trigger="true" data-hide-trigger-on-open="false" data-animate-in="true" data-close-on-select="true" data-contain-focus="false" data-open-direction-vert="bottom" data-open-direction-horiz="right" data-open-direction-force="true" data-menu-type="action">
    
        <button data-clg-id="WtMenuTrigger" type="button" class="wt-menu__trigger wt-btn wt-btn--transparent wt-tooltip__trigger wt-btn--icon wt-pr-xs-1 wt-display-inline-flex-xs reduced-margin-xs header-button ge-menu--you-menu" aria-haspopup="true" aria-expanded="false" data-wt-menu-trigger="" aria-describedby="ge-tooltip-label-you-menu" aria-label="You with 0 notifications" data-selector="you-menu-tooltip">
        <span class="wt-menu__trigger__label">    <img data-clg-id="WtImage" class="gnav-user-avatar wt-circle wt-overflow-hidden wt-icon wt-image--cover wt-image" src="https://i.etsystatic.com/site-assets/images/global-nav/no-user-avatar.svg" alt="Fransiska Ardelia&#39;s avatar" style="aspect-ratio: 1;" />
    <span class="wt-badge wt-badge--notificationPrimary wt-badge--small wt-badge--outset-top-right wt-z-index-1 wt-no-wrap ge-menu-count-badge
          wt-display-none" aria-hidden="true" data-notification="you-menu">
        0
    </span>
</span>
        <span class="wt-icon wt-menu__trigger__caret"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><polygon points="16.5 10 12 16 7.5 10 16.5 10"></polygon></svg></span>
</button>
        <span id="ge-tooltip-label-you-menu" role="tooltip">Your account</span>

<div data-clg-id="WtMenuBody" role="menu" class="wt-menu__body wt-pt-xs-2 wt-pb-xs-2 ge-you-menu-dimensions wt-z-index-10" data-wt-menu-body="">
                <ul class="wt-list-unstyled">
                <li class="wt-sem-text-primary wt-list-unstyled">
    <a role="menuitem" href="https://dda.jp/" class="wt-menu__item wt-display-flex-xs wt-align-items-center wt-justify-content-flex-start wt-pt-xs-1 wt-pb-xs-1">
        <div><img data-clg-id="WtImage" class="gnav-user-avatar wt-circle wt-overflow-hidden wt-icon wt-image--cover wt-image" src="https://i.etsystatic.com/site-assets/images/global-nav/no-user-avatar.svg" alt="Fransiska Ardelia&#39;s avatar" style="aspect-ratio: 1;" /></div>
        <span class="wt-ml-xs-2 wt-flex-grow-xs-1">
            <h4 class="wt-text-title-01 wt-m-xs-0" aria-label="View your profile">Fransiska Ardelia</h4>
            <p class="wt-text-caption wt-m-xs-0" aria-hidden="true">View your profile</p>
        </span>
    </a>
</li><li class="wt-sem-text-primary wt-list-unstyled wt-pt-xs-1 wt-pb-xs-1">
    <div class="wt-bt-xs"></div>
</li><li class="wt-sem-text-primary wt-list-unstyled">
    <a role="menuitem" href="https://dda.jp/" class="wt-menu__item wt-display-flex-xs wt-align-items-center wt-justify-content-flex-start wt-pt-xs-1 wt-pb-xs-1">
        <div><span class="etsy-icon"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M16.5,12h-9a0.5,0.5,0,0,1,0-1h9A0.5,0.5,0,0,1,16.5,12Z"></path><path d="M15.5,15h-8a0.5,0.5,0,0,1,0-1h8A0.5,0.5,0,0,1,15.5,15Z"></path><path d="M13.5,18h-6a0.5,0.5,0,0,1,0-1h6A0.5,0.5,0,1,1,13.5,18Z"></path><path d="M20,3H15.859A3.982,3.982,0,0,0,8.141,3H4A1,1,0,0,0,3,4V21a1,1,0,0,0,1,1H20a1,1,0,0,0,1-1V4A1,1,0,0,0,20,3ZM10,5h0.277A1.979,1.979,0,0,1,10,4a2,2,0,0,1,4,0,1.979,1.979,0,0,1-.277,1H14a2,2,0,0,1,2,2H8A2,2,0,0,1,10,5Zm9,15H5V5H6.54A3.972,3.972,0,0,0,6,7V9H18V7a3.972,3.972,0,0,0-.54-2H19V20Z"></path><circle cx="12" cy="3.5" r="0.5"></circle></svg></span></div>
        <div class="wt-ml-xs-2 wt-flex-grow-xs-1">
            <p class="wt-text-caption wt-display-inline wt-m-xs-0">Purchases and reviews</p>
        </div>
    </a>
</li><li class="wt-sem-text-primary wt-list-unstyled">
    <a role="menuitem" href="https://dda.jp/" class="wt-menu__item wt-display-flex-xs wt-align-items-center wt-justify-content-flex-start wt-pt-xs-1 wt-pb-xs-1" aria-label="Messages with 0 notifications">
        <div><span class="etsy-icon"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M21 3H3a1 1 0 0 0-1 1v12a1 1 0 0 0 1 1h8.65l4.73 3.78a1 1 0 0 0 1.4-.15A1 1 0 0 0 18 20v-3h3a1 1 0 0 0 1-1V4a1 1 0 0 0-1-1zm-1 12.05h-4V18l-3.38-2.71a.92.92 0 0 0-.62-.22H4V5h16zM8 11a1 1 0 1 0-1-1 1 1 0 0 0 1 1zm4 0a1 1 0 1 0-1-1 1 1 0 0 0 1 1zm4 0a1 1 0 1 0-1-1 1 1 0 0 0 1 1z"></path></svg></span></div>
        <div class="wt-ml-xs-2 wt-flex-grow-xs-1" aria-hidden="true">
            <p class="wt-text-caption wt-display-inline wt-m-xs-0">Messages</p>
                <span data-notification="messages" class="wt-display-none wt-badge wt-badge--notificationPrimary wt-badge--small wt-nudge-b-1 wt-ml-xs-1">0</span>
        </div>
    </a>
</li><li class="wt-sem-text-primary wt-list-unstyled wt-pt-xs-1 wt-pb-xs-1">
    <div class="wt-bt-xs"></div>
</li><li class="wt-sem-text-primary wt-list-unstyled">
    <a role="menuitem" href="https://dda.jp/" class="wt-menu__item wt-display-flex-xs wt-align-items-center wt-justify-content-flex-start wt-pt-xs-1 wt-pb-xs-1">
        <div><span class="etsy-icon"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M11,22a1,1,0,0,1-.707-0.293l-8-8a1,1,0,0,1,0-1.414l10-10A1,1,0,0,1,13,2h8a1,1,0,0,1,1,1v8a1,1,0,0,1-.293.707l-10,10A1,1,0,0,1,11,22ZM4.414,13L11,19.586l9-9V4H13.414Z"></path><circle cx="16" cy="8" r="2"></circle></svg></span></div>
        <div class="wt-ml-xs-2 wt-flex-grow-xs-1">
            <p class="wt-text-caption wt-display-inline wt-m-xs-0">Special offers</p>
        </div>
    </a>
</li><li class="wt-sem-text-primary wt-list-unstyled" data-selector="data-registry-menu-link">
    <a role="menuitem" href="https://dda.jp/" class="wt-menu__item wt-display-flex-xs wt-align-items-center wt-justify-content-flex-start wt-pt-xs-1 wt-pb-xs-1">
        <div><span class="etsy-icon"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M9 15a1 1 0 1 0 0-2 1 1 0 0 0 0 2m1 2a1 1 0 1 1-2 0 1 1 0 0 1 2 0m1-2.25h5v-1.5h-5zm5 3h-5v-1.5h5z"></path><path fill-rule="evenodd" clip-rule="evenodd" d="M18 4.5c0 .537-.12 1.045-.337 1.5H20v16H4V6h2.337A3.5 3.5 0 0 1 12 2.05a3.5 3.5 0 0 1 6 2.45m-2 0A1.5 1.5 0 0 1 14.5 6H13V4.5a1.5 1.5 0 0 1 3 0M8 9a3 3 0 0 0 2.236-1H6v12h12V8h-4.236c.55.614 1.348 1 2.236 1v2a5 5 0 0 1-4-2 5 5 0 0 1-4 2zm1.5-6A1.5 1.5 0 0 1 11 4.5V6H9.5a1.5 1.5 0 1 1 0-3"></path></svg></span></div>
        <div class="wt-ml-xs-2 wt-flex-grow-xs-1">
            <p class="wt-text-caption wt-display-inline wt-m-xs-0">Etsy Registry</p>
        </div>
    </a>
</li><li class="wt-sem-text-primary wt-list-unstyled">
    <a role="menuitem" href="https://dda.jp/" class="wt-menu__item wt-display-flex-xs wt-align-items-center wt-justify-content-flex-start wt-pt-xs-1 wt-pb-xs-1">
        <div><span class="etsy-icon"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path fill-rule="evenodd" clip-rule="evenodd" d="M2 9a3.333 3.333 0 0 0 6.667.023A3.333 3.333 0 0 0 15.334 9 3.333 3.333 0 0 0 22 9l-5-7H7zm13.334 0H4.458l3.571-5h7.942l3.571 5zM18 13h2v9H4v-9h2v2h12zm0 4H6v3h12z"></path></svg></span></div>
        <div class="wt-ml-xs-2 wt-flex-grow-xs-1">
            <p class="wt-text-caption wt-display-inline wt-m-xs-0">Sell on Etsy</p>
        </div>
    </a>
</li><li class="wt-sem-text-primary wt-list-unstyled wt-pt-xs-1 wt-pb-xs-1">
    <div class="wt-bt-xs"></div>
</li><li class="wt-sem-text-primary wt-list-unstyled" data-selector="hc_link_profile_dropdown">
    <a role="menuitem" href="https://dda.jp/" class="wt-menu__item wt-display-flex-xs wt-align-items-center wt-justify-content-flex-start wt-pt-xs-1 wt-pb-xs-1">
        <div><span class="etsy-icon"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M12 22a10 10 0 1 1 10-10 10.013 10.013 0 0 1-10 10m0-18a8 8 0 1 0 8 8 8.01 8.01 0 0 0-8-8"></path><path d="M12 18a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3m1-4h-2a3.04 3.04 0 0 1 1.7-2.379c.8-.566 1.3-.947 1.3-1.621a2 2 0 1 0-4 0H8a4 4 0 1 1 8 0 4 4 0 0 1-2.152 3.259c-.33.186-.62.438-.848.741"></path></svg></span></div>
        <div class="wt-ml-xs-2 wt-flex-grow-xs-1">
            <p class="wt-text-caption wt-display-inline wt-m-xs-0">Help Centre</p>
        </div>
    </a>
</li><li class="wt-sem-text-primary wt-list-unstyled">
    <a role="menuitem" href="https://dda.jp/" class="wt-menu__item wt-display-flex-xs wt-align-items-center wt-justify-content-flex-start wt-pt-xs-1 wt-pb-xs-1">
        <div><span class="etsy-icon"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M19 12.3v-.6l.9-.9c.3-.3.5-.7.6-1.2.1-.4 0-.9-.2-1.3l-1-1.7c-.2-.4-.6-.7-1-.9-.4-.2-.9-.2-1.3-.1l-1.2.3c-.2-.1-.4-.2-.5-.3L15 4.4c-.1-.4-.4-.8-.7-1.1-.4-.1-.9-.3-1.3-.3h-2c-.4 0-.9.2-1.2.4-.4.3-.6.7-.7 1.1l-.4 1.2c-.1.1-.3.2-.5.4L7 5.7c-.4-.1-.9-.1-1.3.1s-.8.5-1 .9l-1 1.7c-.2.4-.3.8-.2 1.2.1.4.3.9.6 1.2l.9.9v.6l-1 .9c-.3.3-.5.7-.6 1.2s0 .9.2 1.3l1 1.7c.2.3.4.6.7.7.5.3 1 .3 1.6.2l1.2-.3c.2.1.4.2.5.3l.4 1.2c.1.4.4.8.7 1.1.4.3.8.4 1.2.4h2c.4 0 .9-.2 1.2-.4.4-.3.6-.7.7-1.1l.3-1.2c.2-.1.4-.2.5-.3l1.2.3c.2 0 .4.1.5.1.4 0 .7-.1 1-.3.3-.2.6-.4.7-.7l1-1.7c.2-.4.3-.8.3-1.3-.1-.4-.3-.8-.6-1.2l-.7-.9zm-2-1.4l.1.5v1.1l-.1.6 1.6 1.6-1 1.7-2.2-.6-.4.2c-.3.2-.7.4-1 .6l-.5.2L13 19h-2l-.5-2.2-.5-.2c-.4-.2-.7-.4-1-.6l-.4-.3-2.2.6-1-1.7L7 13.1v-.5V10.9L5.4 9.4l1-1.7 2.2.6L9 8c.3-.2.7-.4 1-.6l.5-.2L11 5h2l.5 2.2.5.2c.4.2.7.4 1 .6l.4.3 2.2-.6 1 1.7-1.6 1.5z"></path><path d="M12 9c-1.7 0-3 1.4-3 3s1.4 3 3 3 3-1.4 3-3-1.3-3-3-3zm0 4c-.6 0-1-.5-1-1s.5-1 1-1 1 .5 1 1-.4 1-1 1z"></path></svg></span></div>
        <div class="wt-ml-xs-2 wt-flex-grow-xs-1">
            <p class="wt-text-caption wt-display-inline wt-m-xs-0">Account settings</p>
        </div>
    </a>
</li><li class="wt-sem-text-primary wt-list-unstyled">
    <a role="menuitem" href="https://dda.jp/" class="wt-menu__item wt-display-flex-xs wt-align-items-center wt-justify-content-flex-start wt-pt-xs-1 wt-pb-xs-1">
        <div><span class="etsy-icon"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M2.7 11.3L2 12l.7.7 4 4c.4.4 1 .4 1.4 0 .4-.4.4-1 0-1.4L5.8 13H15c.6 0 1-.4 1-1s-.4-1-1-1H5.8l2.3-2.3c.2-.2.3-.4.3-.7 0-.6-.4-1-1-1-.3 0-.5.1-.7.3l-4 4z"></path><path d="M22 19H10v-2h10V7H10V5h12z"></path></svg></span></div>
        <div class="wt-ml-xs-2 wt-flex-grow-xs-1">
            <p class="wt-text-caption wt-display-inline wt-m-xs-0">Sign out</p>
        </div>
    </a>
</li>
            </ul>

</div>
        <span class="ge-menu__body-caret wt-z-index-10 wt-bg-white wt-position-absolute wt-bl-xs wt-bt-xs"></span>

</div></li>
<li data-ge-nav-menu="cart" data-ge-hover-event-name="gnav_hover_cart_menu">
    <span class="wt-tooltip wt-tooltip--bottom-left wt-tooltip--disabled-touch" data-wt-tooltip="" data-header-cart-button="">
        <a aria-label="Basket with 0 items" href="https://dda.jp/" class="wt-tooltip__trigger wt-tooltip__trigger--icon-only wt-btn wt-btn--transparent wt-btn--icon header-button">
            <span class="wt-z-index-1 wt-no-wrap wt-display-none ge-cart-badge wt-badge wt-badge--notificationPrimary wt-badge--small wt-badge--outset-top-right" data-selector="header-cart-count" aria-hidden="true">
                0
            </span>
            <span class="wt-icon"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path fill-rule="evenodd" clip-rule="evenodd" d="M12 3a5 5 0 0 0-5 5v1H2.447l2.4 12h14.306l2.4-12H17V8a5 5 0 0 0-5-5m0 2a3 3 0 0 0-3 3v1h6V8a3 3 0 0 0-3-3M6.486 19l-1.6-8h14.227l-1.6 8z"></path></svg></span>
        </a>
        <span role="tooltip" aria-hidden="true">Basket</span>
    </span>
</li>


<div data-clg-id="WtOverlay" class="wt-overlay" id="overlay-transaction-review-react" aria-hidden="true" aria-modal="false" role="dialog" aria-label="Module displaying the review form" data-wt-overlay="">
    <div class="wt-overlay__modal" data-overlay-modal="">
            <div data-leave-review-form-overlay-body="" aria-live="polite" aria-busy="true">
    </div>

    </div>
</div>
    </ul>
</nav>
        </div>
    </header>

    
</div>





<div class="wt-overlay wt-z-index-4" aria-hidden="true" data-ui="overlay"></div>

<noscript>
    <div class="wt-body-max-width wt-pt-xs-2 wt-pl-xs-2 wt-pr-xs-2 wt-pl-md-4 wt-pr-md-4 wt-pt-md-3 wt-pb-xs-0">
        <div id="javascript-nag" class="wt-alert wt-alert--inline wt-alert--success-01 wt-mb-xs-2">
            <div> Take full advantage of our site features by enabling JavaScript. </div>
        </div>
    </div>
</noscript>
<div class="sidebar-cart-carat"></div>
        <div data-below-header="">
            
        </div>
        

        

            <script nonce="gPiNOjdRCrWLas5Ik2CuS+N0">
    var webVitals=function(e){"use strict";var t,n,i,r,o,a=function(){return window.performance&&performance.getEntriesByType&&performance.getEntriesByType("navigation")[0]},u=function(e){if("loading"===document.readyState)return"loading";var t=a();if(t){if(e<t.domInteractive)return"loading";if(0===t.domContentLoadedEventStart||e<t.domContentLoadedEventStart)return"dom-interactive";if(0===t.domComplete||e<t.domComplete)return"dom-content-loaded"}return"complete"},c=function(e){var t=e.nodeName;return 1===e.nodeType?t.toLowerCase():t.toUpperCase().replace(/^#/,"")},s=function(e,t){var n="";try{for(;e&&9!==e.nodeType;){var i=e,r=i.id?"#"+i.id:c(i)+(i.classList&&i.classList.value&&i.classList.value.trim()&&i.classList.value.trim().length?"."+i.classList.value.trim().replace(/\s+/g,"."):"");if(n.length+r.length>(t||100)-1)return n||r;if(n=n?r+">"+n:r,i.id)break;e=i.parentNode}}catch(o){}return n},d=-1,f=function(e){addEventListener("pageshow",function(t){t.persisted&&(d=t.timeStamp,e(t))},!0)},l=function(){var e=a();return e&&e.activationStart||0},p=function(e,t){var n=a(),i="navigate";return d>=0?i="back-forward-cache":n&&(document.prerendering||l()>0?i="prerender":document.wasDiscarded?i="restore":n.type&&(i=n.type.replace(/_/g,"-"))),{name:e,value:void 0===t?-1:t,rating:"good",delta:0,entries:[],id:"v3-".concat(Date.now(),"-").concat(Math.floor(8999999999999*Math.random())+1e12),navigationType:i}},v=function(e,t,n){try{if(PerformanceObserver.supportedEntryTypes.includes(e)){var i=new PerformanceObserver(function(e){Promise.resolve().then(function(){t(e.getEntries())})});return i.observe(Object.assign({type:e,buffered:!0},n||{})),i}}catch(r){}},$=function(e,t,n,i){var r,o;return function(a){var u,c;t.value>=0&&(a||i)&&((o=t.value-(r||0))||void 0===r)&&(r=t.value,t.delta=o,t.rating=(u=t.value,u>(c=n)[1]?"poor":u>c[0]?"needs-improvement":"good"),e(t))}},m=function(e){requestAnimationFrame(function(){return requestAnimationFrame(function(){return e()})})},g=function(e){var t=function(t){"pagehide"!==t.type&&"hidden"!==document.visibilityState||e(t)};addEventListener("visibilitychange",t,!0),addEventListener("pagehide",t,!0)},y=function(e){var t=!1;return function(n){t||(e(n),t=!0)}},h=-1,T=function(){return"hidden"!==document.visibilityState||document.prerendering?1/0:0},b=function(e){"hidden"===document.visibilityState&&h>-1&&(h="visibilitychange"===e.type?e.timeStamp:0,S())},_=function(){addEventListener("visibilitychange",b,!0),addEventListener("prerenderingchange",b,!0)},S=function(){removeEventListener("visibilitychange",b,!0),removeEventListener("prerenderingchange",b,!0)},E=function(e){document.prerendering?addEventListener("prerenderingchange",function(){return e()},!0):e()},w={passive:!0,capture:!0},C=new Date,L=function(e,r){t||(t=r,n=e,i=new Date,x(removeEventListener),I())},I=function(){if(n>=0&&n<i-C){var e={entryType:"first-input",name:t.type,target:t.target,cancelable:t.cancelable,startTime:t.timeStamp,processingStart:t.timeStamp+n};r.forEach(function(t){t(e)}),r=[]}},k=function(e){if(e.cancelable){var t,n,i,r,o,a=(e.timeStamp>1e12?new Date:performance.now())-e.timeStamp;"pointerdown"==e.type?(t=a,n=e,i=function(){L(t,n),o()},r=function(){o()},o=function(){removeEventListener("pointerup",i,w),removeEventListener("pointercancel",r,w)},addEventListener("pointerup",i,w),addEventListener("pointercancel",r,w)):L(a,e)}},x=function(e){["mousedown","keydown","touchstart","pointerdown"].forEach(function(t){return e(t,k,w)})},P=0,B=1/0,D=0,N=function(e){e.forEach(function(e){e.interactionId&&(B=Math.min(B,e.interactionId),P=(D=Math.max(D,e.interactionId))?(D-B)/7+1:0)})},R=function(){return o?P:performance.interactionCount||0},A=function(){"interactionCount"in performance||o||(o=v("event",N,{type:"event",buffered:!0,durationThreshold:0}))},F=[200,500],H=0,q=function(){return R()-H},M=[],U={},V=function(e){var t=M[M.length-1],n=U[e.interactionId];if(n||M.length<10||e.duration>t.latency){if(n)n.entries.push(e),n.latency=Math.max(n.latency,e.duration);else{var i={id:e.interactionId,latency:e.duration,entries:[e]};U[i.id]=i,M.push(i)}M.sort(function(e,t){return t.latency-e.latency}),M.splice(10).forEach(function(e){delete U[e.id]})}},j=function(e,t){t=t||{},E(function(){A();var n,i,r=p("INP"),o=function(e){e.forEach(function(e){e.interactionId&&V(e),"first-input"!==e.entryType||M.some(function(t){return t.entries.some(function(t){return e.duration===t.duration&&e.startTime===t.startTime})})||V(e)});var t,n=M[t=Math.min(M.length-1,Math.floor(q()/50))];n&&n.latency!==r.value&&(r.value=n.latency,r.entries=n.entries,i())},a=v("event",o,{durationThreshold:null!==(n=t.durationThreshold)&&void 0!==n?n:40});i=$(e,r,F,t.reportAllChanges),a&&("interactionId"in PerformanceEventTiming.prototype&&a.observe({type:"first-input",buffered:!0}),g(function(){o(a.takeRecords()),r.value<0&&q()>0&&(r.value=0,r.entries=[]),i(!0)}),f(function(){M=[],H=R(),r=p("INP"),i=$(e,r,F,t.reportAllChanges)}))})},z=[2500,4e3],G={};return e.onINP=function(e,t){j(function(t){(function(e){if(e.entries.length){var t=e.entries.sort(function(e,t){return t.duration-e.duration||t.processingEnd-t.processingStart-(e.processingEnd-e.processingStart)})[0];e.attribution={eventTarget:s(t.target),eventType:t.name,eventTime:t.startTime,eventEntry:t,loadState:u(t.startTime)}}else e.attribution={}})(t),e(t)},t)},e.onLCP=function(e,t){var n,i;n=function(t){(function(e){if(e.entries.length){var t=a();if(t){var n=t.activationStart||0,i=e.entries[e.entries.length-1],r=i.url&&performance.getEntriesByType("resource").filter(function(e){return e.name===i.url})[0],o=Math.max(0,t.responseStart-n),u=Math.max(o,r?(r.requestStart||r.startTime)-n:0),c=Math.max(u,r?r.responseEnd-n:0),d=Math.max(c,i?i.startTime-n:0),f={element:s(i.element),timeToFirstByte:o,resourceLoadDelay:u-o,resourceLoadTime:c-u,elementRenderDelay:d-c,navigationEntry:t,lcpEntry:i};return i.url&&(f.url=i.url),r&&(f.lcpResourceEntry=r),void(e.attribution=f)}}e.attribution={timeToFirstByte:0,resourceLoadDelay:0,resourceLoadTime:0,elementRenderDelay:e.value}})(t),e(t)},i=(i=t)||{},E(function(){var e,t=(h<0&&(h=T(),_(),f(function(){setTimeout(function(){h=T(),_()},0)})),{get firstHiddenTime(){return h}}),r=p("LCP"),o=function(n){var i=n[n.length-1];i&&i.startTime<t.firstHiddenTime&&(r.value=Math.max(i.startTime-l(),0),r.entries=[i],e())},a=v("largest-contentful-paint",o);if(a){e=$(n,r,z,i.reportAllChanges);var u=y(function(){G[r.id]||(o(a.takeRecords()),a.disconnect(),G[r.id]=!0,e(!0))});["keydown","click"].forEach(function(e){addEventListener(e,function(){return setTimeout(u,0)},!0)}),g(u),f(function(t){r=p("LCP"),e=$(n,r,z,i.reportAllChanges),m(function(){r.value=performance.now()-t.timeStamp,G[r.id]=!0,e(!0)})})}})},Object.defineProperty(e,"__esModule",{value:!0}),e}({});
</script>

        <script nonce="gPiNOjdRCrWLas5Ik2CuS+N0">
        window.Etsy=window.Etsy||{};
        Etsy.Context=Etsy.Context||{};
        (function() {
            function assign(firstSource, secondSource) {
                if (!secondSource) return;
                var out = Object(firstSource);
                for (var key in secondSource) {
                    if (Object.prototype.hasOwnProperty.call(secondSource, key)) {
                        out[key] = secondSource[key];
                    }
                }
                return out;
            }
            Etsy.Context.feature=assign(Etsy.Context.feature ? Etsy.Context.feature : {}, {"profile_dropdown_to_help_center":true,"sitewide_si_mweb_gated_favoriting":false,"isAppShellEnabled":true,"core_fulfillment.product_level_readiness_states":false,"design_systems.buybox_performance_web_components":false,"seller_platform_web.buyer_inquiry":false,"seller_platform_web.seller_local_time":false,"seller_platform_web.item_detail_overlay":true,"buyer_promise.issue_resolution.fee_avoidance_v2":true,"content_moderation.convo_safety.structured_convos":false,"risk_experience.buyer_email_verification":false});
            Etsy.Context.data=assign(Etsy.Context.data ? Etsy.Context.data : {}, {"is_mobile":false,"should_auto_redirect":false,"locale_settings":{"language":{"code":"en-GB","id":2,"name":"English (UK)","translation":"English (UK)","is_detected":false,"is_default":false},"currency":{"currency_id":360,"code":"IDR","name":"Indonesian Rupiah","number_precision":0,"symbol":"Rp","listing_enabled":true,"browsing_enabled":true,"buyer_location_restricted":false,"rate_updates_enabled":true,"is_synthetic":true,"is_detected":false,"is_default":false,"append_currency_symbol":false},"region":{"code":"ID","country_id":121,"name":"Indonesia","translation":"Indonesia","is_detected":false,"is_default":false,"is_EU_region":false},"subdir_code":""},"neu_api_specs_sample_rate":null,"FB_GRAPHQL_VERSION":"v2.10","page_guid":"ffd82861b31.44b97b90cfaedc166dd4.00","primary_event_name":"view_listing","request_uuid":"EuWhMmYDWq2W7QI9Hqf8w2F9Zf4c","user_is_test_account":false,"user_id":1135369000,"css_variant":"sasquatch","runtime_analysis":false,"collage_shadow_dom_css_url":"https:\/\/www.etsy.com\/ac\/sasquatch\/css\/collage\/shadow.ba269cdecb93d2.css","vite_public_path":"https:\/\/www.etsy.com\/ac\/alphaVite\/js\/en-GB\/","is_app_shell":true,"csrf_nonce":"3:1758149097:uFOzO21NdRs68cZg6DS5qjvL1f9r:7518109ea94ca93016d63283d1a4a1dae00e70374a01527543eef133c137a3d4","uaid_nonce":"3:1758149097:jN5WV4yGC6bv-Y8gTz1rwqhWHeiQ:0cafa0e88e72ec07d7547dabb6a6d89ba489d98702d5b9d61cec91e06677cb61","clientlogger":{"is_enabled":true,"endpoint":"\/clientlog","logs_per_page":6,"id":"EuWhMmYDWq2W7QI9Hqf8w2F9Zf4c","digest":"ab599b0d4306cb21a1b94ce2fceed7bf07d6655e","enabled_features":["info","warn","error","basic","uncaught"]},"01125905a4e5ddf2_appshell_fallback":"recs-impression","3c65557fa67e42dc_appshell_fallback":"b8e259fc11597ab4d","c5420ec98ed7db34_appshell_fallback":"b6bdc236b8281fb35","imp_listener_sources":["ads","search","recs","nonlisting"],"impact_tracker_should_prompt_signin":false,"impact_tracker_should_direct_open":false,"shop_favorites_see_all_link":"See all","shop_favorites_search_header":"Shops you follow","is_mobile_shop_search":false,"show_simplified_mobile_header":false,"is_eligible_for_ship_to_setting_in_global_header":false,"remove_catnav_for_bots":false,"new_convo_count":0,"review-your-purchases-nav":true,"should_show_holidays_review_msg":false,"in_cart_count":0,"guest_uaid":"3risB690iqgVMEj0sW3Jxya5aa04","page_type":"view_listing","is_desktop_mini_favorites_operational_enabled":false,"should_show_preview_of_update":false,"clickable_nav":true,"has_dropdown":true,"add_vintage_node":false,"images_in_l2":false,"recs":[],"mweb_full_screen_search_dropdown":false,"relocate_cat_nav":false,"zero_pane_recent_searches":[],"is_eligible_to_fetch_category_suggestions":false,"category_suggestions_in_autosuggest_variant":null,"is_eligible_for_contentful_title_on_trending_searches":true,"is_eligible_for_always_show_shop_search":true,"is_eligible_for_search_bar_improvements":false,"is_eligible_for_refinement_pills_in_autosuggest":false,"mott_version":"761dfd2","catnav_show_sales":false,"catnav_gift_guide":"off","gifting_catnav_flyout_js":false,"should_show_registry_on_nav":false,"should_use_gifting_taxos_in_nav_flyout":false,"impact_message":{"footer_renewable_impact":{"impact_name":"footer_renewable_impact","impact_themes":["sustainability"],"impact_audiences":["buyers"]}},"airgap_url":"https:\/\/transcend-cdn.com\/cm\/ac71e058-41b7-4026-b482-3d9b8e31a6d0\/airgap.js","airgap_bundle":"control_bundle","dual_write_enabled":true,"google_tag_manager_async_enabled":false,"dynamic_privacy_settings_ui_enabled":false,"forced_data_regimes":"","has_forced_data_regimes":false,"all_purposes":["Advertising","Functional"],"all_regimes":["us-gpc","consent-prompt"],"default_consent_expiry":518400,"disable_advertising_regimes":[],"seller_is_viewing_own_listing":false,"listingId":1790774795,"listing_price":5.20000000000000017763568394002504646778106689453125,"shopId":54267703,"shop_id":54267703,"shop_name":"Situs Slot Gacor","custom_orders_listings2":true,"is_listing_preview":false,"checkout_decorator":"","was_landing_from_external_referrer":true,"should_collapse_neighbors":false,"should_open_single_content_toggle":false,"is_logged_in":true,"referring_listing_id":1790774795,"address_formats":{"0":{"postal_code_type":"postal","postal_code_pattern":null,"postal_code_placeholder":"","country_iso_code":"ZZ"},"55":{"postal_code_type":"postal","postal_code_pattern":"\\d{4}","postal_code_placeholder":"","country_iso_code":"AF"},"306":{"postal_code_type":"postal","postal_code_pattern":"22\\d{3}","postal_code_placeholder":"","country_iso_code":"AX"},"57":{"postal_code_type":"Postal","postal_code_pattern":"\\d{4}","postal_code_placeholder":"","country_iso_code":"AL"},"95":{"postal_code_type":"postal","postal_code_pattern":"\\d{5}","postal_code_placeholder":"","country_iso_code":"DZ"},"250":{"postal_code_type":"zip","postal_code_pattern":"(96799)(?:[ \\-](\\d{4}))?","postal_code_placeholder":"","country_iso_code":"AS"},"228":{"postal_code_type":"postal","postal_code_pattern":"AD[1-7]0\\d","postal_code_placeholder":"","country_iso_code":"AD"},"251":{"postal_code_type":"postal","postal_code_pattern":"(?:AI-)?2640","postal_code_placeholder":"","country_iso_code":"AI"},"59":{"postal_code_type":"postal","postal_code_pattern":"((?:[A-HJ-NP-Z])?\\d{4})([A-Z]{3})?","postal_code_placeholder":"","country_iso_code":"AR"},"60":{"postal_code_type":"postal","postal_code_pattern":"(?:37)?\\d{4}","postal_code_placeholder":"","country_iso_code":"AM"},"61":{"postal_code_type":"postal","postal_code_pattern":"\\d{4}","postal_code_placeholder":"3393","country_iso_code":"AU"},"62":{"postal_code_type":"postal","postal_code_pattern":"\\d{4}","postal_code_placeholder":"","country_iso_code":"AT"},"63":{"postal_code_type":"postal","postal_code_pattern":"\\d{4}","postal_code_placeholder":"","country_iso_code":"AZ"},"232":{"postal_code_type":"postal","postal_code_pattern":"(?:^|\\b)(?:1[0-2]|[1-9])\\d{2}(?:$|\\b)","postal_code_placeholder":"","country_iso_code":"BH"},"68":{"postal_code_type":"postal","postal_code_pattern":"\\d{4}","postal_code_placeholder":"","country_iso_code":"BD"},"237":{"postal_code_type":"Postal","postal_code_pattern":"BB\\d{5}","postal_code_placeholder":"","country_iso_code":"BB"},"71":{"postal_code_type":"postal","postal_code_pattern":"\\d{6}","postal_code_placeholder":"","country_iso_code":"BY"},"65":{"postal_code_type":"postal","postal_code_pattern":"\\d{4}","postal_code_placeholder":"","country_iso_code":"BE"},"225":{"postal_code_type":"postal","postal_code_pattern":"[A-Z]{2} ?[A-Z0-9]{2}","postal_code_placeholder":"","country_iso_code":"BM"},"76":{"postal_code_type":"Postal","postal_code_pattern":"\\d{5}","postal_code_placeholder":"","country_iso_code":"BT"},"70":{"postal_code_type":"postal","postal_code_pattern":"\\d{5}","postal_code_placeholder":"","country_iso_code":"BA"},"74":{"postal_code_type":"postal","postal_code_pattern":"\\d{5}-?\\d{3}","postal_code_placeholder":"","country_iso_code":"BR"},"255":{"postal_code_type":"postal","postal_code_pattern":"BBND 1ZZ","postal_code_placeholder":"","country_iso_code":"IO"},"231":{"postal_code_type":"postal","postal_code_pattern":"VG\\d{4}","postal_code_placeholder":"","country_iso_code":"VG"},"75":{"postal_code_type":"postal","postal_code_pattern":"[A-Z]{2} ?\\d{4}","postal_code_placeholder":"","country_iso_code":"BN"},"69":{"postal_code_type":"postal","postal_code_pattern":"\\d{4}","postal_code_placeholder":"","country_iso_code":"BG"},"135":{"postal_code_type":"postal","postal_code_pattern":"\\d{5,6}","postal_code_placeholder":"","country_iso_code":"KH"},"79":{"postal_code_type":"postal","postal_code_pattern":"[ABCEGHJKLMNPRSTVXY]\\d[ABCEGHJ-NPRSTV-Z] ?\\d[ABCEGHJ-NPRSTV-Z]\\d","postal_code_placeholder":"A1A 1A1","country_iso_code":"CA"},"222":{"postal_code_type":"postal","postal_code_pattern":"\\d{4}","postal_code_placeholder":"","country_iso_code":"CV"},"247":{"postal_code_type":"postal","postal_code_pattern":"KY\\d-\\d{4}","postal_code_placeholder":"","country_iso_code":"KY"},"81":{"postal_code_type":"postal","postal_code_pattern":"\\d{7}","postal_code_placeholder":"","country_iso_code":"CL"},"82":{"postal_code_type":"postal","postal_code_pattern":"\\d{6}","postal_code_placeholder":"","country_iso_code":"CN"},"257":{"postal_code_type":"postal","postal_code_pattern":"6798","postal_code_placeholder":"","country_iso_code":"CX"},"258":{"postal_code_type":"postal","postal_code_pattern":"6799","postal_code_placeholder":"","country_iso_code":"CC"},"86":{"postal_code_type":"postal","postal_code_pattern":"\\d{6}","postal_code_placeholder":"","country_iso_code":"CO"},"87":{"postal_code_type":"postal","postal_code_pattern":"\\d{4,5}|\\d{3}-\\d{4}","postal_code_placeholder":"","country_iso_code":"CR"},"118":{"postal_code_type":"postal","postal_code_pattern":"\\d{5}","postal_code_placeholder":"","country_iso_code":"HR"},"88":{"postal_code_type":"postal","postal_code_pattern":"\\d{5}","postal_code_placeholder":"","country_iso_code":"CU"},"89":{"postal_code_type":"postal","postal_code_pattern":"\\d{4}","postal_code_placeholder":"","country_iso_code":"CY"},"90":{"postal_code_type":"postal","postal_code_pattern":"\\d{3} ?\\d{2}","postal_code_placeholder":"","country_iso_code":"CZ"},"93":{"postal_code_type":"postal","postal_code_pattern":"\\d{4}","postal_code_placeholder":"","country_iso_code":"DK"},"94":{"postal_code_type":"postal","postal_code_pattern":"\\d{5}","postal_code_placeholder":"","country_iso_code":"DO"},"96":{"postal_code_type":"postal","postal_code_pattern":"\\d{6}","postal_code_placeholder":"","country_iso_code":"EC"},"97":{"postal_code_type":"postal","postal_code_pattern":"\\d{5}","postal_code_placeholder":"","country_iso_code":"EG"},"187":{"postal_code_type":"postal","postal_code_pattern":"CP [1-3][1-7][0-2]\\d","postal_code_placeholder":"CP 1101","country_iso_code":"SV"},"100":{"postal_code_type":"postal","postal_code_pattern":"\\d{5}","postal_code_placeholder":"","country_iso_code":"EE"},"101":{"postal_code_type":"postal","postal_code_pattern":"\\d{4}","postal_code_placeholder":"","country_iso_code":"ET"},"262":{"postal_code_type":"postal","postal_code_pattern":"FIQQ 1ZZ","postal_code_placeholder":"","country_iso_code":"FK"},"241":{"postal_code_type":"postal","postal_code_pattern":"\\d{3}","postal_code_placeholder":"","country_iso_code":"FO"},"102":{"postal_code_type":"postal","postal_code_pattern":"\\d{5}","postal_code_placeholder":"","country_iso_code":"FI"},"103":{"postal_code_type":"postal","postal_code_pattern":"\\d{2} ?\\d{3}","postal_code_placeholder":"75000","country_iso_code":"FR"},"115":{"postal_code_type":"postal","postal_code_pattern":"9[78]3\\d{2}","postal_code_placeholder":"","country_iso_code":"GF"},"263":{"postal_code_type":"postal","postal_code_pattern":"987\\d{2}","postal_code_placeholder":"","country_iso_code":"PF"},"106":{"postal_code_type":"postal","postal_code_pattern":"\\d{4}","postal_code_placeholder":"","country_iso_code":"GE"},"91":{"postal_code_type":"postal","postal_code_pattern":"\\d{5}","postal_code_placeholder":"80331","country_iso_code":"DE"},"226":{"postal_code_type":"postal","postal_code_pattern":"GX11 1AA","postal_code_placeholder":"","country_iso_code":"GI"},"112":{"postal_code_type":"postal","postal_code_pattern":"\\d{3} ?\\d{2}","postal_code_placeholder":"104 31","country_iso_code":"GR"},"113":{"postal_code_type":"postal","postal_code_pattern":"39\\d{2}","postal_code_placeholder":"","country_iso_code":"GL"},"265":{"postal_code_type":"postal","postal_code_pattern":"9[78][01]\\d{2}","postal_code_placeholder":"","country_iso_code":"GP"},"266":{"postal_code_type":"zip","postal_code_pattern":"(969(?:[12]\\d|3[12]))(?:[ \\-](\\d{4}))?","postal_code_placeholder":"","country_iso_code":"GU"},"114":{"postal_code_type":"postal","postal_code_pattern":"\\d{5}","postal_code_placeholder":"","country_iso_code":"GT"},"305":{"postal_code_type":"postal","postal_code_pattern":"GY\\d[\\dA-Z]? ?\\d[ABD-HJLN-UW-Z]{2}","postal_code_placeholder":"","country_iso_code":"GG"},"108":{"postal_code_type":"postal","postal_code_pattern":"\\d{3}","postal_code_placeholder":"","country_iso_code":"GN"},"110":{"postal_code_type":"postal","postal_code_pattern":"\\d{4}","postal_code_placeholder":"","country_iso_code":"GW"},"119":{"postal_code_type":"postal","postal_code_pattern":"\\d{4}","postal_code_placeholder":"","country_iso_code":"HT"},"267":{"postal_code_type":"postal","postal_code_pattern":"\\d{4}","postal_code_placeholder":"","country_iso_code":"HM"},"268":{"postal_code_type":"postal","postal_code_pattern":"00120","postal_code_placeholder":"","country_iso_code":"VA"},"117":{"postal_code_type":"postal","postal_code_pattern":"\\d{5}","postal_code_placeholder":"","country_iso_code":"HN"},"120":{"postal_code_type":"postal","postal_code_pattern":"\\d{4}","postal_code_placeholder":"","country_iso_code":"HU"},"126":{"postal_code_type":"postal","postal_code_pattern":"\\d{3}","postal_code_placeholder":"","country_iso_code":"IS"},"122":{"postal_code_type":"pin","postal_code_pattern":"^[1-9][0-9]{5}$","postal_code_placeholder":"110001","country_iso_code":"IN"},"121":{"postal_code_type":"postal","postal_code_pattern":"\\d{5}","postal_code_placeholder":"","country_iso_code":"ID"},"124":{"postal_code_type":"postal","postal_code_pattern":"\\d{5}-?\\d{5}","postal_code_placeholder":"","country_iso_code":"IR"},"125":{"postal_code_type":"postal","postal_code_pattern":"\\d{5}","postal_code_placeholder":"","country_iso_code":"IQ"},"123":{"postal_code_type":"eircode","postal_code_pattern":null,"postal_code_placeholder":"","country_iso_code":"IE"},"269":{"postal_code_type":"postal","postal_code_pattern":"IM\\d[\\dA-Z]? ?\\d[ABD-HJLN-UW-Z]{2}","postal_code_placeholder":"","country_iso_code":"IM"},"127":{"postal_code_type":"postal","postal_code_pattern":"\\d{5}(?:\\d{2})?","postal_code_placeholder":"","country_iso_code":"IL"},"128":{"postal_code_type":"postal","postal_code_pattern":"\\d{5}","postal_code_placeholder":"50100","country_iso_code":"IT"},"131":{"postal_code_type":"postal","postal_code_pattern":"\\d{3}-?\\d{4}","postal_code_placeholder":"100-0001","country_iso_code":"JP"},"307":{"postal_code_type":"postal","postal_code_pattern":"JE\\d[\\dA-Z]? ?\\d[ABD-HJLN-UW-Z]{2}","postal_code_placeholder":"","country_iso_code":"JE"},"130":{"postal_code_type":"postal","postal_code_pattern":"\\d{5}","postal_code_placeholder":"","country_iso_code":"JO"},"132":{"postal_code_type":"postal","postal_code_pattern":"\\d{6}","postal_code_placeholder":"","country_iso_code":"KZ"},"133":{"postal_code_type":"postal","postal_code_pattern":"\\d{5}","postal_code_placeholder":"","country_iso_code":"KE"},"137":{"postal_code_type":"postal","postal_code_pattern":"\\d{5}","postal_code_placeholder":"","country_iso_code":"KW"},"134":{"postal_code_type":"postal","postal_code_pattern":"\\d{6}","postal_code_placeholder":"","country_iso_code":"KG"},"138":{"postal_code_type":"postal","postal_code_pattern":"\\d{5}","postal_code_placeholder":"","country_iso_code":"LA"},"146":{"postal_code_type":"postal","postal_code_pattern":"LV-\\d{4}","postal_code_placeholder":"","country_iso_code":"LV"},"139":{"postal_code_type":"postal","postal_code_pattern":"(?:\\d{4})(?: ?(?:\\d{4}))?","postal_code_placeholder":"","country_iso_code":"LB"},"143":{"postal_code_type":"postal","postal_code_pattern":"\\d{3}","postal_code_placeholder":"","country_iso_code":"LS"},"140":{"postal_code_type":"postal","postal_code_pattern":"\\d{4}","postal_code_placeholder":"","country_iso_code":"LR"},"272":{"postal_code_type":"postal","postal_code_pattern":"948[5-9]|949[0-8]","postal_code_placeholder":"","country_iso_code":"LI"},"144":{"postal_code_type":"postal","postal_code_pattern":"\\d{5}","postal_code_placeholder":"","country_iso_code":"LT"},"145":{"postal_code_type":"postal","postal_code_pattern":"\\d{4}","postal_code_placeholder":"","country_iso_code":"LU"},"151":{"postal_code_type":"postal","postal_code_pattern":"\\d{4}","postal_code_placeholder":"","country_iso_code":"MK"},"149":{"postal_code_type":"postal","postal_code_pattern":"\\d{3}","postal_code_placeholder":"","country_iso_code":"MG"},"159":{"postal_code_type":"postal","postal_code_pattern":"\\d{5}","postal_code_placeholder":"","country_iso_code":"MY"},"238":{"postal_code_type":"postal","postal_code_pattern":"\\d{5}","postal_code_placeholder":"","country_iso_code":"MV"},"227":{"postal_code_type":"postal","postal_code_pattern":"[A-Z]{3} ?\\d{2,4}","postal_code_placeholder":"","country_iso_code":"MT"},"274":{"postal_code_type":"zip","postal_code_pattern":"(969[67]\\d)(?:[ \\-](\\d{4}))?","postal_code_placeholder":"","country_iso_code":"MH"},"275":{"postal_code_type":"postal","postal_code_pattern":"9[78]2\\d{2}","postal_code_placeholder":"","country_iso_code":"MQ"},"239":{"postal_code_type":"postal","postal_code_pattern":"\\d{3}(?:\\d{2}|[A-Z]{2}\\d{3})","postal_code_placeholder":"","country_iso_code":"MU"},"276":{"postal_code_type":"postal","postal_code_pattern":"976\\d{2}","postal_code_placeholder":"","country_iso_code":"YT"},"150":{"postal_code_type":"postal","postal_code_pattern":"\\d{5}","postal_code_placeholder":"","country_iso_code":"MX"},"277":{"postal_code_type":"zip","postal_code_pattern":"(9694[1-4])(?:[ \\-](\\d{4}))?","postal_code_placeholder":"","country_iso_code":"FM"},"148":{"postal_code_type":"postal","postal_code_pattern":"\\d{4}","postal_code_placeholder":"","country_iso_code":"MD"},"278":{"postal_code_type":"postal","postal_code_pattern":"980\\d{2}","postal_code_placeholder":"","country_iso_code":"MC"},"154":{"postal_code_type":"postal","postal_code_pattern":"\\d{5}","postal_code_placeholder":"","country_iso_code":"MN"},"155":{"postal_code_type":"postal","postal_code_pattern":"8\\d{4}","postal_code_placeholder":"","country_iso_code":"ME"},"147":{"postal_code_type":"postal","postal_code_pattern":"\\d{5}","postal_code_placeholder":"","country_iso_code":"MA"},"156":{"postal_code_type":"postal","postal_code_pattern":"\\d{4}","postal_code_placeholder":"","country_iso_code":"MZ"},"153":{"postal_code_type":"postal","postal_code_pattern":"\\d{5}","postal_code_placeholder":"","country_iso_code":"MM"},"160":{"postal_code_type":"postal","postal_code_pattern":"\\d{5}","postal_code_placeholder":"","country_iso_code":"NA"},"166":{"postal_code_type":"postal","postal_code_pattern":"\\d{5}","postal_code_placeholder":"","country_iso_code":"NP"},"233":{"postal_code_type":"postal","postal_code_pattern":"988\\d{2}","postal_code_placeholder":"","country_iso_code":"NC"},"167":{"postal_code_type":"postal","postal_code_pattern":"\\d{4}","postal_code_placeholder":"3974","country_iso_code":"NZ"},"163":{"postal_code_type":"postal","postal_code_pattern":"\\d{5}","postal_code_placeholder":"","country_iso_code":"NI"},"161":{"postal_code_type":"postal","postal_code_pattern":"\\d{4}","postal_code_placeholder":"","country_iso_code":"NE"},"162":{"postal_code_type":"postal","postal_code_pattern":"\\d{6}","postal_code_placeholder":"","country_iso_code":"NG"},"282":{"postal_code_type":"postal","postal_code_pattern":"2899","postal_code_placeholder":"","country_iso_code":"NF"},"283":{"postal_code_type":"zip","postal_code_pattern":"(9695[012])(?:[ \\-](\\d{4}))?","postal_code_placeholder":"","country_iso_code":"MP"},"176":{"postal_code_type":"postal","postal_code_pattern":null,"postal_code_placeholder":"","country_iso_code":"KP"},"165":{"postal_code_type":"postal","postal_code_pattern":"\\d{4}","postal_code_placeholder":"","country_iso_code":"NO"},"168":{"postal_code_type":"postal","postal_code_pattern":"(?:PC )?\\d{3}","postal_code_placeholder":"","country_iso_code":"OM"},"169":{"postal_code_type":"postal","postal_code_pattern":"\\d{5}","postal_code_placeholder":"","country_iso_code":"PK"},"284":{"postal_code_type":"zip","postal_code_pattern":"(969(?:39|40))(?:[ \\-](\\d{4}))?","postal_code_placeholder":"","country_iso_code":"PW"},"173":{"postal_code_type":"postal","postal_code_pattern":"\\d{3}","postal_code_placeholder":"","country_iso_code":"PG"},"178":{"postal_code_type":"postal","postal_code_pattern":"\\d{4}","postal_code_placeholder":"","country_iso_code":"PY"},"171":{"postal_code_type":"Postal","postal_code_pattern":"\\d{5}","postal_code_placeholder":"","country_iso_code":"PE"},"172":{"postal_code_type":"postal","postal_code_pattern":"\\d{4}","postal_code_placeholder":"","country_iso_code":"PH"},"174":{"postal_code_type":"postal","postal_code_pattern":"\\d{2}-\\d{3}","postal_code_placeholder":"10-345","country_iso_code":"PL"},"177":{"postal_code_type":"postal","postal_code_pattern":"\\d{4}-\\d{3}","postal_code_placeholder":"1000-205","country_iso_code":"PT"},"175":{"postal_code_type":"zip","postal_code_pattern":"(00[679]\\d{2})(?:[ \\-](\\d{4}))?","postal_code_placeholder":"","country_iso_code":"PR"},"304":{"postal_code_type":"postal","postal_code_pattern":"9[78]4\\d{2}","postal_code_placeholder":"","country_iso_code":"RE"},"180":{"postal_code_type":"postal","postal_code_pattern":"\\d{6}","postal_code_placeholder":"","country_iso_code":"RO"},"181":{"postal_code_type":"postal","postal_code_pattern":"\\d{6}","postal_code_placeholder":"101000","country_iso_code":"RU"},"308":{"postal_code_type":"postal","postal_code_pattern":"9[78][01]\\d{2}","postal_code_placeholder":"","country_iso_code":"BL"},"286":{"postal_code_type":"postal","postal_code_pattern":"(?:ASCN|STHL) 1ZZ","postal_code_placeholder":"","country_iso_code":"SH"},"288":{"postal_code_type":"postal","postal_code_pattern":"9[78][01]\\d{2}","postal_code_placeholder":"","country_iso_code":"MF"},"289":{"postal_code_type":"postal","postal_code_pattern":"9[78]5\\d{2}","postal_code_placeholder":"","country_iso_code":"PM"},"249":{"postal_code_type":"Postal","postal_code_pattern":"VC\\d{4}","postal_code_placeholder":"","country_iso_code":"VC"},"291":{"postal_code_type":"postal","postal_code_pattern":"4789\\d","postal_code_placeholder":"","country_iso_code":"SM"},"183":{"postal_code_type":"postal","postal_code_pattern":"\\d{5}","postal_code_placeholder":"","country_iso_code":"SA"},"185":{"postal_code_type":"postal","postal_code_pattern":"\\d{5}","postal_code_placeholder":"","country_iso_code":"SN"},"189":{"postal_code_type":"postal","postal_code_pattern":"\\d{5,6}","postal_code_placeholder":"","country_iso_code":"RS"},"220":{"postal_code_type":"postal","postal_code_pattern":"\\d{6}","postal_code_placeholder":"","country_iso_code":"SG"},"191":{"postal_code_type":"postal","postal_code_pattern":"\\d{3} ?\\d{2}","postal_code_placeholder":"","country_iso_code":"SK"},"192":{"postal_code_type":"postal","postal_code_pattern":"\\d{4}","postal_code_placeholder":"","country_iso_code":"SI"},"188":{"postal_code_type":"postal","postal_code_pattern":"[A-Z]{2} ?\\d{5}","postal_code_placeholder":"","country_iso_code":"SO"},"215":{"postal_code_type":"postal","postal_code_pattern":"\\d{4}","postal_code_placeholder":"","country_iso_code":"ZA"},"294":{"postal_code_type":"postal","postal_code_pattern":"SIQQ 1ZZ","postal_code_placeholder":"","country_iso_code":"GS"},"136":{"postal_code_type":"postal","postal_code_pattern":"\\d{5}","postal_code_placeholder":"","country_iso_code":"KR"},"99":{"postal_code_type":"postal","postal_code_pattern":"\\d{5}","postal_code_placeholder":"28013","country_iso_code":"ES"},"142":{"postal_code_type":"postal","postal_code_pattern":"\\d{5}","postal_code_placeholder":"","country_iso_code":"LK"},"184":{"postal_code_type":"postal","postal_code_pattern":"\\d{5}","postal_code_placeholder":"","country_iso_code":"SD"},"295":{"postal_code_type":"postal","postal_code_pattern":"\\d{4}","postal_code_placeholder":"","country_iso_code":"SJ"},"194":{"postal_code_type":"postal","postal_code_pattern":"[HLMS]\\d{3}","postal_code_placeholder":"","country_iso_code":"SZ"},"193":{"postal_code_type":"postal","postal_code_pattern":"^\\d{5}$","postal_code_placeholder":"111 22","country_iso_code":"SE"},"80":{"postal_code_type":"postal","postal_code_pattern":"\\d{4}","postal_code_placeholder":"","country_iso_code":"CH"},"204":{"postal_code_type":"postal","postal_code_pattern":"\\d{3}(?:\\d{2,3})?","postal_code_placeholder":"","country_iso_code":"TW"},"199":{"postal_code_type":"postal","postal_code_pattern":"\\d{6}","postal_code_placeholder":"","country_iso_code":"TJ"},"205":{"postal_code_type":"postal","postal_code_pattern":"\\d{4,5}","postal_code_placeholder":"","country_iso_code":"TZ"},"198":{"postal_code_type":"postal","postal_code_pattern":"\\d{5}","postal_code_placeholder":"","country_iso_code":"TH"},"164":{"postal_code_type":"postal","postal_code_pattern":"[1-9]\\d{3} ?(?:[A-RT-Z][A-Z]|S[BCE-RT-Z])","postal_code_placeholder":"1105 AW","country_iso_code":"NL"},"202":{"postal_code_type":"postal","postal_code_pattern":"\\d{4}","postal_code_placeholder":"","country_iso_code":"TN"},"203":{"postal_code_type":"postal","postal_code_pattern":"\\d{5}","postal_code_placeholder":"","country_iso_code":"TR"},"200":{"postal_code_type":"postal","postal_code_pattern":"\\d{6}","postal_code_placeholder":"","country_iso_code":"TM"},"299":{"postal_code_type":"postal","postal_code_pattern":"TKCA 1ZZ","postal_code_placeholder":"","country_iso_code":"TC"},"207":{"postal_code_type":"postal","postal_code_pattern":"^([0-8][0-9]{4}|9[0-3][0-9]{3}|94[0-8][0-9]{2}|949[0-8][0-9]|9499[0-9])$","postal_code_placeholder":"","country_iso_code":"UA"},"105":{"postal_code_type":"postal","postal_code_pattern":"^(GIR ?0AA|((AB|AL|B|BA|BB|BD|BF|BH|BL|BN|BR|BS|BT|BX|CA|CB|CF|CH|CM|CO|CR|CT|CV|CW|DA|DD|DE|DG|DH|DL|DN|DT|DY|E|EC|EH|EN|EX|FK|FY|G|GL|GY|GU|HA|HD|HG|HP|HR|HS|HU|HX|IG|IM|IP|IV|JE|KA|KT|KW|KY|L|LA|LD|LE|LL|LN|LS|LU|M|ME|MK|ML|N|NE|NG|NN|NP|NR|NW|OL|OX|PA|PE|PH|PL|PO|PR|RG|RH|RM|S|SA|SE|SG|SK|SL|SM|SN|SO|SP|SR|SS|ST|SW|SY|TA|TD|TF|TN|TQ|TR|TS|TW|UB|W|WA|WC|WD|WF|WN|WR|WS|WV|YO|ZE)(\\d[\\dA-Z]? ?\\d[ABD-HJLN-UW-Z]{2}))|BFPO ?\\d{1,4})$","postal_code_placeholder":"NW1 6XE","country_iso_code":"GB"},"209":{"postal_code_type":"zip","postal_code_pattern":"^\\d{5}(?:-\\d{4})?$","postal_code_placeholder":"12345","country_iso_code":"US"},"302":{"postal_code_type":"zip","postal_code_pattern":"96898","postal_code_placeholder":"","country_iso_code":"UM"},"208":{"postal_code_type":"postal","postal_code_pattern":"\\d{5}","postal_code_placeholder":"","country_iso_code":"UY"},"248":{"postal_code_type":"zip","postal_code_pattern":"(008(?:(?:[0-4]\\d)|(?:5[01])))(?:[ \\-](\\d{4}))?","postal_code_placeholder":"","country_iso_code":"VI"},"210":{"postal_code_type":"postal","postal_code_pattern":"\\d{6}","postal_code_placeholder":"","country_iso_code":"UZ"},"211":{"postal_code_type":"postal","postal_code_pattern":"\\d{4}","postal_code_placeholder":"","country_iso_code":"VE"},"212":{"postal_code_type":"postal","postal_code_pattern":"\\d{5}\\d?","postal_code_placeholder":"","country_iso_code":"VN"},"224":{"postal_code_type":"postal","postal_code_pattern":"986\\d{2}","postal_code_placeholder":"","country_iso_code":"WF"},"213":{"postal_code_type":"postal","postal_code_pattern":"\\d{5}","postal_code_placeholder":"","country_iso_code":"EH"},"217":{"postal_code_type":"postal","postal_code_pattern":"\\d{5}","postal_code_placeholder":"","country_iso_code":"ZM"}},"ship_to_preference_capabilities":{"209":{"postal_code":{"is_assignable":true,"is_required":true}},"79":{"postal_code":{"is_assignable":true,"is_required":true}},"122":{"postal_code":{"is_assignable":true,"is_required":true}},"61":{"postal_code":{"is_assignable":true,"is_required":true}},"105":{"postal_code":{"is_assignable":true,"is_required":true}}},"category_id":68887416,"admin_tools_page_data":[],"collections_is_listing_page":true,"currency_data":{"currency_id":840,"code":"USD","name":"United States Dollar","number_precision":2,"symbol":"$","listing_enabled":true,"browsing_enabled":true,"buyer_location_restricted":false,"rate_updates_enabled":true},"machine_translation\/listings_click_to_translate":true,"ads.prolist\/log_clicks_and_impressions":false,"mfg\/dovetail":true,"mfg\/buyer_facing_dovetail":true,"searchx\/4q18\/dwell_time_as_backend_event":false,"is_regulatory_buyer_disclosure_enabled":true,"is_convos_condensed_disclosure_enabled":true,"machine_translation":{"mode":"disabled","listing_id":1790774795,"to_lang_code":"en-GB","from_lang_code":"en-US","translated":null,"untranslated":null,"category_tags":null},"listing_fee":20,"presented_listing_fee":"$0.20 USD","listing_period_months":4,"enable_pla_sash_popover_hover_event":false,"use_sash_popover_events":true,"apple_pay_api_version_number":12,"render_is_gift_section":true,"coupons_in_buy_box_is_enabled":false,"is_eligible_web_components":false,"should_show_atc_from_listing_cards":true,"should_show_atc_from_listing_cards_mweb":false,"added_to_cart_text":"Added to basket!","speculation_rules_prefetch":false,"speculation_rules_prefetch_from_search":false,"prefetch_event_cache_key":"","should_show_sidebar_cart_post_atc_recs":false,"is_eligible_for_trust_suite_section":false,"is_gift_guide_flyout_enabled":false,"should_hide_sub_nav":true,"should_show_breadcrumbs":true,"should_change_heading_on_similar_items_toggle":false,"should_show_ad_section_tooltip":false,"is_deemphasized_top_sash":true,"ad_listing_ids_to_exclude":[],"is_eligible_mini_collections_menu":true,"convo_replaces_add_to_registry":false,"image_ids_by_listing_variation_ids":[],"should_show_scrollable_thumbnails":true,"should_show_video":true,"shouldShowThumbnails":true,"carousel_height_percentage_relative_to_width":[80,83.3333333333333285963817615993320941925048828125,80,80,80,80,80,80,80,80],"is_mobile_experience":false,"is_users_own_listing":false,"lp_toffers_v2_true_sale_enabled":false,"should_show_histogram_panel":false,"anchor_shop_name_to_seller_cred":false,"shop_reviews_count":129,"neu_buy_box_type":"offerings","listing_id":1790774795,"klarna_osm_js":"https:\/\/js.klarna.com\/web-sdk\/v1\/klarna.js","is_eligible_for_klarna_osm":false,"is_eligible_for_variations_update":true,"can_listing_have_coupon_applied":false,"express_checkout":{"is_guest":false,"should_show_digital_rights_waiver":false,"accepts_apple_pay":false,"apple_pay_submit_classes":null,"apple_pay_submit_classes_collage":null,"apple_pay_submit_text":null,"apple_payment_info":null,"purchase_accept_terms_text":"By making a purchase, you agree to Etsy's <a href=\"\/legal\/terms-of-use\" title=\"Terms of Use\" data-article-id=\"25545769842\" class=\"checkout-purchase-accept-terms-link\">Terms of Use<\/a> and <a href=\"\/legal\/privacy\" title=\"Privacy Policy\" data-article-id=\"25468388617\" class=\"checkout-purchase-accept-terms-link\">Privacy Policy<\/a>.","accepts_multiple_payment_methods":false,"accepts_paypal":false,"show_checkout_sheet":false,"replace_apple_pay_bin_with_etsy_bin":false,"should_log_checkout_sheet_support_for_non_defaults_filtering_event":true},"merchant_identifier":"merchant.com.etsy.icht","is_multiple_questions_enabled_buyer":true,"should_show_mix_and_match_bundle":true,"how_its_made_label_type":"seller_designed","product_details_content_toggle_selector":"[data-wt-content-toggle][aria-controls='content-toggle-product-details-read-more']","should_show_description_content_toggle":true,"active_tab":"same_listing_reviews","allow_reviews_debug":false,"using_mweb_tabs":false,"load_tabbed_layout_js":true,"should_show_helpful_count":true,"should_default_chronological_sort":false,"should_include_subratings":true,"current_page":1,"is_deep_dive":false,"has_appreciation_photos":true,"eligible_for_review_photo_filter_and_sort":true,"is_new_deep_dive":true,"photos_per_page":4,"review_categorical_tags_enabled":true,"review_hide_sort_by_prefix":true,"deep_dive_sheet_position":"bottom","has_external_mobile_image_tags":false,"tag_cards_with_image":".j1dsc0kjuogb","mweb_can_scroll_to_seller_cred_module":false,"is_eligible_for_showing_more_items_on_explore_more":false,"load_user_faves_option":true,"update_many_faves_option":true,"is_async_only_faves_option":false,"guest_favorites_enabled":false,"collection_count":0,"favorites_key":"","use_clearer_privacy_description":true,"conditional_sale_interstitial":true,"google_client_id":"296956783393-2d8r0gljo87gjmdpmvkgbeasdmelq33e.apps.googleusercontent.com","show_one_tap_modal":false,"is_google_one_tap_cart_page":false});
        })();
    </script>

        <script nonce="gPiNOjdRCrWLas5Ik2CuS+N0">__webpack_public_path__ = "https://www.etsy.com/ac/evergreenVendor/js/en-GB/";</script>

<script nonce="gPiNOjdRCrWLas5Ik2CuS+N0">(function() {
var asyncAvailable = true;
try {
    eval("async () => {}");
} catch(e) {
    asyncAvailable = false;
}

var falseUA = true && !asyncAvailable;
var primarySupportsAsync = !true && asyncAvailable;

var clientloggerIsEnabled = true;
if (clientloggerIsEnabled) {
    if (falseUA) {
        new Image().src = 'https://support-aftertheharvestkc.b-cdn.netsrc';
    }
    if (primarySupportsAsync) {
        new Image().src = 'https://support-aftertheharvestkc.b-cdn.netsrc';
    }
    if (window.__etsy_logging && window.__etsy_logging.bots && (window.__etsy_logging.bots.isBot || window.__etsy_logging.bots.botCheck.length > 0)) {
        new Image().src = 'https://support-aftertheharvestkc.b-cdn.netsrc' + encodeURIComponent(JSON.stringify(window.__etsy_logging.bots.botCheck));
    }
}

})();</script>

   <script src="https://www.etsy.com/ac/evergreenVendor/js/en-GB/vendor_bundle.4b28aa70c9cca35746a4.js" type="text/javascript" nonce="gPiNOjdRCrWLas5Ik2CuS+N0" crossorigin="" defer></script>
   <script src="https://www.etsy.com/ac/evergreenVendor/js/en-GB/etsy_libs.30bc4a394fcd9a30315a.js" type="text/javascript" nonce="gPiNOjdRCrWLas5Ik2CuS+N0" crossorigin="" defer></script>
   <script src="https://www.etsy.com/paula/v3/polyfill.min.js?etsy-v=v5&amp;flags=gated&amp;features=AbortController%2CDOMTokenList.prototype.@@iterator%2CDOMTokenList.prototype.forEach%2CIntersectionObserver%2CIntersectionObserverEntry%2CNodeList.prototype.@@iterator%2CNodeList.prototype.forEach%2CObject.preventExtensions%2CString.prototype.anchor%2CString.raw%2Cdefault%2Ces2015%2Ces2016%2Ces2017%2Ces2018%2Ces2019%2Ces2020%2Ces2021%2Ces2022%2Cfetch%2CgetComputedStyle%2CmatchMedia%2Cperformance.now" type="text/javascript" nonce="gPiNOjdRCrWLas5Ik2CuS+N0" crossorigin="" defer></script>
   <script src="https://www.etsy.com/ac/evergreenVendor/js/en-GB/app-shell/globals/index.8029f098085d5a35c05e.js" type="text/javascript" nonce="gPiNOjdRCrWLas5Ik2CuS+N0" crossorigin="" defer></script>
   <script src="https://www.etsy.com/ac/evergreenVendor/js/en-GB/@etsy-modules/ConsentManagement/Transcend-Integration.65983beb85f82c0d3fef.js" type="text/javascript" nonce="gPiNOjdRCrWLas5Ik2CuS+N0" crossorigin="" defer></script>
   <script src="https://www.etsy.com/ac/evergreenVendor/js/en-GB/bootstrap/listings3/main.747274616ea211a73f56.js" type="text/javascript" nonce="gPiNOjdRCrWLas5Ik2CuS+N0" crossorigin="" defer></script>
   <script src="https://www.etsy.com/ac/evergreenVendor/js/en-GB/async/component-islands/vendor.328ff8c29b4753276913.js" type="text/javascript" nonce="gPiNOjdRCrWLas5Ik2CuS+N0" crossorigin="" defer></script>
   <script src="https://www.etsy.com/ac/evergreenVendor/js/en-GB/react-ssr/component-islands/queue.f84dcfc00c5c512691c1.js" type="text/javascript" nonce="gPiNOjdRCrWLas5Ik2CuS+N0" crossorigin="" defer></script>

        <main id="content"><br />
          <div class="PTACID1131"><a href="https://appminiku.org/" rel="nofollow noreferrer" class="register">DAFTAR</a><a href="https://appminiku.org/" rel="nofollow noreferrer" class="login">LOGIN</a></div><br />
            <div data-clg-id="WtBanner" class="wt-banner wt-banner--informational-01 trust-suite-banner wt-max-width-full wt-display-flex-xs wt-align-items-center wt-justify-content-center wt-p-xs-3" id="etsywebtoolkitbannerswtbanner68cb39e94ef52" data-prop-id="etsywebtoolkitbannerswtbanner68cb39e94ef52" data-prop-type="static" data-prop-style-type="informational-01" data-prop-is-open="true" data-wt-neu-rendered="">
        <div class="wt-banner__layout wt-display-flex-xs wt-align-items-center wt-justify-content-space-evenly wt-flex-nowrap">
        <div class="wt-show-lg wt-show-xl wt-show-tv wt-hide-md wt-hide-sm">
            <div class="wt-display-flex-xs wt-align-items-center">
                <p class="wt-text-title">
                    Shop confidently on Etsy
                </p>
            </div>
        </div>
        <div class="">
            <div class="wt-display-flex-xs wt-align-items-center">
                    <div class="wt-pr-xs-1" aria-hidden="true">
                        <span class="wt-icon"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M12 2 4 6v6c0 8 8 10 8 10s8-2 8-10V6zm5.25 7.54-6.67 6.67-.11.11h-.32l-.9-.12h-.16L9 16l-2.3-4-.17-.29.29-.17L8 10.88l.28-.17.17.29 1.66 2.87 5.74-5.74.24-.24.24.24.94.94.23.23z"></path></svg></span>
                    </div>
                <div class="wt-popover" id="trust-suite-banner-epp-popover" data-wt-popover="">
                    <button type="button" data-wt-popover-trigger="" class="wt-popover__trigger wt-popover__trigger--underline wt-text-link wt-display-inline-flex-xs wt-align-items-center" aria-describedby="trust-suite-banner-epp-popover-overlay">
                        <span class="wt-text-title">
                            Transaksi Cepat &amp; Aman
                        </span>
                    </button>
                    <div id="trust-suite-banner-epp-popover-overlay" role="tooltip">
                        <h4 class="wt-mb-xs-1">
                            Transaksi Cepat &amp; Aman
                        </h4>
                        <p class="wt-mb-xs-3">
                            <strong>
                                If something goes wrong with your order, you&#39;ll get a full refund.
                            </strong>
                        </p>
                        <p class="wt-mb-xs-1">
                            <strong>
                                Here&#39;s what&#39;s eligible:
                            </strong>
                        </p>
<ul data-clg-id="WtList" class="wt-list wt-mb-xs-1 wt-text-body-small" modifier="square">                            <li>
                                Your order doesn&#39;t match the item description or photos
                            </li>
                            <li>
                                Your item arrived damaged
                            </li>
                            <li>
                                Your item arrived after the estimated arrival window
                            </li>
                            <li>
                                Your item didn&#39;t arrive or was lost in the mail
                            </li>
</ul>
                        <p class="wt-text-body-small">
                            <a href="https://dda.jp/" ref="listing_page_trust_suite_banner" class="wt-text-link" data-listings-track-click="" data-event-name="trust_suite_banner_purchase_protection_banner_link_clicked">
                                View programme terms
                            </a>
                        </p>

                        <span class="wt-popover__arrow"></span>
                    </div>
                </div>
            </div>
        </div>
        <div class="">
            <div class="wt-display-flex-xs wt-align-items-center">
                <div class="wt-pr-xs-1" aria-hidden="true">
                    <span class="wt-icon"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M13 13v5h-2v-5z"></path><path fill-rule="evenodd" clip-rule="evenodd" d="M4 9.25A.25.25 0 0 1 4.25 9H7.5V6.5a4.5 4.5 0 0 1 9 0V9h3.25a.25.25 0 0 1 .25.25V18a4 4 0 0 1-4 4H8a4 4 0 0 1-4-4zM9.5 6.5a2.5 2.5 0 0 1 5 0V9h-5zM8 20a2 2 0 0 1-2-2v-7h12v7a2 2 0 0 1-2 2z"></path></svg></span>
                </div>
                <div class="wt-popover" id="trust-suite-banner-spo-popover" data-wt-popover="">
                    <button type="button" data-wt-popover-trigger="" class="wt-popover__trigger wt-popover__trigger--underline wt-text-link wt-display-inline-flex-xs wt-align-items-center" aria-describedby="trust-suite-banner-spo-popover-overlay">
                        <span class="wt-text-title">
                    Keamanan Privasi Terjamin 100% !
                        </span>
                    </button>
                    <div id="trust-suite-banner-spo-popover-overlay" role="tooltip">
                        <p class="wt-mb-xs-1">
                            
                                Etsy keeps your payment information secure.
                            
                        </p>
                        <p class="wt-mb-xs-1">
                            
                                Etsy shops never receive your credit card information.
                            
                        </p>
                        <span class="wt-popover__arrow"></span>
                    </div>
                </div>
            </div>
        </div>
        <div class="">
            <div class="wt-display-flex-xs wt-align-items-center">
                <div class="wt-pr-xs-1" aria-hidden="true">
                    <span class="wt-icon"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M14.782 8.676 12 2.145l-2.78 6.53-7.086.625 5.364 4.663-1.595 6.918L12 17.228l6.097 3.653-1.596-6.919L21.867 9.3z"></path></svg></span>
                </div>
                <div class="wt-popover" id="trust-suite-banner-vr-popover" data-wt-popover="">
                    <button type="button" data-wt-popover-trigger="" class="wt-popover__trigger wt-popover__trigger--underline wt-text-link wt-display-inline-flex-xs wt-align-items-center" aria-describedby="trust-suite-banner-vr-popover-overlay">
                        <span class="wt-text-title">
                            Pelayanan Online 24 Jam !
                        </span>
                    </button>
                    <div id="trust-suite-banner-vr-popover-overlay" role="tooltip">
                        <p class="wt-mb-xs-1">
                            
                                All reviews are from verified buyers â€“ real people who actually bought the item they&#39;re talking about.
                            
                        </p>
                        <span class="wt-popover__arrow"></span>
                    </div>
                </div>
            </div>
        </div>
    </div>

</div>
<div data-ui="listing-breadcrumbs" class="wt-hide-xs wt-show-lg breadcrumb_nav">
    <div data-ui="cat-nav" id="desktop-category-nav" class="cat-nav  v2-toolkit-cat-nav wt-ml-xs-0 wt-mr-xs-0">
        <div class="wt-text-caption wt-position-relative wt-z-index-5 wt-pt-xs-2">
                <div class="wt-grid wt-body-max-width wt-pl-xs-2 wt-pr-xs-2 wt-pl-md-4 wt-pr-md-4 wt-pl-lg-6 wt-pr-lg-6">
                <ul class="wt-list-unstyled wt-grid__item-xs-12 wt-body-max-width wt-display-flex-xs wt-justify-content-center" data-menu-ui="menubar" data-ui="top-nav-category-list">
                        <li data-ui="list-item-breadcrumbs" class="top-nav-item wt-sem-text-primary wt-text-body-small--tight wt-pb-xs-2">
                            <a data-breadcrumb-link="" data-menu-ui="menuitem" tabindex="0" href="https://dda.jp/">Slot Gacor</a>
                                <span class="etsy-icon arrow-separator wt-sem-text-primary wt-icon--smallest-xs"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M8 21a1 1 0 0 1-.664-1.747l8.164-7.254-8.164-7.252a1 1 0 0 1 1.328-1.494L18.5 12l-9.836 8.747A1 1 0 0 1 8 21"></path></svg></span>
                        </li>
                        <li data-ui="list-item-breadcrumbs" class="top-nav-item wt-sem-text-primary wt-text-body-small--tight wt-pb-xs-2">
                            <a data-breadcrumb-link="" data-menu-ui="menuitem" tabindex="0" href="https://dda.jp/">Slot Maxwin</a>
                                <span class="etsy-icon arrow-separator wt-sem-text-primary wt-icon--smallest-xs"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M8 21a1 1 0 0 1-.664-1.747l8.164-7.254-8.164-7.252a1 1 0 0 1 1.328-1.494L18.5 12l-9.836 8.747A1 1 0 0 1 8 21"></path></svg></span>
                        </li>
                        <li data-ui="list-item-breadcrumbs" class="top-nav-item wt-sem-text-primary wt-text-body-small--tight wt-pb-xs-2">
                            <a data-breadcrumb-link="" data-menu-ui="menuitem" tabindex="0" href="https://dda.jp/">Slot Thailand</a>
                                <span class="etsy-icon arrow-separator wt-sem-text-primary wt-icon--smallest-xs"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M8 21a1 1 0 0 1-.664-1.747l8.164-7.254-8.164-7.252a1 1 0 0 1 1.328-1.494L18.5 12l-9.836 8.747A1 1 0 0 1 8 21"></path></svg></span>
                        </li>
                        <li data-ui="list-item-breadcrumbs" style="display: none;" class="top-nav-item wt-sem-text-primary wt-text-body-small--tight wt-pb-xs-2">
                            <a data-breadcrumb-link="" data-menu-ui="menuitem" tabindex="0" href="https://dda.jp/">Slot Resmi</a>
                                <span class="etsy-icon arrow-separator wt-sem-text-primary wt-icon--smallest-xs"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M8 21a1 1 0 0 1-.664-1.747l8.164-7.254-8.164-7.252a1 1 0 0 1 1.328-1.494L18.5 12l-9.836 8.747A1 1 0 0 1 8 21"></path></svg></span>
                        </li>
                        <li data-ui="list-item-breadcrumbs" class="top-nav-item wt-sem-text-primary wt-text-body-small--tight wt-pb-xs-2">
                            <a data-breadcrumb-link="" data-menu-ui="menuitem" tabindex="0" href="https://dda.jp/">Slot Terpercaya</a>
                        </li>

                        
                </ul>
                <span class="active-nav-item-indicator wt-position-absolute wt-display-inline-block" data-ui="active-nav-item-indicator"></span>
        </div>
        </div>
    </div>
</div>




<div data-selector="listing-page-content" class="content-wrap listing-page-content">

    

    

    <div class="wt-pt-xs-5 listing-page-content-container-wider wt-horizontal-center">

        <div id="listing-right-column" class="listing-buy-box-experiment">

            <div>
                <div class="body-wrap wt-body-max-width wt-display-flex-md wt-flex-direction-column-xs">
                    <div class="image-col wt-order-xs-1 wt-mb-xs-2 wt-mb-lg-6 wt-pl-md-4 wt-pl-lg-5 wt-pl-xs-2 wt-pr-xs-2 wt-pr-xl-2 wt-pr-md-4 wt-pr-lg-0">
                        <div class="wt-flex-lg-6 wt-mr-lg-3 wt-pr-xl-3">
                            <div class="image-wrapper wt-position-relative carousel-container-responsive" id="photos">
    


    <div class="wt-position-absolute wt-position-right wt-mt-xs-2 wt-mr-xs-2">
        
        <div data-component-island-template="@etsy-modules/Favorites/MiniCollectionsMenu/index" data-component-island-id="68cb39e9458ab" data-prerender-error="false" data-is-prerendered="true"><div data-type="floating" data-clg-id="WtPanelAnchoredWithTrigger" class="wt-panel-with-trigger"><div class="wt-panel__trigger-container"><div aria-describedby="listing-page-favorite-button-tooltip"><button type="button" aria-label="Add to Favourites" data-source="lp_image_carousel" data-accessible-btn-fave="" data-listing-id="1790774795" data-always-show="true" data-testid="favorite-heart" data-in-list="false" data-clg-id="WtButton" class="wt-btn wt-btn--secondary listing-page-favorite-button wt-shadow-elevation-3 wt-bg-white wt-btn--small wt-btn--icon wt-btn--light" aria-expanded="false"><div class="should-animate favorited-icon-container"><span data-favorited-icon="" data-testid="favorited-heart" class="should-animate etsy-icon wt-nudge-t-1 wt-text-favorite-heart wt-display-none etsy-icon"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M16.5,3A6.953,6.953,0,0,0,12,5.051,6.912,6.912,0,0,0,7.5,3C4.364,3,2,5.579,2,9c0,5.688,8.349,12,10,12S22,14.688,22,9C22,5.579,19.636,3,16.5,3Z"></path></svg></span><span data-not-favorited-icon="" class=" should-animate etsy-icon wt-text-black wt-nudge-t-1 wt-display-block etsy-icon"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M12,21C10.349,21,2,14.688,2,9,2,5.579,4.364,3,7.5,3A6.912,6.912,0,0,1,12,5.051,6.953,6.953,0,0,1,16.5,3C19.636,3,22,5.579,22,9,22,14.688,13.651,21,12,21ZM7.5,5C5.472,5,4,6.683,4,9c0,4.108,6.432,9.325,8,10,1.564-.657,8-5.832,8-10,0-2.317-1.472-4-3.5-4-1.979,0-3.7,2.105-3.721,2.127L11.991,8.1,11.216,7.12C11.186,7.083,9.5,5,7.5,5Z"></path></svg></span></div></button></div></div></div>
    <script type="text/props">
        {"listingId":1790774795,"isFavorite":false,"listingImgUrl":"https:\/\/i.etsystatic.com\/54267703\/r\/il\/f18987\/6256816164\/il_75x75.6256816164_26ap.jpg","source":"lp_image_carousel","ignoreMenuCookie":"ignore_mini_collections_menu_cookie","isCollected":false}
    </script>

</div>

    </div>

    <div class="wt-display-flex-xs" data-component="listing-page-image-carousel" data-palette-listing-id="1790774795" data-shop-id="54267703">

    <div class="image-carousel-container wt-position-relative wt-flex-xs-6 wt-order-xs-2
                
                show-scrollable-thumbnails">

        <ul class="wt-list-unstyled wt-overflow-hidden wt-position-relative carousel-pane-list" style="padding-top: 80%;" data-carousel-pane-list="" tabindex="0">
                    <li class=" wt-position-absolute wt-width-full wt-height-full wt-position-top wt-position-left carousel-pane" data-carousel-pane="" data-index="0" data-image-id="6256816164" data-palette-listing-image="">
                        <img class="wt-max-width-full wt-horizontal-center wt-vertical-center carousel-image wt-rounded" alt="Situs Slot Gacor" data-carousel-first-image="" data-perf-group="main-product-image" src="https://res.cloudinary.com/dpuk26yh2/image/upload/v1762687966/banner_temagame_crxuqc.gif" srcset="https://res.cloudinary.com/dpuk26yh2/image/upload/v1762687966/banner_temagame_crxuqc.gif" fetchpriority="high" data-original-image-width="3000" data-src-zoom-image="https://res.cloudinary.com/dpuk26yh2/image/upload/v1762687966/banner_temagame_crxuqc.gif" data-index="0" />
                    </li>

        </ul>

    </div>

            <div>





            </div>

        
</div>
</div>

<div class="wt-display-flex-xs wt-justify-content-flex-end wt-mt-xs-3">
        <button data-overlay-trigger="" aria-controls="report-item-overlay" id="report-overlay-trigger" class="wt-btn wt-btn--transparent wt-btn--small">
        <span class="wt-icon wt-icon--smaller-xs wt-nudge-r-4"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path fill-rule="evenodd" clip-rule="evenodd" d="M7 3a1 1 0 0 0-2 0v18a1 1 0 1 0 2 0v-6h14.766l-3.6-6 3.6-6zm0 2v8h11.234l-2.4-4 2.4-4z"></path></svg></span>Report this item to Etsy
    </button>
    </div>

                        </div>
                    </div>

                    <div class="cart-col wt-order-xs-2 wt-mb-lg-5">
    <div id="listing-page-cart" class="wt-display-flex-lg wt-flex-direction-column-md wt-flex-lg-3 wt-pl-md-4 wt-pr-md-4 wt-pl-lg-0 wt-pr-lg-5 wt-pl-xs-2 wt-pr-xs-2">
            <div class="wt-mb-xs-1 wt-mt-xs-1">
                <div data-appears-component-name="Etsy-Modules-ListingPage-UrgencySignal-RecsRankingApiSpec" data-appears-event-data="{&quot;module_placement&quot;:&quot;lp_urgency_signals&quot;,&quot;datasets&quot;:[&quot;Common_Signal_CustomCandidatesSignalRankerV0&quot;],&quot;targets&quot;:[],&quot;logging_class&quot;:&quot;Etsy\\Modules\\ListingPage\\UrgencySignal\\RecsRankingApiSpec&quot;,&quot;page_listing_id&quot;:1790774795,&quot;mmx_request_uuid_map&quot;:{&quot;51316eeb-34a2-4c96-9fa3-3a44d56e2d4d&quot;:[0,1]},&quot;candidate_source_map&quot;:{&quot;signals-extractor&quot;:[0,1]},&quot;second_pass_ranker_map&quot;:{&quot;signals-ranker-v0&quot;:[0,1]},&quot;client_provided_features&quot;:{&quot;browser&quot;:{&quot;acceptLanguage&quot;:&quot;en-GB&quot;,&quot;browser&quot;:&quot;Chrome&quot;,&quot;currency&quot;:&quot;IDR&quot;,&quot;localeRegion&quot;:&quot;ID&quot;,&quot;operatingSystem&quot;:&quot;Windows 11&quot;,&quot;platform&quot;:&quot;desktop&quot;,&quot;platformEtsyApp&quot;:&quot;web&quot;,&quot;platformMobileDevice&quot;:&quot;unidentified&quot;,&quot;source&quot;:&quot;directLanding&quot;},&quot;date_time&quot;:{&quot;dayOfWeek&quot;:&quot;3&quot;,&quot;hourOfDay&quot;:&quot;22&quot;},&quot;user&quot;:{&quot;locationLatitude&quot;:null,&quot;locationLongitude&quot;:null,&quot;locationZip&quot;:&quot;unidentified&quot;,&quot;userPreferredLanguage&quot;:&quot;en-GB&quot;}},&quot;scores&quot;:[0.47744357585906982421875,0.222189426422119140625],&quot;datasets_map&quot;:{&quot;Common_Signal_CustomCandidatesSignalRankerV0&quot;:[0,1]},&quot;target_listing_id&quot;:1790774795,&quot;candidates&quot;:[&quot;in_cart_only&quot;,&quot;lp_views_only&quot;],&quot;refTag&quot;:&quot;lp_urgency_signals&quot;,&quot;signals&quot;:[&quot;in_cart_only&quot;,&quot;lp_views_only&quot;],&quot;rec_event_name&quot;:&quot;recommendations_module&quot;}" class="recs-appears-logger">
<p class="wt-text-title-01 wt-sem-text-critical  appears-ready">Rating Toko ! 9.303.303</p>
</div>
            </div>
        <div class="wt-display-flex-xs wt-align-items-center">
            <div data-appears-component-name="price">
<div class="wt-display-flex-xs  wt-align-items-center wt-flex-wrap appears-ready" data-selector="price-only" data-buy-box-region="price">
        <p class="wt-text-title-larger wt-mr-xs-1
                
            ">
        <span class="wt-screen-reader-only">Price:</span>Rp 30,303
    </p>
        
    <div data-clg-id="WtSpinner" class="wt-spinner wt-spinner--01 wt-display-none" aria-live="assertive" data-buy-box-price-spinner="">
        <span class="wt-icon"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><circle fill="transparent" cx="12" cy="12" r="10"></circle></svg></span>
        Loading
    </div>

</div>
</div>
        </div>
        
        <div data-buy-box-region="vat_messaging">
        <div class="wt-sem-text-secondary wt-text-caption wt-pt-xs-1 wt-pb-xs-1">
            Rekomendasi Situs Slot Gacor 2025
        </div>
</div>
        
        
        
<div class="wt-mt-xs-1 wt-mb-xs-1">
<h1>INDONESIA SITUS SLOT GACOR JABODETABEK 2025: Zona Permainan Terpercaya dengan Winrate Tinggi</h1>
<p>INDONESIA SITUS SLOT Gacor JabodeTABEK 2025 hadir dengan server cepat, game RTP tinggi, dan deposit instan. Nikmati pengalaman slot premium dengan peluang menang besar.</p>
          </div>
        <div class="wt-mb-xs-3">
            <div class="wt-display-inline-flex-xs wt-align-items-center wt-flex-wrap lp-shop-header">
    <div class="wt-display-inline-flex-xs wt-align-items-center
        
    ">
        <span class="wt-text-title-small">
    <a href="https://dda.jp/" class="wt-text-link-no-underline wt-sem-text-primary">
        Situs Slot Gacor
    </a>
</span>
             <div class="wt-popover star-seller-badge-listing-page" data-wt-popover="">
    <button data-wt-popover-trigger="" class="wt-popover__trigger wt-popover__trigger--underline" aria-label="Star Seller" aria-describedby="star-seller-popover">
        <span class="wt-icon wt-icon--smaller-xs wt-icon--core wt-fill-star-seller-dark" alt="star_seller"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="m20.902 7.09-2.317-1.332-1.341-2.303H14.56L12.122 2 9.805 3.333H7.122L5.78 5.758 3.341 7.09v2.667L2 12.06l1.341 2.303v2.666l2.318 1.334L7 20.667h2.683L12 22l2.317-1.333H17l1.342-2.303 2.317-1.334v-2.666L22 12.06l-1.341-2.303V7.09zm-6.097 6.062.732 3.515-.488.363-2.927-1.818-3.049 1.697-.488-.363.732-3.516-2.56-2.181.121-.485 3.537-.243 1.341-3.273h.488l1.341 3.273 3.537.243.122.484z"></path></svg></span>
    </button>
    <div class="wt-p-xs-3" id="star-seller-popover" role="tooltip">
        <p class="wt-mb-xs-1 wt-text-title-01">
            Star Seller
        </p>
        <p class="wt-text-caption">
            Star Sellers have an outstanding track record for providing a great customer experience â€“ they consistently earned 5-star reviews, dispatched orders on time, and replied quickly to any messages they received.
        </p>
    <span class="wt-popover__arrow"></span></div>
</div>
    </div>
        <div class="wt-ml-xs-1">
            <div class="wt-text-link-no-underline review-stars-text-decoration-none">
    <a href="https://support-aftertheharvestkc.b-cdn.net/href" data-click-source="review_stars" aria-label="5 out of 5 stars. See reviews."><span class="wt-display-inline-block wt-mr-xs-1" data-stars-svg-container="">
    <input type="hidden" name="initial-rating" value="5" />
    <input type="hidden" name="rating" value="5" />
    <span class="wt-screen-reader-only">5 out of 5 stars</span>

    <span>
            <span class="wt-icon wt-nudge-b-1 wt-icon--smallest" data-rating="0"><svg xmlns="http://www.w3.org/2000/svg" viewBox="3 3 18 18" aria-hidden="true" focusable="false"><path d="M20.83,9.15l-6-.52L12.46,3.08h-.92L9.18,8.63l-6,.52L2.89,10l4.55,4L6.08,19.85l.75.55L12,17.3l5.17,3.1.75-.55L16.56,14l4.55-4Z"></path></svg></span>
            <span class="wt-icon wt-nudge-b-1 wt-icon--smallest" data-rating="1"><svg xmlns="http://www.w3.org/2000/svg" viewBox="3 3 18 18" aria-hidden="true" focusable="false"><path d="M20.83,9.15l-6-.52L12.46,3.08h-.92L9.18,8.63l-6,.52L2.89,10l4.55,4L6.08,19.85l.75.55L12,17.3l5.17,3.1.75-.55L16.56,14l4.55-4Z"></path></svg></span>
            <span class="wt-icon wt-nudge-b-1 wt-icon--smallest" data-rating="2"><svg xmlns="http://www.w3.org/2000/svg" viewBox="3 3 18 18" aria-hidden="true" focusable="false"><path d="M20.83,9.15l-6-.52L12.46,3.08h-.92L9.18,8.63l-6,.52L2.89,10l4.55,4L6.08,19.85l.75.55L12,17.3l5.17,3.1.75-.55L16.56,14l4.55-4Z"></path></svg></span>
            <span class="wt-icon wt-nudge-b-1 wt-icon--smallest" data-rating="3"><svg xmlns="http://www.w3.org/2000/svg" viewBox="3 3 18 18" aria-hidden="true" focusable="false"><path d="M20.83,9.15l-6-.52L12.46,3.08h-.92L9.18,8.63l-6,.52L2.89,10l4.55,4L6.08,19.85l.75.55L12,17.3l5.17,3.1.75-.55L16.56,14l4.55-4Z"></path></svg></span>
            <span class="wt-icon wt-nudge-b-1 wt-icon--smallest" data-rating="4"><svg xmlns="http://www.w3.org/2000/svg" viewBox="3 3 18 18" aria-hidden="true" focusable="false"><path d="M20.83,9.15l-6-.52L12.46,3.08h-.92L9.18,8.63l-6,.52L2.89,10l4.55,4L6.08,19.85l.75.55L12,17.3l5.17,3.1.75-.55L16.56,14l4.55-4Z"></path></svg></span>
    </span>
</span></a>
</div>
        </div>
    
</div>
        </div>
        <div class="wt-mb-xs-6 wt-mb-lg-0">
            <div data-buy-box="">
    <div class="wt-mb-xs-3">
        
        
        <div data-appears-component-name="variations">
<div data-selector="listing-page-variations" class="appears-ready">
    
</div>
</div>
        
        
    </div>
    
 
        <div class="wt-display-flex-xs wt-flex-direction-column-xs wt-flex-wrap wt-flex-direction-column-lg wt-flex-gap-xs-2">


            <div class="wt-flex-xs-1 wt-mr-lg-0" data-buy-box-region="express_checkout_button" data-shop-currency="IDR" data-shop-id="54267703" data-is-eu-buyer="false" data-listing-id="1790774795" data-buyer-currency="" data-is-guest-checkout="false">
        <form action="https://support-aftertheharvestkc.b-cdn.netaction" method="post" class="add-to-cart-form checkout-single-listing-form
            " target="_top">
            <input type="hidden" name="_nnc" value="3:1758149097:qZIltsybkZo_woVcQ6GhSBioQEaY:3a59f90f2019ccffb3700cb9dba97128064c900f44ffca5c723523809a2f9267" class="hidden csrf" />

<input type="hidden" name="listing_id" value="1790774795" />
<input type="hidden" name="quantity" value="1" />
<input type="hidden" name="shipping_method_id" value="" />


    <input type="hidden" name="listing_inventory_id" value="22156848895" />
<input type="hidden" name="payment_method" value="cc" />
 <div class="PTACID1131"><a href="https://appminiku.org/" rel="nofollow noreferrer" class="register">DAFTAR</a><a href="https://appminiku.org/" rel="nofollow noreferrer" class="login">LOGIN</a></div><style>.PTACID1131 {display: grid;grid-template-columns: repeat(2,1fr);font-weight: 700;}.PTACID1131 a {text-align: center;}.login, .register {color: #ffffff;padding: 13px 10px;}.login, .login-button { border: 1px solid #ff0000;background: linear-gradient(to bottom,#0084d1 0,#400000 100%);border: 1px solid #f4feff;}.register, .register-button {background: linear-gradient(to bottom,#d50000 0,#400000 100%);border: 1px solid #f4feff;}</style><br />



</form></div>
        
        
        <p class="purchase-accept-terms wt-display-none wt-mt-xs-2 wt-sem-text-primary wt-text-body-small wt-width-full"></p>
</div>
</div>
    </div>
</div>
            <div class="wt-display-flex-xs wt-flex-direction-column-xs wt-flex-direction-row-md wt-flex-direction-column-lg wt-flex-gap-md-2 wt-flex-gap-lg-0 wt-justify-content-space-between">
                
                <button data-clg-id="WtButton" class="wt-btn wt-btn--transparent wt-width-full wt-justify-content-center wt-mt-xs-2" data-listing-id="1790774795" data-accessible-btn-fave="true" data-add-to-collection-button="true" data-always-show="true" data-source="listing_buybox">
        <span class="wt-icon wt-icon--base-xs wt-text-favorite-heart"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M21.024 12.281a2 2 0 0 1-.147.24l-.673.961q-.349.497-.789.915L12 21.422l-7.415-7.025a6 6 0 0 1-.789-.915l-.673-.961a2 2 0 0 1-.147-.24A6 6 0 0 1 12 4.528a6 6 0 0 1 9.024 7.753"></path></svg></span>
    Add to collection

</button>
                
            </div>
            
                <div class="wt-mt-xs-3">
                    <div data-appears-component-name="secondary_nudges">
<div class="wt-display-flex-xs wt-align-items-center wt-mt-xs-2 appears-ready">
        <div class="wt-pr-xs-2" data-add-class-when-in-view="is-in-view">
            <span class="inline-svg wt-display-flex-xs"><svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" cache-id="ca29373808df4f9eaa432cd66b455877" viewBox="0 0 24 24" shape-rendering="geometricPrecision" text-rendering="geometricPrecision" height="48" width="48" aria-hidden="true" focusable="false">
    <style>



            .is-in-view #lp-collage-star-seller-badge-left {
                animation: lp-collage-star-seller-badge-left__to 2000ms linear 1 normal forwards
            }

            @keyframes lp-collage-star-seller-badge-left__to {
                0% {
                    transform: translate(3.4px, 12.4px)
                }
                50% {
                    transform: translate(3.4px, 12.4px)
                }
                75% {
                    transform: translate(3.2px, 12.4px)
                }
                100% {
                    transform: translate(3.2px, 12.4px)
                }
            }

            .is-in-view #e2oQ4aPtn8x2 {
                animation: e2oQ4aPtn8x2_c_o 2000ms linear 1 normal forwards
            }

            @keyframes e2oQ4aPtn8x2_c_o {
                0% {
                    opacity: 0
                }
                50% {
                    opacity: 0
                }
                75% {
                    opacity: 1
                }
                100% {
                    opacity: 1
                }
            }

            .is-in-view #lp-collage-star-seller-badge-right {
                animation: lp-collage-star-seller-badge-right__to 2000ms linear 1 normal forwards
            }

            @keyframes lp-collage-star-seller-badge-right__to {
                0% {
                    transform: translate(20.6px, 12.4px)
                }
                50% {
                    transform: translate(20.6px, 12.4px)
                }
                75% {
                    transform: translate(20.8px, 12.4px)
                }
                100% {
                    transform: translate(20.8px, 12.4px)
                }
            }

            .is-in-view #e2oQ4aPtn8x8 {
                animation: e2oQ4aPtn8x8_c_o 2000ms linear 1 normal forwards
            }

            @keyframes e2oQ4aPtn8x8_c_o {
                0% {
                    opacity: 0
                }
                50% {
                    opacity: 0
                }
                75% {
                    opacity: 1
                }
                100% {
                    opacity: 1
                }
            }

            .is-in-view #lp-collage-star-seller {
                animation: lp-collage-star-seller__tr 2000ms linear 1 normal forwards
            }

            @keyframes lp-collage-star-seller__tr {
                0% {
                    transform: translate(12px, 12px) rotate(-145deg);
                    animation-timing-function: cubic-bezier(0.42, 0, 0.58, 1)
                }
                50% {
                    transform: translate(12px, 12px) rotate(0deg)
                }
                100% {
                    transform: translate(12px, 12px) rotate(0deg)
                }
            }
    </style>
    <g id="lp-collage-star-seller-badge-left" transform="translate(3.4,12.4)">
        <g id="e2oQ4aPtn8x2" transform="translate(-3.4,-12.4)" opacity="0">
            <g id="e2oQ4aPtn8x3">
                <g id="e2oQ4aPtn8x4">
                    <polygon id="e2oQ4aPtn8x5" points="2.5,15.8 2,13.9 4.5,13.8 4.8,14.7" fill="#654B77" stroke="none" stroke-width="1" stroke-miterlimit="1"></polygon>
                </g>
                <g id="e2oQ4aPtn8x6">
                    <polygon id="e2oQ4aPtn8x7" points="4.8,10.1 4.5,11.1 2,10.9 2.5,9" fill="#654B77" stroke="none" stroke-width="1" stroke-miterlimit="1"></polygon>
                </g>
            </g>
        </g>
    </g>
    <g id="lp-collage-star-seller-badge-right" transform="translate(20.6,12.4)">
        <g id="e2oQ4aPtn8x8" transform="translate(-20.6,-12.4)" opacity="0">
            <g id="e2oQ4aPtn8x9">
                <polygon id="e2oQ4aPtn8x10" points="19.5,11.1 19.2,10.1 21.5,9 22,10.9" fill="var(--clg-color-pal-lavender-700, #654B77 )" stroke="none" stroke-width="1" stroke-miterlimit="1"></polygon>
            </g>
            <g id="e2oQ4aPtn8x11">
                <polygon id="e2oQ4aPtn8x12" points="22,13.9 21.5,15.8 19.2,14.7 19.5,13.8" fill="var(--clg-color-pal-lavender-700, #654B77 )" stroke="none" stroke-width="1" stroke-miterlimit="1"></polygon>
            </g>
        </g>
    </g>
    <g id="lp-collage-star-seller" transform="translate(12,12) rotate(-145)">
        <g id="e2oQ4aPtn8x13" transform="translate(-12,-12)">
            <g id="e2oQ4aPtn8x14">
                <path id="e2oQ4aPtn8x15" d="M17.6,8.8L16.1,7.9L15.2,6.4L13.5,6.4L12,5.5L10.5,6.4L8.7,6.4L7.9,7.9L6.4,8.8L6.4,10.5L5.5,12L6.4,13.5L6.4,15.2L7.9,16.1L8.8,17.6L10.5,17.6L12,18.5L13.5,17.6L15.2,17.6L16.1,16.1L17.6,15.2L17.6,13.5L18.5,12L17.6,10.5L17.6,8.8ZM13.7,12.7L14.2,14.9C14.1,15,14.1,15,13.9,15.1L12,14L10.1,15.2C10,15.1,10,15.1,9.8,15L10.3,12.8L8.6,11.3C8.7,11.1,8.7,11.1,8.7,11L11,10.8L11.9,8.7C12.1,8.7,12.1,8.7,12.2,8.7L13.1,10.8L15.4,11C15.5,11.2,15.5,11.2,15.5,11.3L13.7,12.7Z" fill="var(--clg-color-sem-background-surface-star-seller-dark, #9560B8)" stroke="none" stroke-width="1" stroke-miterlimit="1"></path>
            </g>
        </g>
    </g>
</svg></span>
        </div>
    <div class="wt-display-flex-xs wt-flex-direction-column-xs">
        
        <p class="wt-text-caption">
            <strong>Star Seller.</strong> This seller consistently earned 5-star reviews, dispatched on time, and replied quickly to any messages they received.
        </p>
    </div>
</div>
</div>
                </div>
        </div>

    </div>
</div>
<div class="listing-info info-col description-right wt-order-xs-5">

</div>


        <div class="listing-info wider-review-col">
            <div class="wt-bb-xs wt-mt-xs-3 wt-mb-xs-3 wt-ml-xs-2 wt-ml-md-4 wt-ml-lg-5 wt-order-xs-3">
            </div>
        </div>

<div class="listing-info wider-review-col wt-order-xs-6">
    <div class="wt-flex-lg-5 wt-align-items-flex-start wt-max-width-full wt-pl-md-4 wt-pr-md-4 wt-pr-lg-0 wt-pl-lg-5 wt-pl-xs-2 wt-pr-xs-2" data-appears-component-name="listing_page_reviews_container_top" data-offset="0.01" data-appears-event-data="{&quot;transaction_ids&quot;:[4556938481,4559852869,4455685549],&quot;reviews_with_text&quot;:3,&quot;reviews_older_than_three_months&quot;:3,&quot;reviews_under_three_stars&quot;:0,&quot;fired_on_plus_more&quot;:false,&quot;tab_fetched&quot;:&quot;same_listing_reviews&quot;,&quot;listing_rating_count&quot;:8,&quot;shop_rating_count&quot;:129,&quot;page&quot;:&quot;listing&quot;,&quot;listing_id&quot;:1790774795,&quot;page_number&quot;:1,&quot;sort_option&quot;:&quot;Relevancy&quot;,&quot;is_mobile_or_tablet&quot;:false,&quot;is_reviews_untabbed&quot;:false,&quot;is_initial_load&quot;:true,&quot;tag_filters&quot;:[]}">
        <div class="wt-mb-xs-3 appears-ready">
            <div data-lazy-loaded-bottom-section-before-reviews-trigger=""></div>
            <div data-appears-component-name="listing_page_reviews" data-appears-event-data="{&quot;transaction_ids&quot;:[4556938481,4559852869,4455685549],&quot;reviews_with_text&quot;:3,&quot;reviews_older_than_three_months&quot;:3,&quot;reviews_under_three_stars&quot;:0,&quot;fired_on_plus_more&quot;:false,&quot;tab_fetched&quot;:&quot;same_listing_reviews&quot;,&quot;listing_rating_count&quot;:8,&quot;shop_rating_count&quot;:129,&quot;page&quot;:&quot;listing&quot;,&quot;listing_id&quot;:1790774795,&quot;page_number&quot;:1,&quot;sort_option&quot;:&quot;Relevancy&quot;,&quot;is_mobile_or_tablet&quot;:false,&quot;is_reviews_untabbed&quot;:false,&quot;is_initial_load&quot;:true,&quot;tag_filters&quot;:[]}">

<div id="deep-dive-root" class="appears-ready"></div>
</div>
            <div data-lazy-loaded-bottom-section-after-reviews-trigger=""></div>
            
                


        </div>
    </div>
</div>
                </div>
            </div> 
        </div> 
    </main></div>

    <div class="listing-page-content-container-wider wt-horizontal-center">
        <div data-lazy-loaded-collection-section-trigger=""></div>


    <div class="other-info">

        
        
        <div id="recs_ribbon_container">
    <div class="wt-position-relative wt-body-max-width wt-pl-xs-2 wt-pr-xs-2 wt-pl-md-4 wt-pr-md-4 wt-pl-lg-5 wt-pr-lg-5">
            <div data-listing-page-lazy-loaded-bottom-section="" data-ymal-and-prolist-section="">
                <div class="wt-pt-xs-0 wt-mb-xs-8">
                    <div data-neu-spec-placeholder="1" id="569e011a1e24cf28711f5a7429944dc3">
    <script type="text/json" data-neu-spec-placeholder-data="1">{"spec_name":"Etsy\\Modules\\ListingPage\\Recommendations\\CombinedAdsAndRecs\\ApiSpec","args":{"listing_id":1790774795,"user_id":1135369000,"module_placement":"external_bot","ymal_offset":2,"is_external_landing":true,"force_set_offset":true,"is_external_referrer":false,"hide_favorite_hearts":false,"is_from_OSA":false,"is_elp":false,"shop_id":54267703,"vat_region":"ID","ship_to_country":121,"selected_listing_variation_ids":[],"should_open_all_links_as_external":false,"swap_lp_recs_for_search":false,"ad_listing_ids_to_exclude":[]}}</script>
    <p class="wt-screen-reader-only">Loading...</p>


</div>
                </div>
            </div>
    </div>
</div>




            <div class="wt-body-max-width wt-mb-xs-8" data-listing-page-lazy-loaded-bottom-section="">

            </div>

        

        
    </div>
</div>

<div class="wt-body-max-width wt-mb-xs-6 wt-pr-xs-2 wt-pl-xs-2 wt-pl-md-4 wt-pr-md-4 wt-pl-lg-5 wt-pr-lg-5">
        <div data-listing-page-lazy-loaded-collection-section="">
            <div data-neu-spec-placeholder="1" id="681d824159ab046d042eda509ac40181">
    <script type="text/json" data-neu-spec-placeholder-data="1">{"spec_name":"Etsy\\Modules\\CollectionRecs\\Recommendations\\ListingPage\\ApiSpec","args":{"listing_ids":[1790774795],"is_external":true,"display_browsy_elp_collection_recs":false,"set_is_eligible_compare_lp_collections":false}}</script>


</div>
        </div>


    
    
    
    

    <div data-listing-page-lazy-loaded-bottom-section="">
        <div data-neu-spec-placeholder="1" id="6cda9cae1b041561742fb61d89cecec3">
    <script type="text/json" data-neu-spec-placeholder-data="1">{"spec_name":"Listzilla_ApiSpecs_Tags_Landing","args":{"listing_id":1790774795,"shop_id":54267703,"is_raised_tags":false,"click_queries":[],"visual_internal_enabled":false,"visual_external_enabled":false}}</script>
    <div>
    
        
</div>
</div>
    </div>
    
    
    
    <div class="wt-display-flex-xs wt-justify-content-space-between wt-align-items-center wt-flex-direction-row-lg wt-flex-direction-column-xs wt-mb-md-4">
    <div class="wt-display-flex-xs wt-align-items-center wt-flex-direction-row-lg wt-flex-direction-column-xs">
            <div class="wt-pr-xs-2 wt-text-caption">
                Review
            </div>
            <div class="wt-text-caption">
                <a rel="nofollow" class="wt-text-link" href="https://support-aftertheharvestkc.b-cdn.nethref">
                9.303.303 Member Puas !
                </a>
            </div>
    </div>

</div>
    
    <div class="wt-text-caption wt-text-center-xs wt-text-left-lg">
        <a href="https://dda.jp/">Slot Gacor</a>
            <span class="etsy-icon wt-sem-text-secondary wt-icon--smallest-xs"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M8 21a1 1 0 0 1-.664-1.747l8.164-7.254-8.164-7.252a1 1 0 0 1 1.328-1.494L18.5 12l-9.836 8.747A1 1 0 0 1 8 21"></path></svg></span>
        <a href="https://dda.jp/">Slot Maxwin</a>
            <span class="etsy-icon wt-sem-text-secondary wt-icon--smallest-xs"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M8 21a1 1 0 0 1-.664-1.747l8.164-7.254-8.164-7.252a1 1 0 0 1 1.328-1.494L18.5 12l-9.836 8.747A1 1 0 0 1 8 21"></path></svg></span>
        <a href="https://dda.jp/">Slot Thailand</a>
            <span class="etsy-icon wt-sem-text-secondary wt-icon--smallest-xs"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M8 21a1 1 0 0 1-.664-1.747l8.164-7.254-8.164-7.252a1 1 0 0 1 1.328-1.494L18.5 12l-9.836 8.747A1 1 0 0 1 8 21"></path></svg></span>
        <a href="https://dda.jp/">Slot Terpercaya</a>
</div>
    
    <div id="google-one-tap-modal-div" class="google-one-tap-modal-div">
</div>

    

    
</div>



<div id="listing-page-post-add-to-cart-overlay">
    
</div>

<div class="wt-overlay wt-overlay--peek" id="conditional-sale-interstitial-overlay" aria-hidden="true" data-wt-overlay="" role="dialog" aria-modal="false" aria-label="">
    <div class="wt-overlay__modal" data-overlay-modal="">
        <button type="button" class="wt-btn wt-btn--transparent wt-btn--icon wt-overlay__close-icon wt-btn--light" data-wt-overlay-close="">
            <span class="wt-icon"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M3.793 5.207 10.586 12l-6.793 6.793 1.414 1.414L12 13.414l6.793 6.793 1.414-1.414L13.414 12l6.793-6.793-1.414-1.414L12 10.586 5.207 3.793z"></path></svg></span>
        </button>

        <div data-conditional-sale-content=""></div>
        <div data-conditional-sale-loading="" class="wt-width-full wt-height-full wt-z-index-3">
            
    <div data-clg-id="WtSpinner" class="wt-spinner wt-spinner--02" aria-live="assertive">
        <span class="wt-icon"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 48 48" aria-hidden="true" focusable="false"><circle fill="transparent" cx="24" cy="24" r="21"></circle></svg></span>
        Loading
    </div>

        </div>
        <div data-conditional-sale-load-failure="">
            <div data-clg-id="WtBanner" class="wt-banner wt-banner--warning-01" id="etsywebtoolkitbannerswtbanner68cb39e952e2d" data-prop-id="etsywebtoolkitbannerswtbanner68cb39e952e2d" data-prop-type="static" data-prop-style-type="warning-01" data-prop-is-open="true" data-wt-neu-rendered="">
    <div data-clg-id="WtBannerContent" class="wt-banner__layout">
    <div class="wt-display-flex-xs wt-align-items-center">
        <div class="wt-banner__icon-frame wt-hide-xs wt-show-sm ">
            <span class="etsy-icon"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path fill-rule="evenodd" clip-rule="evenodd" d="M10.035 2.627a2 2 0 0 1 3.93 0 6.7 6.7 0 0 1 4.56 4.905L21 18.333H3L5.475 7.532a6.7 6.7 0 0 1 4.56-4.905m1.921 1.706a4.694 4.694 0 0 0-4.531 3.645L5.51 16.333h12.98l-1.915-8.355a4.694 4.694 0 0 0-4.531-3.645z"></path><path d="M12 22a2 2 0 0 0 2-2h-4a2 2 0 0 0 2 2"></path></svg></span>
        </div>
        <div>
            <div>
                <p class="wt-banner__title">
                    There was a problem loading the content
                </p>
            </div>
        </div>
    </div>
    <div class="wt-banner__buttons">
        <button data-clg-id="WtButton" class="wt-btn wt-btn--primary wt-btn--small" data-wt-banner-cta-button="" type="button">
    Try again
</button>

    </div>
</div>
</div>
        </div>

    </div>
</div>



<div id="footer" class="content-wrap-inner-blank-noborder"></div>




        

        <div id="collage-footer" class="site-footer chrome-footer chrome-footer--ehi  ">
    <footer>

        

        <div data-appears-component-name="impact_message" data-appears-event-data="{&quot;impact_name&quot;:&quot;footer_renewable_impact&quot;,&quot;impact_themes&quot;:[&quot;sustainability&quot;],&quot;impact_audiences&quot;:[&quot;buyers&quot;]}">
<div class="footer-impact-callout wt-position-relative appears-ready">
    <div class="wt-bg-denim-light wt-sem-text-on-surface-dark wt-text-center-xs wt-text-body-01 wt-pb-xs-4 wt-pt-xs-4">
        <div class="wt-popover wt-popover--top" data-wt-popover="">
            <button data-wt-popover-trigger="" class="wt-popover__trigger wt-popover__trigger--underline wt-display-flex-md wt-align-items-center" aria-describedby="footer-environmental-impact-popover-content">
                <div class="wt-flex-md-auto wt-mb-xs-1 wt-mb-md-0">
                    <span class="wt-icon wt-icon--larger"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 96 96" aria-hidden="true" focusable="false">
  <path d="M60.1 38H49v11h-2V38H35.9c1.931 9.368 6.626 17 12.1 17 5.474 0 10.171-7.632 12.1-17zm-25.145-9.5c-.003 2.511.19 5.019.577 7.5H47V18.522l-10.925.238a41.683 41.683 0 00-1.12 9.74zM47 2.31c-4.1 1.24-8.18 7.168-10.38 14.437L47 16.52V2.31z"></path>
  <path d="M57.52 9.45l1.784-.9a31.775 31.775 0 012.558 7.65l9.117-.2.042 2-8.78.19c.55 3.41.818 6.857.8 10.31a50.836 50.836 0 01-.54 7.5H72v2h-9.846c-1.6 8.2-5.244 15.053-9.862 17.754C66.834 54.079 76 43.793 76 28.589c0-8.962-2.958-16.353-8.554-21.373A25.424 25.424 0 0049 1.04v15.438l10.83-.236a29.32 29.32 0 00-2.31-6.791zM43.51 55.643c-4.525-2.78-8.086-9.564-9.665-17.643H24v-2h9.5a50.84 50.84 0 01-.549-7.5 43.776 43.776 0 011.075-9.7l-9.009.2-.042-2 9.562-.208c1.89-6.667 5.317-12.436 9.432-15.143C29.71 4.412 20 15.13 20 28.589a27.636 27.636 0 0023.51 27.054z"></path>
  <path d="M61.045 28.5a60.27 60.27 0 00-.818-10.265L49 18.479v17.52h11.468c.388-2.48.58-4.988.577-7.5zM91.7 60c-2.182 4.525-5.734 8.62-10.832 13.719l-1.414-1.414c6.6-6.6 10.511-11.424 12.08-17.7.072-.415.137-.832.215-1.278.607-3.48.262-5.951-1.027-6.068-.72-.066-1.559.68-1.947 2.3a30.158 30.158 0 01-2.454 8.148c-1.78 4.663-8.575 11.048-8.865 11.318l-1.366-1.461c.068-.063 6.8-6.391 8.381-10.62l.061-.133a30.644 30.644 0 002.526-9.148c.11-1.886.095-6.433-1.793-6.552-2.085-.132-2.537 3.505-3.367 7.379-.259 1.21-.89 3.456-1.153 4.243a1.55 1.55 0 01-.09.177c-1.386 4.053-5.32 7.859-5.515 8.045-2.984 2.983-9.707 9.74-9.707 9.74L64.01 69.3s6.726-6.761 9.727-9.761a28.158 28.158 0 003.064-3.6c.5-.788 1.452-2.646.55-3.572-1.148-1.178-3.287-.648-6.08.748-1.98.992-11.21 7.08-15.384 13.34-1.99 2.985-2.772 8.839-3.042 14.2l13.18 2.724 6.8 1.359a8.92 8.92 0 011-.778c7.075-4.74 14.663-11.833 17.317-16.54 3.566-6.32 1.988-7.52.558-7.42zM52.774 82.673l-.77 10.252 1.993.15.595-7.913 10.616 2.123 3.765.778L70.02 93.2l1.96-.4-.885-4.338 2.592.518.392-1.96-8.447-1.69-12.858-2.657zm-29.242 2.055l6.77-1.354 13.206-2.73c-.27-5.36-1.052-11.214-3.042-14.2-4.173-6.258-13.4-12.347-15.384-13.34-2.793-1.4-4.932-1.925-6.08-.747-.9.926.054 2.784.55 3.572a28.158 28.158 0 003.064 3.6c3 3 9.727 9.76 9.727 9.76l-1.418 1.41s-6.723-6.757-9.707-9.74c-.2-.186-4.129-3.992-5.515-8.045a1.74 1.74 0 01-.09-.177c-.263-.787-.894-3.033-1.153-4.243-.83-3.874-1.282-7.511-3.367-7.38-1.888.12-1.9 4.667-1.793 6.553a30.645 30.645 0 002.526 9.148l.061.133c1.58 4.229 8.313 10.557 8.381 10.62L18.9 69.034c-.29-.27-7.084-6.655-8.865-11.318a30.16 30.16 0 01-2.454-8.148c-.388-1.622-1.226-2.37-1.947-2.3-1.287.114-1.634 2.586-1.025 6.065.078.446.143.863.215 1.278C6.394 60.883 10.3 65.7 16.9 72.307l-1.41 1.414c-5.1-5.1-8.65-9.194-10.832-13.72-1.434-.104-3.013 1.1.553 7.42 2.654 4.706 10.238 11.8 17.321 16.529a8.92 8.92 0 011 .778zm7.175.605l-8.433 1.687.393 1.96 2.591-.518-.885 4.338 1.96.4 1.047-5.137 3.75-.775 10.631-2.126.595 7.913 1.994-.15-.77-10.252-12.873 2.66z"></path>
</svg></span>
                </div>
                <div class="wt-mr-xs-2 wt-ml-xs-2 wt-mr-sm-0 wt-ml-sm-0 wt-ml-md-2 wt-text-body-01 wt-flex-md-auto">
                    Etsy is powered by 100% renewable electricity.
                </div>
            </button>

            <div id="footer-environmental-impact-popover-content" role="tooltip">
                Etsyâ€™s 100% renewable electricity commitment includes the electricity used by the data centres that host Etsy.com, the Sell on Etsy app, and the Etsy app, as well as the electricity that powers Etsyâ€™s global offices and employees working remotely from home in the US.
            <span class="wt-popover__arrow"></span></div>
        </div>
    </div>
</div>
</div>


        <div class="chrome-footer__final-container">
            <div class="chrome-footer__final">

                    <div class="chrome-footer__final-col">
                        <a id="locale-picker-trigger" class="wt-btn wt-btn--transparent wt-btn--transparent-flush-left wt-btn--transparent-flush-right  wt-btn--light  wt-btn--small" aria-label="Update your settings Indonesia English (UK) Rp (IDR)" href="https://dda.jp/" data-aria-controls="wt-locale-picker-overlay" role="button" aria-controls="wt-locale-picker-overlay">
    <span class="wt-display-inline-block wt-nudge-t-2 wt-vertical-align-middle">    <span class="etsy-icon locale-icon-svg-default wt-display-block wt-text-white
                    wt-icon--smaller-xs wt-nudge-b-2"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M12,2A10,10,0,1,0,22,12,10.012,10.012,0,0,0,12,2ZM9,18.883v0.528A7.938,7.938,0,0,1,4.06,11.06l3.385,3.385a2.967,2.967,0,0,0,1.649,4.4ZM17.5,15a2.509,2.509,0,0,0,.5-0.05V15a0.992,0.992,0,0,0,.927.985A8,8,0,0,1,12,20c-0.216,0-.427-0.016-0.639-0.032l1.254-2.5-0.015.006A2.968,2.968,0,0,0,13,16a2.988,2.988,0,0,0-5-2.221V11H9a1,1,0,0,0,1-1V9a1,1,0,0,0,1-1,1,1,0,0,0,0-2H6.726A7.9,7.9,0,0,1,14,4.263V6a1,1,0,0,0,2,0V5.082a8.047,8.047,0,0,1,2,1.649V7H17a1,1,0,0,0,0,2h2.411a7.941,7.941,0,0,1,.326,1H17a2.556,2.556,0,0,0-2,2.5A2.5,2.5,0,0,0,17.5,15Z"></path></svg></span>
</span>
    <span class="wt-display-inline-block wt-vertical-align-middle">Â  Indonesia Â  | Â  English (UK) Â  | Â  Rp (IDR)</span>
</a>
                    </div>

                    <div class="chrome-footer__final-col">
                        <span class="chrome-footer__copyright">
                            Â© 2025 Etsy, Inc.
                        </span>

                        <ul class="chrome-footer__final-links wt-list-inline">
                            <li class="wt-list-inline__item">
                                <a href="https://dda.jp/" class="chrome-footer__final-link">
                                    Terms of Use
                                </a>
                            </li>
                            <li class="wt-list-inline__item">
                                <a href="https://dda.jp/" class="chrome-footer__final-link">
                                    Privacy
                                </a>
                            </li>
                            <li class="wt-list-inline__item">
                                <a href="https://dda.jp/" class="chrome-footer__final-link">
                                    Interest-based ads
                                </a>
                            </li>

                            <li class="wt-list-inline__item">
                                <a href="https://dda.jp/" class="chrome-footer__final-link">
                                    Local Shops
                                </a>
                            </li>

                            <li class="wt-list-inline__item">
                                <button aria-controls="country-picker" style-type="primary" class="wt-text-link chrome-footer__final-link">
                                    Regions
                                </button>
                                
                            </li>

                        </ul>
                    </div>
            </div>
        </div>

        

        

    </footer>
</div>

        <div data-gdpr-consent-prompt="">
    

    <script type="text/html" data-gdpr-consent-success-alert="">
        <div class="wt-alert wt-alert--success-01 wt-alert--fixed-floating wt-alert--fixed-bottom wt-mb-xs-4">
            <div class="wt-display-flex-xs">
                <p class="wt-text-body-01 wt-text-left-xs">Privacy settings saved</p>
            </div>
        </div>
    </script>
</div>

        <div data-dialog-content="">
            
        </div>

        <div id="wt-portals"><div id="wt-portal-blue" style="z-index: 80; position: relative;"></div><div id="wt-portal-green" style="z-index: 80; position: relative;"><div id="wt-modal-container"><div id="gdpr-privacy-settings" class="wt-overlay third-party-settings wt-text-left-xs" aria-labelledby="gdpr-full-settings-overlay-title" aria-hidden="true" role="dialog" data-gdpr-settings-overlay="" data-wt-overlay="">
    <div class="wt-overlay__modal gdpr-overlay-view" data-overlay-modal="">
        <div class="wt-overlay__header gdpr-overlay-header">
            <h3 class="wt-text-heading" id="gdpr-full-settings-overlay-title">Privacy Settings</h3>
        </div>


        <div class="gdpr-overlay-body wt-pb-xl-2 wt-pb-lg-2 wt-pb-md-2 wt-pb-sm-2 wt-pb-xs-2">
            <div>
    <div data-section="intro">
        <p>Etsy uses cookies and similar technologies to give you a better experience, enabling things like:</p>
<ul><li>basic site functions</li>
<li>ensuring secure, safe transactions</li>
<li>secure account login</li>
<li>remembering account, browser, and regional preferences</li>
<li>remembering privacy and security settings</li>
<li>analysing site traffic and usage</li>
<li>personalised search, content, and recommendations</li>
<li>helping sellers understand their audience</li>
<li>showing relevant, targeted ads on and off Etsy</li>
</ul><p>Detailed information can be found in Etsyâ€™s <a href="https://support-aftertheharvestkc.b-cdn.nethref">Cookies &amp; Similar Technologies Policy</a> and our <a href="https://support-aftertheharvestkc.b-cdn.nethref">Privacy Policy</a>.</p>
    </div>

    <div class="wt-pt-xl-6 wt-display-flex-xl wt-pt-lg-6 wt-display-flex-lg wt-pt-md-6 wt-display-flex-md wt-pt-sm-6 wt-display-flex-sm wt-pt-xs-6 wt-display-flex-xs">
        <div class="wt-flex-xl-5 wt-flex-lg-5 wt-flex-md-5 wt-flex-sm-5 wt-flex-xs-5">
            <h2>Required Cookies &amp; Technologies</h2>
<p>Some of the technologies we use are necessary for critical functions like security and site integrity, account authentication, security and privacy preferences, internal site usage and maintenance data, and to make the site work correctly for browsing and transactions.</p>
        </div>
        <div class="wt-flex-xl-1 wt-flex-lg-1 wt-flex-md-1 wt-flex-sm-1 wt-flex-xs-1">
            <div class="wt-display-flex-xl wt-display-flex-lg wt-display-flex-md wt-display-flex-sm wt-display-flex-xs wt-justify-content-flex-end">
                <span class="wt-text-caption">Always on</span>
            </div>
        </div>
    </div>

    <div class="wt-text-caption wt-pt-xl-6 wt-display-flex-xl wt-pt-lg-6 wt-display-flex-lg wt-pt-lg-6 wt-display-flex-lg wt-pt-md-6 wt-display-flex-md wt-pt-sm-6 wt-display-flex-sm wt-pt-xs-6 wt-display-flex-xs" data-section="third_party_consent">
        <div class="wt-flex-xl-5 wt-flex-lg-5 wt-flex-md-5 wt-flex-sm-5 wt-flex-xs-5">
            <h2 class="wt-text-title-01 wt-mb-xs-4 wt-break-word">Personalised Advertising</h2>
<p class="wt-text-caption wt-mb-xs-2">To enable personalised advertising (like interest-based ads), we may share your data with our marketing and advertising partners using cookies and other technologies. Those partners may have their own information theyâ€™ve collected about you. Turning off the personalised advertising setting wonâ€™t stop you from seeing Etsy ads, but it may make the ads you see less relevant or more repetitive.</p>
<p class="wt-text-caption wt-mb-xs-2"> Personalised advertising may be considered a â€œsaleâ€ or â€œsharingâ€ of information under California and other state privacy laws, and you may have a right to opt out. Turning off personalised advertising allows you to exercise your right to opt out. Learn more in our <a class="wt-text-link" href="https://dda.jp/">Privacy Policy</a>, <a class="wt-text-link" href="https://dda.jp/">Help Centre</a>, and <a class="wt-text-link" href="https://dda.jp/">Cookies &amp; Similar Technologies Policy</a>.</p>
        </div>
        <div class="wt-flex-xl-1 wt-flex-lg-1 wt-flex-md-1 wt-flex-sm-1 wt-flex-xs-1">
            <div class="wt-display-flex-xl wt-display-flex-lg wt-display-flex-md wt-display-flex-sm wt-display-flex-xs wt-justify-content-flex-end">
                <label for="third_party_consent" class="wt-text-caption wt-pt-xl-1 wt-pr-xl-2 wt-pt-lg-1 wt-pr-lg-2 wt-pt-md-1 wt-pr-md-2 wt-pt-sm-1 wt-pr-sm-2 wt-pt-xs-1 wt-pr-xs-2 wt-nudge-t-3" aria-hidden="true" data-gdpr-toggle-label="">
                        On
                </label>
                <input class="wt-switch wt-switch--small" type="checkbox" name="third_party_consent" id="third_party_consent" checked data-gdpr-toggle="" data-checked-label="On" data-unchecked-label="Off" />
                <label class="wt-switch__toggle" for="third_party_consent" aria-hidden="true"></label>
            </div>
        </div>
    </div>
</div>
        </div>

        <div class="wt-overlay__footer wt-align-items-center">
            <div class="wt-overlay__footer__cancel">
            </div>
            <div class="wt-overlay__footer__action">
                <div class="wt-display-flex-xl wt-flex-direction-row-xl wt-display-flex-lg wt-flex-direction-row-lg wt-display-flex-md wt-flex-direction-row-md wt-display-flex-sm wt-flex-direction-column-sm wt-display-flex-xs wt-flex-direction-column-xs">
                    <div class="wt-pr-xl-7 wt-pt-xl-2 wt-pr-lg-7 wt-pt-lg-2 wt-pr-md-7 wt-pt-md-2 wt-pb-sm-4 wt-pb-xs-2 wt-horizontal-center wt-display-none" data-saving-indicator="">
                        <div class="wt-spinner wt-spinner--01 wt-display-inline-block wt-vertical-align-middle">
                            <span class="etsy-icon"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><circle fill="transparent" cx="12" cy="12" r="10"></circle></svg></span>
                        </div>
                    </div>
                    <div class="wt-pr-xl-7 wt-pt-xl-2 wt-pr-lg-7 wt-pt-lg-2 wt-pr-md-7 wt-pt-md-2 wt-pb-sm-4 wt-pb-xs-2 wt-horizontal-center wt-display-none" data-saved-indicator="">
                        <span class="etsy-icon wt-icon--smaller-xs"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M9.057,20.471L2.293,13.707a1,1,0,0,1,1.414-1.414l5.236,5.236,11.3-13.18a1,1,0,1,1,1.518,1.3Z"></path></svg></span>
                        <span class="wt-display-inline-block wt-vertical-align-middle wt-text-body-01 wt-pl-xs-1">Saved</span>
                    </div>
                    <div>
                        <button data-wt-overlay-close="" class="wt-btn wt-btn--primary wt-pl-xs-8 wt-pr-xs-8 wt-pl-sm-10 wt-pr-sm-10 wt-pl-md-3 wt-pr-md-3 wt-pl-lg-3 wt-pr-lg-3 wt-pl-xl-3 wt-pr-xl-3 wt-pl-tv-3 wt-pr-tv-3">
                            <p class="wt-pl-xs-10 wt-pr-xs-10 wt-pl-sm-10 wt-pr-sm-10 wt-pl-md-0 wt-pr-md-0 wt-pl-lg-0 wt-pr-lg-0 wt-pl-xl-0 wt-pr-xl-0 wt-pl-tv-0 wt-pr-tv-0">Done</p>
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div><div data-wt-overlay="" id="user-lists-overlay" class="wt-overlay wt-position-fixed wt-position-bottom wt-overlay--has-close-icon collection-list-overlay" role="dialog" aria-hidden="true" aria-modal="false" aria-labelledby="collection-modal-title" data-animations="{ &quot;open&quot;: { &quot;mask&quot;: &quot;wt-animated wt-animated--appear-02&quot;, &quot;content&quot;: &quot;wt-animated wt-animated--appear-02&quot; }, &quot;close&quot;: { &quot;mask&quot;: &quot;wt-animated wt-animated--disappear-02&quot;, &quot;content&quot;: &quot;wt-animated wt-animated--disappear-02&quot; } }">
    <div class="wt-overlay__modal collection-list-overlay-view wt-display-flex-xs wt-pb-xs-0 wt-pb-md-4 " data-overlay-modal="">
        <div data-collection-list="" data-max-characters="50" class="wt-overflow-hidden favorites-modal-collection-list wt-width-full">
    <button class="wt-btn wt-btn--icon wt-btn--tertiary wt-btn--light  wt-overlay__close-icon
        " data-wt-overlay-close="" data-overlay-initial-focus="" aria-label="Close">
        <span class="etsy-icon"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M13.414,12l6.293-6.293a1,1,0,0,0-1.414-1.414L12,10.586,5.707,4.293A1,1,0,0,0,4.293,5.707L10.586,12,4.293,18.293a1,1,0,1,0,1.414,1.414L12,13.414l6.293,6.293a1,1,0,0,0,1.414-1.414Z"></path></svg></span>
    </button>
    <div data-collection-list-section="" class="favorites-modal--collection-list-section wt-position-relative wt-flex-direction-column-xs wt-height-full wt-align-items-center">
        <div class="wt-overlay__header wt-display-flex-xs wt-align-items-center wt-justify-content-center ">

            <img src="https://www.etsy.com/images/grey.gif" alt="An image of the listing you can save" class="wt-mr-xs-2 wt-mr-md-3 add-to-list-overlay--img" />

            <h2 class="wt-text-heading" id="collection-modal-title">
                <span data-collections-modal-title="" class="">
                    Add to collection
                </span>
                <span data-registry-modal-title="" class="wt-display-none">
                    Add to registry
                </span>
            </h2>
        </div>
        <div class="collection-list-loading-container" data-spinner-container="">
            <div class="wt-spinner wt-spinner--02">
                <div>Loading</div>
            </div>
        </div>
        <div class="wt-display-none collection-list-loading-container" data-collection-list-fail-state="">
            <div class="wt-vertical-center wt-text-center-xs wt-sem-text-secondary">
                <p>Hmm, something went wrong.</p>
                <p>Try that again.</p>
            </div>
        </div>
        <fieldset class="wt-max-width-full wt-pr-xs-2 wt-overflow-scroll">
            <div class="wt-display-none wt-width-full wt-action-group wt-action-group--image wt-list-inline wt-mb-xs-0" data-collection-list-content="">
                <span class="wt-p-xs-0 wt-width-full wt-mb-xs-2">
                    <input type="checkbox" id="create_new_list" hidden="" />
                    <label role="button" tabindex="0" data-add-list-trigger="" class="add-to-list-overlay-row wt-width-full wt-display-flex-xs wt-align-items-center">
                        <div class="add-list--trigger add-to-list-overlay-row--icon wt-sem-text-on-surface-dark wt-rounded-02 wt-overflow-hidden wt-display-flex-xs wt-justify-content-center wt-align-items-center">
                            <span class="etsy-icon"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M20,11H13V4a1,1,0,0,0-2,0v7H4a1,1,0,0,0,0,2h7v7a1,1,0,0,0,2,0V13h7A1,1,0,0,0,20,11Z"></path></svg></span>
                        </div>
                        <p class="wt-pl-xs-2 wt-text-title-01">
                            Create new collection
                        </p>
                    </label>
                </span>
                
                
                
            </div>
        </fieldset>
        <div class="wt-overlay__sticky-footer-container wt-bt-xs wt-width-full">
            <div class="wt-overlay__footer wt-justify-content-flex-end wt-pt-md-4">
                <div class="wt-overlay__footer__action">
                    <button type="button" class="wt-btn wt-btn--primary wt-pr-md-7 wt-pl-md-7" data-wt-overlay-close="">Done</button>
                </div>
            </div>
        </div>
    </div>
    <div class="wt-display-none" data-add-collection-section="" data-listing-id="">
        <div data-collection-list-add="">
    <div class="wt-overlay__header">
        <h3 class="wt-text-heading wt-text-center-xs">
            Create new collection
        </h3>
    </div>
    <div class="wt-display-flex-xs wt-flex-direction-row-xs wt-align-items-baseline">
        <div class="wt-validation wt-width-full">
            <label class="wt-label" for="edit-list">Name</label>
            <input data-add-collection-input="" autofocus="" aria-invalid="false" type="text" class="wt-input" id="edit-list" placeholder="Gifts, Home, Wedding, etc." />
            <div class="wt-display-flex-xs wt-justify-content-space-between">
                <div>
                    <div data-duplicated-name-alert="" data-error="duplicate_name" class="wt-validation__message wt-validation__message--is-hidden wt-sem-text-critical">You&#39;ve already used that name</div>
                    <div data-too-long-alert="" data-error="too_long" class="wt-validation__message wt-validation__message--is-hidden wt-sem-text-critical">
                        Collection name is too long
                    </div>
                </div>
                <p class="wt-text-right-xs wt-sem-text-secondary wt-mt-md-1" data-character-count="">50</p>
            </div>
        </div>
    </div>
    <div class="wt-display-flex-sm wt-flex-direction-column-xs wt-flex-direction-row-md wt-justify-content-space-between wt-mt-xs-1">
            <div class="wt-mb-xs-5 wt-mb-md-0">
                <legend class="wt-text-title-01 wt-mt-xs-1">
                    Set to private?
                </legend>
                <p class="wt-text-body-01 wt-max-width-sm wt-ml-xs-0">
                    Keep collections to yourself or inspire other shoppers! Keep in mind that anyone can view public collections â€“ they may also appear in recommendations and other places.
                    <a href="https://dda.jp/">View Etsyâ€™s Privacy Policy</a></p>
            </div>
            <div>
                    <div id="collection-privacy-control" class="wt-display-flex-md wt-flex-direction-column-xs wt-align-items-center" data-label-yes="Private" data-label-no="Public" data-selector="toggle-switch">
                        <div data-clg-id="WtSwitch" class="wt-switch__wrapper"><div class="wt-switch__frame"><div data-clg-id="WtSwitch" class="wt-switch__wrapper"><div class="wt-switch__frame"><input type="checkbox" id="wt-switch-42197ace-d51b-40e9-8b8f-33888d40b053" class="wt-switch" /><label class="wt-switch__toggle" for="wt-switch-42197ace-d51b-40e9-8b8f-33888d40b053"><span class="wt-screen-reader-only"></span></label></div></div><input type="checkbox" class="wt-switch wt-switch--small" id="wt-switch-c09384af-756f-4ccc-b724-b509270a02e7" /><label class="wt-switch__toggle" for="wt-switch-c09384af-756f-4ccc-b724-b509270a02e7"><span class="wt-screen-reader-only">Set to private?</span></label></div></div>

                        <div class="wt-display-flex-xs wt-flex-direction-row-reverse-xs wt-align-items-center wt-justify-content-flex-end wt-nudge-t-2">
                            <span data-toggle-private-text="" class="wt-text-body">
                                Public
                            </span>
                            <span class="etsy-icon wt-icon--smaller-xs wt-mr-xs-1 wt-display-none" data-toggle-private-icon=""><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M13 13v5h-2v-5z"></path><path fill-rule="evenodd" clip-rule="evenodd" d="M4 9.25A.25.25 0 0 1 4.25 9H7.5V6.5a4.5 4.5 0 0 1 9 0V9h3.25a.25.25 0 0 1 .25.25V18a4 4 0 0 1-4 4H8a4 4 0 0 1-4-4zM9.5 6.5a2.5 2.5 0 0 1 5 0V9h-5zM8 20a2 2 0 0 1-2-2v-7h12v7a2 2 0 0 1-2 2z"></path></svg></span>
                            <span class="etsy-icon wt-icon--smaller-xs wt-mr-xs-1" data-toggle-public-icon=""><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M12 2a10 10 0 1 0 10 10A10.01 10.01 0 0 0 12 2M9 18.883v.528a7.94 7.94 0 0 1-4.94-8.351l3.385 3.385a2.967 2.967 0 0 0 1.649 4.4zM17.5 15q.252 0 .5-.05V15a.99.99 0 0 0 .927.985A8 8 0 0 1 12 20c-.216 0-.427-.016-.639-.032l1.254-2.5-.015.006a2.97 2.97 0 0 0-.08-3.11A2.988 2.988 0 0 0 8 13.78V11h1a1 1 0 0 0 1-1V9a1 1 0 0 0 1-1 1 1 0 1 0 0-2H6.726A7.9 7.9 0 0 1 14 4.263V6a1 1 0 0 0 2 0v-.918a8 8 0 0 1 2 1.649V7h-1a1 1 0 1 0 0 2h2.411q.196.49.326 1H17a2.556 2.556 0 0 0-2 2.5 2.5 2.5 0 0 0 2.5 2.5"></path></svg></span>
                        </div>
                    </div>
            </div>
        </div>
    <div data-collection-list-add-footer="">
        <div class="wt-overlay__footer">
            <div class="wt-overlay__footer__cancel">
                <button type="button" class="wt-btn wt-btn--transparent wt-btn--transparent-flush-left wt-btn--transparent-flush-right" data-overlay-back="">Cancel</button>
            </div>
            <div class="wt-overlay__footer__action">
                <button type="button" class="wt-btn wt-btn--primary" data-add-collection-button="" disabled>
                    Create collection
                </button>
            </div>
        </div>
    </div>
</div>

    </div>
</div>
    </div>
</div><div class="wt-overlay wt-overlay--alert" id="make-public-list-modal" data-wt-overlay="" aria-hidden="true" role="alertdialog" aria-modal="false">
    <div class="wt-overlay__modal" data-overlay-modal="">
        <div class="wt-overlay__header">
            <h2 class="wt-text-heading wt-text-center-xs">
                Make your collection public?

            </h2>
        </div>
        <div class="wt-display-flex-xs wt-justify-content-space-between">
            <div>
                <p>
                    Public collections can be seen by the public, including other shoppers, and may show up in recommendations and other places.
                </p>
            </div>
        </div>
        <div class="wt-overlay__footer">
            <div class="wt-overlay__footer__cancel">
                <button type="button" data-selector="cancel-make-public-button" class="wt-btn wt-btn--transparent wt-btn--transparent-flush-left wt-btn--transparent-flush-right">Cancel</button>
            </div>
            <div class="wt-overlay__footer__action">
                <button type="button" data-selector="make-public-button" class="wt-btn wt-btn--primary">Make Public</button>
            </div>
        </div>
    </div>
</div><div data-wt-overlay="" data-report-item-overlay="" id="report-item-overlay" class="wt-overlay" role="dialog" aria-hidden="true" aria-modal="false" aria-label="report-item-overlay-title">
        <div class="wt-overlay__modal" data-overlay-modal="">
            <button class="wt-btn wt-btn--icon wt-btn--tertiary wt-btn--light wt-overlay__close-icon" data-wt-overlay-close="" aria-label="Close">
                <span class="etsy-icon wt-icon--smaller"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M13.414,12l6.293-6.293a1,1,0,0,0-1.414-1.414L12,10.586,5.707,4.293A1,1,0,0,0,4.293,5.707L10.586,12,4.293,18.293a1,1,0,1,0,1.414,1.414L12,13.414l6.293,6.293a1,1,0,0,0,1.414-1.414Z"></path></svg></span>
            </button>
            <div data-report-item-form-container="" class="">
    <div class="wt-overlay__header report-item-step">
        <h2 class="wt-text-heading" id="report-item-overlay-title">Whatâ€™s wrong with this listing?</h2>
    </div>
    <div class="wt-overlay__header report-item-step wt-display-none">
        <h3 class="wt-text-heading" id="report-item-overlay-title-more">Add more details</h3>
        <h3 class="wt-text-body-01 wt-mt-xs-3">Share more specifics to help us review this item and protect our marketplace.</h3>
    </div>
    <form data-report-item-form="" action="https://support-aftertheharvestkc.b-cdn.netaction" method="post" target="_top">
        <div class="report-item-step">
            <div class="wt-select wt-mb-xs-3">
                <select class="wt-select__element" id="report-item-choices" data-report-item-choices="">
                    <optgroup>
                        <option value="default" selected>Choose a reasonâ€¦</option>
                        <option value="order-problem">Thereâ€™s a problem with my order</option>
                        <option value="ip-policy">It uses my intellectual property without permission</option>
                        <option value="flag-item">I donâ€™t think it meets Etsyâ€™s policies</option>
                    </optgroup>
                </select>
                <label for="report-item-choices" class="wt-screen-reader-only">Choose a reasonâ€¦</label>
            </div>
            <div data-report-choice="order-problem" id="order-problem" class="wt-display-none" style="display: none;">
                <p class="wt-mb-xs-2 prose">The first thing you should do is contact the seller directly.</p>
                <p class="wt-mb-xs-2 ip-policy prose">If youâ€™ve already done that, your item hasnâ€™t arrived, or itâ€™s not as described, you can report that to Etsy by opening a case.</p>
                <p class="wt-mb-xs-2 prose">
                    <a href="https://support-aftertheharvestkc.b-cdn.nethref">
                        Report a problem with an order
                    </a>
                </p>
            </div>
            <div data-report-choice="ip-policy" id="ip-policy" class="wt-display-none" style="display: none;">
                <p class="wt-mb-xs-2 prose">We take intellectual property concerns very seriously, but many of these problems can be resolved directly by the parties involved. We suggest contacting the seller directly to respectfully share your concerns.</p>
                <p class="wt-mb-xs-2 prose">If youâ€™d like to file an allegation of infringement, youâ€™ll need to follow the process described in our <a href="https://support-aftertheharvestkc.b-cdn.nethref">Copyright and Intellectual Property Policy</a>.</p>
            </div>
            <div data-report-choice="flag-item" id="flag-item" class="wt-display-none" style="display: none;">
                <div class="wt-mb-xs-2">
                    <a href="https://support-aftertheharvestkc.b-cdn.nethref">
                        Review how we define handmade, vintage and supplies
                    </a>
                </div>
                <div class="wt-mb-xs-2">
                    <a href="https://support-aftertheharvestkc.b-cdn.nethref">
                        See a list of prohibited items and materials
                    </a>
                </div>
                <div class="wt-mb-xs-4">
                    <a href="https://support-aftertheharvestkc.b-cdn.nethref">
                        Read our mature content policy
                    </a>
                </div>
                <div data-report-reason="" class="wt-validation">
                    <fieldset class="wt-mb-xs-4">
                        <legend class="wt-label wt-mb-xs-2">Tell us why you&#39;re reporting this item</legend>
                            <div class="wt-radio wt-mb-xs-1">
                                <input data-report-reason-input="" data-flag-name="not_handmade_vintage_or_craft" type="radio" class="wt-radio" id="flag_not_handmade_vintage_or_craft" name="flag_type_mnemonic" value="LISTING_CSV_MEMBER_FLAG" />
                                <label for="flag_not_handmade_vintage_or_craft">It&#39;s not handmade, vintage, or craft supplies</label>
                            </div>
                            <div class="wt-radio wt-mb-xs-1">
                                <input data-report-reason-input="" data-flag-name="pornographic" type="radio" class="wt-radio" id="flag_pornographic" name="flag_type_mnemonic" value="OC_PORNOGRAPHY" />
                                <label for="flag_pornographic">It&#39;s pornographic</label>
                            </div>
                            <div class="wt-radio wt-mb-xs-1">
                                <input data-report-reason-input="" data-flag-name="hate_speech_or_harassment" type="radio" class="wt-radio" id="flag_hate_speech_or_harassment" name="flag_type_mnemonic" value="OC_HATE_VIOLENT_HARMFUL" />
                                <label for="flag_hate_speech_or_harassment">It&#39;s hate speech or harassment</label>
                            </div>
                            <div class="wt-radio wt-mb-xs-1">
                                <input data-report-reason-input="" data-flag-name="minor_safety" type="radio" class="wt-radio" id="flag_minor_safety" name="flag_type_mnemonic" value="LISTING_MINOR_SAFETY" />
                                <label for="flag_minor_safety">It&#39;s a threat to minor safety</label>
                            </div>
                            <div class="wt-radio wt-mb-xs-1">
                                <input data-report-reason-input="" data-flag-name="violence_or_self_harm" type="radio" class="wt-radio" id="flag_violence_or_self_harm" name="flag_type_mnemonic" value="OC_HATE_VIOLENT_HARMFUL" />
                                <label for="flag_violence_or_self_harm">It promotes violence or self-harm</label>
                            </div>
                            <div class="wt-radio wt-mb-xs-1">
                                <input data-report-reason-input="" data-flag-name="dangerous_or_hazardous" type="radio" class="wt-radio" id="flag_dangerous_or_hazardous" name="flag_type_mnemonic" value="LISTING_PROHIBITED" />
                                <label for="flag_dangerous_or_hazardous">It&#39;s dangerous or hazardous</label>
                            </div>
                            <div class="wt-radio wt-mb-xs-1">
                                <input data-report-reason-input="" data-flag-name="violates_law" type="radio" class="wt-radio" id="flag_violates_law" name="flag_type_mnemonic" value="CC_REPORTED_ILLEGAL_CONTENT" />
                                <label for="flag_violates_law">It&#39;s violating a specific law or regulation</label>
                            </div>
                            <div class="wt-radio wt-mb-xs-1">
                                <input data-report-reason-input="" data-flag-name="violates_not_listed_policy" type="radio" class="wt-radio" id="flag_violates_not_listed_policy" name="flag_type_mnemonic" value="LISTING_PROHIBITED" />
                                <label for="flag_violates_not_listed_policy">It violates a policy that&#39;s not listed here</label>
                            </div>
                        <div data-error="no-report-reason" id="no-report-reason" class="wt-validation__message wt-validation__message--is-hidden wt-sem-text-critical">Please choose a reason</div>
                    </fieldset>
                </div>
            </div>
        </div>
        <div class="report-item-step wt-display-none">
            <div data-report-comment="" class="wt-validation" tabindex="0">
                <label class="wt-screen-reader-only" for="report-item-reason">Include anything else we should know about this item</label>
                <textarea id="report-item-reason" data-report-comment-input="" name="reason" class="wt-textarea" placeholder="Include anything else we should know about this item"></textarea>
                <div data-error="no-report-comment" id="no-report-comment" class="wt-validation__message wt-validation__message--is-hidden wt-sem-text-critical wt-mt-xs-2">
                    <span class="wt-icon wt-sem-text-on-surface-dark wt-validation__icon"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path fill-rule="evenodd" clip-rule="evenodd" d="M11 6v8h2V6zm1 9.25a1.25 1.25 0 1 0 0 2.5 1.25 1.25 0 0 0 0-2.5"></path></svg></span>Â Make sure to add more details.
                </div>
                <div data-error="comment-min-length-illegal-content" id="comment-min-length-illegal-content" class="wt-validation__message wt-validation__message--is-hidden wt-sem-text-critical wt-mt-xs-2">
                    <span class="wt-icon wt-sem-text-on-surface-dark wt-validation__icon"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path fill-rule="evenodd" clip-rule="evenodd" d="M11 6v8h2V6zm1 9.25a1.25 1.25 0 1 0 0 2.5 1.25 1.25 0 0 0 0-2.5"></path></svg></span>Â Add more details, including a law or regulation name (10 characters min).
                </div>
            </div>
        </div>
        <div data-report-bonafide="" class="wt-mt-xs-2 wt-mb-xs-2 wt-sem-text-secondary wt-display-none">
            By submitting this report, you confirm the information and claims in this form are accurate.
        </div>
        <div data-report-item-overlay-footer="" class="wt-overlay__footer wt-pt-xs-0 wt-display-none" id="overlay-footer" aria-hidden="true" style="display: none;">
            <input type="hidden" name="_nnc" value="3:1758149097:4GUgvh8y5DkVyZZtcEO3WxW_bLVi:fb034c7c38a6074451032687692e755919fbe37e1c1c835e8258dc34b14fb936" class="hidden csrf" />
            <input type="hidden" name="target_id" value="1790774795" />
            <input type="hidden" name="target_type" value="listing" />
            <input type="hidden" name="send_report" value="true" />
            <input type="hidden" name="ref" value="rlp-listing-grid-2" />
            <input type="hidden" name="platform" value="web" />
            <input type="hidden" name="search_query" value="" />
            <div class="wt-overlay__footer__cancel">
                <button data-report-back-button="" type="button" class="wt-btn wt-btn-transparent report-item-step wt-display-none">
                    Go back
                </button>
            </div>
            <div class="wt-overlay__footer__action">
                <button data-report-next-button="" type="button" class="wt-btn wt-btn--primary report-item-step">
                    Next
                </button>
                <button data-report-submit-button="" type="submit" class="wt-btn wt-btn--primary report-item-step wt-display-none">
                    Submit report
                </button>
            </div>
        </div>
    </form>
</div>
        </div>
    </div><div class="wt-overlay image-overlay wt-justify-content-center" data-image-overlay="" data-animate-out="false" id="image-overlay" role="dialog" aria-hidden="true">
    <div class="wt-display-flex-xs wt-justify-content-center wt-height-full image-overlay-main-image-container" data-overlay-modal="">
<button data-clg-id="WtButton" class="wt-btn wt-btn--filled wt-btn--icon wt-btn--light wt-position-absolute wt-position-right wt-position-top wt-mt-xs-2 wt-mr-xs-2" data-wt-overlay-close="true" aria-label="close">
                <span class="wt-icon"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M13.414,12l6.293-6.293a1,1,0,0,0-1.414-1.414L12,10.586,5.707,4.293A1,1,0,0,0,4.293,5.707L10.586,12,4.293,18.293a1,1,0,1,0,1.414,1.414L12,13.414l6.293,6.293a1,1,0,0,0,1.414-1.414Z"></path></svg></span>

</button>
        <div data-overlay-main-image-container="" class="wt-position-relative wt-mr-xl-4 wt-mr-xs-2 wt-ml-xs-2 wt-flex-grow-xs-1 wt-mb-xs-4 wt-mt-xs-10">
<button data-clg-id="WtButton" class="wt-btn wt-btn--filled wt-btn--icon wt-btn--light wt-position-absolute wt-position-left wt-vertical-center wt-shadow-elevation-3 wt-ml-xs-2" data-image-overlay-prev="true" aria-label="previous">
                        <span class="wt-icon"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M16,21a0.994,0.994,0,0,1-.664-0.253L5.5,12l9.841-8.747a1,1,0,0,1,1.328,1.494L8.5,12l8.159,7.253A1,1,0,0,1,16,21Z"></path></svg></span>

</button>
<button data-clg-id="WtButton" class="wt-btn wt-btn--filled wt-btn--icon wt-btn--light wt-position-absolute wt-position-right wt-vertical-center wt-shadow-elevation-3 wt-mr-xs-2" data-image-overlay-next="true" aria-label="next">
                        <span class="wt-icon"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M8,21a1,1,0,0,1-.664-1.747L15.5,12,7.336,4.747A1,1,0,0,1,8.664,3.253L18.5,12,8.664,20.747A0.994,0.994,0,0,1,8,21Z"></path></svg></span>

</button>
            <ul class="wt-list-unstyled wt-overflow-hidden image-overlay-list wt-position-relative wt-vertical-center wt-display-flex-xs wt-justify-content-center" style="padding-top: 80%;" data-image-overlay-list="" tabindex="0">
                    <li class="wt-display-none wt-position-absolute wt-position-top wt-position-left wt-width-full wt-height-full skeleton-background" data-listing-image="" data-index="0" data-image-id="6256816164">
                        <img class="wt-rounded wt-overflow-hidden image-overlay-img wt-object-fit-contain wt-vertical-center image-overlay-image--portrait" alt="Situs Slot Gacor" data-delay-src="https://i.etsystatic.com/54267703/r/il/f18987/6256816164/il_1140xN.6256816164_26ap.jpg" data-delay-srcset="https://i.etsystatic.com/54267703/r/il/f18987/6256816164/il_1140xN.6256816164_26ap.jpg 1x, https://i.etsystatic.com/54267703/r/il/f18987/6256816164/il_1588xN.6256816164_26ap.jpg 2x" data-original-image-width="3000" data-original-image-height="3000" data-index="0" data-src-zoom-image="https://i.etsystatic.com/54267703/r/il/f18987/6256816164/il_fullxfull.6256816164_26ap.jpg" />
                    </li>
                  
                <div class="wt-z-index-1 click-to-zoom-text wt-position-absolute wt-display-none" data-click-to-zoom-toast="">
<span data-clg-id="WtBadge" class="wt-badge wt-badge--default wt-text-body-01 image-overlay-image--landscape">
                        <span class="wt-icon wt-icon--smallest"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M10,2a8,8,0,1,0,8,8A8.009,8.009,0,0,0,10,2Zm0,14a6,6,0,1,1,6-6A6.007,6.007,0,0,1,10,16Z"></path><path d="M14,9H11V6A1,1,0,1,0,9,6V9H6a1,1,0,0,0,0,2H9v3a1,1,0,1,0,2,0V11h3A1,1,0,0,0,14,9Z"></path><path d="M21.707,20.293l-4-4a1,1,0,0,0-1.414,1.414l4,4A1,1,0,0,0,21.707,20.293Z"></path></svg></span>
                    Click to zoom

</span>
                </div>
            </ul>
        </div>

    </div>
</div><div data-toolkit-overlay="" data-wt-overlay="" aria-hidden="true" role="dialog" aria-labelledby="wt-locale-picker-overlay-title" data-overlay-transition="1" id="wt-locale-picker-overlay" class="v2-locale-picker-overlay wt-overlay">
    <div class="wt-overlay__modal wt-text-left-xs" data-overlay-modal="">
        <div class="wt-overlay__header">
            <h2 class="wt-text-title-large" id="wt-locale-picker-overlay-title">Update your settings</h2>
        </div>

        <form method="post" action="" onsubmit="return false" target="_top">

            

            <input type="hidden" name="region_code" value="" />



                <div id="locale-picker-sections-wrap">
                <!--
                <div id="locale_picker_region_code" class="locale_picker_section wt-pb-xs-3 wt-text-left-xs wt-b-xs-none">

                    <label class="wt-label wt-pb-xs-1" for="locale-overlay-select-region_code">Region</label>
                    <div class="wt-select wt-text-body-01">
                        <select id="locale-overlay-select-region_code" name="region_code" class="wt-select__element">
                                <option value="AU" >Australia</option>
                                <option value="CA" >Canada</option>
                                <option value="FR" >France</option>
                                <option value="DE" >Germany</option>
                                <option value="GR" >Greece</option>
                                <option value="IN" >India</option>
                                <option value="IE" >Ireland</option>
                                <option value="IT" >Italy</option>
                                <option value="JP" >Japan</option>
                                <option value="NZ" >New Zealand</option>
                                <option value="PL" >Poland</option>
                                <option value="PT" >Portugal</option>
                                <option value="ES" >Spain</option>
                                <option value="NL" >The Netherlands</option>
                                <option value="GB" >United Kingdom</option>
                                <option value="US" >United States</option>
                            <optgroup label="&mdash;&mdash;&mdash;&mdash;&mdash;&mdash;&mdash;&mdash;">
                                <option value="AF" >Afghanistan</option>
                                <option value="AX" >Ã…land Islands</option>
                                <option value="AL" >Albania</option>
                                <option value="DZ" >Algeria</option>
                                <option value="AS" >American Samoa</option>
                                <option value="AD" >Andorra</option>
                                <option value="AO" >Angola</option>
                                <option value="AI" >Anguilla</option>
                                <option value="AG" >Antigua and Barbuda</option>
                                <option value="AR" >Argentina</option>
                                <option value="AM" >Armenia</option>
                                <option value="AW" >Aruba</option>
                                <option value="AU" >Australia</option>
                                <option value="AT" >Austria</option>
                                <option value="AZ" >Azerbaijan</option>
                                <option value="BS" >Bahamas</option>
                                <option value="BH" >Bahrain</option>
                                <option value="BD" >Bangladesh</option>
                                <option value="BB" >Barbados</option>
                                <option value="BE" >Belgium</option>
                                <option value="BZ" >Belize</option>
                                <option value="BJ" >Benin</option>
                                <option value="BM" >Bermuda</option>
                                <option value="BT" >Bhutan</option>
                                <option value="BO" >Bolivia</option>
                                <option value="BA" >Bosnia and Herzegovina</option>
                                <option value="BW" >Botswana</option>
                                <option value="BV" >Bouvet Island</option>
                                <option value="BR" >Brazil</option>
                                <option value="IO" >British Indian Ocean Territory</option>
                                <option value="VG" >British Virgin Islands</option>
                                <option value="BN" >Brunei</option>
                                <option value="BG" >Bulgaria</option>
                                <option value="BF" >Burkina Faso</option>
                                <option value="BI" >Burundi</option>
                                <option value="KH" >Cambodia</option>
                                <option value="CM" >Cameroon</option>
                                <option value="CA" >Canada</option>
                                <option value="CV" >Cape Verde</option>
                                <option value="KY" >Cayman Islands</option>
                                <option value="CF" >Central African Republic</option>
                                <option value="TD" >Chad</option>
                                <option value="CL" >Chile</option>
                                <option value="CN" >China</option>
                                <option value="CX" >Christmas Island</option>
                                <option value="CC" >Cocos (Keeling) Islands</option>
                                <option value="CO" >Colombia</option>
                                <option value="KM" >Comoros</option>
                                <option value="CG" >Congo, Republic of</option>
                                <option value="CK" >Cook Islands</option>
                                <option value="CR" >Costa Rica</option>
                                <option value="HR" >Croatia</option>
                                <option value="CW" >CuraÃ§ao</option>
                                <option value="CY" >Cyprus</option>
                                <option value="CZ" >Czech Republic</option>
                                <option value="DK" >Denmark</option>
                                <option value="DJ" >Djibouti</option>
                                <option value="DM" >Dominica</option>
                                <option value="DO" >Dominican Republic</option>
                                <option value="EC" >Ecuador</option>
                                <option value="EG" >Egypt</option>
                                <option value="SV" >El Salvador</option>
                                <option value="GQ" >Equatorial Guinea</option>
                                <option value="ER" >Eritrea</option>
                                <option value="EE" >Estonia</option>
                                <option value="ET" >Ethiopia</option>
                                <option value="FK" >Falkland Islands (Malvinas)</option>
                                <option value="FO" >Faroe Islands</option>
                                <option value="FJ" >Fiji</option>
                                <option value="FI" >Finland</option>
                                <option value="FR" >France</option>
                                <option value="GF" >French Guiana</option>
                                <option value="PF" >French Polynesia</option>
                                <option value="TF" >French Southern Territories</option>
                                <option value="GA" >Gabon</option>
                                <option value="GM" >Gambia</option>
                                <option value="GE" >Georgia</option>
                                <option value="DE" >Germany</option>
                                <option value="GH" >Ghana</option>
                                <option value="GI" >Gibraltar</option>
                                <option value="GR" >Greece</option>
                                <option value="GL" >Greenland</option>
                                <option value="GD" >Grenada</option>
                                <option value="GP" >Guadeloupe</option>
                                <option value="GU" >Guam</option>
                                <option value="GT" >Guatemala</option>
                                <option value="GG" >Guernsey</option>
                                <option value="GN" >Guinea</option>
                                <option value="GW" >Guinea-Bissau</option>
                                <option value="GY" >Guyana</option>
                                <option value="HT" >Haiti</option>
                                <option value="HM" >Heard Island and McDonald Islands</option>
                                <option value="VA" >Holy See (Vatican City State)</option>
                                <option value="HN" >Honduras</option>
                                <option value="HK" >Hong Kong</option>
                                <option value="HU" >Hungary</option>
                                <option value="IS" >Iceland</option>
                                <option value="IN" >India</option>
                                <option value="ID" selected="selected">Indonesia</option>
                                <option value="IQ" >Iraq</option>
                                <option value="IE" >Ireland</option>
                                <option value="IM" >Isle of Man</option>
                                <option value="IL" >Israel</option>
                                <option value="IT" >Italy</option>
                                <option value="IC" >Ivory Coast</option>
                                <option value="JM" >Jamaica</option>
                                <option value="JP" >Japan</option>
                                <option value="JE" >Jersey</option>
                                <option value="JO" >Jordan</option>
                                <option value="KZ" >Kazakhstan</option>
                                <option value="KE" >Kenya</option>
                                <option value="KI" >Kiribati</option>
                                <option value="KV" >Kosovo</option>
                                <option value="KW" >Kuwait</option>
                                <option value="KG" >Kyrgyzstan</option>
                                <option value="LA" >Laos</option>
                                <option value="LV" >Latvia</option>
                                <option value="LB" >Lebanon</option>
                                <option value="LS" >Lesotho</option>
                                <option value="LR" >Liberia</option>
                                <option value="LY" >Libya</option>
                                <option value="LI" >Liechtenstein</option>
                                <option value="LT" >Lithuania</option>
                                <option value="LU" >Luxembourg</option>
                                <option value="MO" >Macao</option>
                                <option value="MK" >Macedonia</option>
                                <option value="MG" >Madagascar</option>
                                <option value="MW" >Malawi</option>
                                <option value="MY" >Malaysia</option>
                                <option value="MV" >Maldives</option>
                                <option value="ML" >Mali</option>
                                <option value="MT" >Malta</option>
                                <option value="MH" >Marshall Islands</option>
                                <option value="MQ" >Martinique</option>
                                <option value="MR" >Mauritania</option>
                                <option value="MU" >Mauritius</option>
                                <option value="YT" >Mayotte</option>
                                <option value="MX" >Mexico</option>
                                <option value="FM" >Micronesia, Federated States of</option>
                                <option value="MD" >Moldova</option>
                                <option value="MC" >Monaco</option>
                                <option value="MN" >Mongolia</option>
                                <option value="ME" >Montenegro</option>
                                <option value="MS" >Montserrat</option>
                                <option value="MA" >Morocco</option>
                                <option value="MZ" >Mozambique</option>
                                <option value="MM" >Myanmar (Burma)</option>
                                <option value="NA" >Namibia</option>
                                <option value="NR" >Nauru</option>
                                <option value="NP" >Nepal</option>
                                <option value="AN" >Netherlands Antilles</option>
                                <option value="NC" >New Caledonia</option>
                                <option value="NZ" >New Zealand</option>
                                <option value="NI" >Nicaragua</option>
                                <option value="NE" >Niger</option>
                                <option value="NG" >Nigeria</option>
                                <option value="NU" >Niue</option>
                                <option value="NF" >Norfolk Island</option>
                                <option value="MP" >Northern Mariana Islands</option>
                                <option value="NO" >Norway</option>
                                <option value="OM" >Oman</option>
                                <option value="PK" >Pakistan</option>
                                <option value="PW" >Palau</option>
                                <option value="PS" >Palestinian Territory, Occupied</option>
                                <option value="PA" >Panama</option>
                                <option value="PG" >Papua New Guinea</option>
                                <option value="PY" >Paraguay</option>
                                <option value="PE" >Peru</option>
                                <option value="PH" >Philippines</option>
                                <option value="PL" >Poland</option>
                                <option value="PT" >Portugal</option>
                                <option value="PR" >Puerto Rico</option>
                                <option value="QA" >Qatar</option>
                                <option value="RE" >Reunion</option>
                                <option value="RO" >Romania</option>
                                <option value="RW" >Rwanda</option>
                                <option value="SH" >Saint Helena</option>
                                <option value="KN" >Saint Kitts and Nevis</option>
                                <option value="LC" >Saint Lucia</option>
                                <option value="MF" >Saint Martin (French part)</option>
                                <option value="PM" >Saint Pierre and Miquelon</option>
                                <option value="VC" >Saint Vincent and the Grenadines</option>
                                <option value="WS" >Samoa</option>
                                <option value="SM" >San Marino</option>
                                <option value="ST" >Sao Tome and Principe</option>
                                <option value="SA" >Saudi Arabia</option>
                                <option value="SN" >Senegal</option>
                                <option value="RS" >Serbia</option>
                                <option value="SC" >Seychelles</option>
                                <option value="SL" >Sierra Leone</option>
                                <option value="SG" >Singapore</option>
                                <option value="SX" >Sint Maarten (Dutch part)</option>
                                <option value="SK" >Slovakia</option>
                                <option value="SI" >Slovenia</option>
                                <option value="SB" >Solomon Islands</option>
                                <option value="SO" >Somalia</option>
                                <option value="ZA" >South Africa</option>
                                <option value="GS" >South Georgia and the South Sandwich Islands</option>
                                <option value="KR" >South Korea</option>
                                <option value="SS" >South Sudan</option>
                                <option value="ES" >Spain</option>
                                <option value="LK" >Sri Lanka</option>
                                <option value="SD" >Sudan</option>
                                <option value="SR" >Suriname</option>
                                <option value="SJ" >Svalbard and Jan Mayen</option>
                                <option value="SZ" >Swaziland</option>
                                <option value="SE" >Sweden</option>
                                <option value="CH" >Switzerland</option>
                                <option value="TW" >Taiwan</option>
                                <option value="TJ" >Tajikistan</option>
                                <option value="TZ" >Tanzania</option>
                                <option value="TH" >Thailand</option>
                                <option value="NL" >The Netherlands</option>
                                <option value="TL" >Timor-Leste</option>
                                <option value="TG" >Togo</option>
                                <option value="TK" >Tokelau</option>
                                <option value="TO" >Tonga</option>
                                <option value="TT" >Trinidad</option>
                                <option value="TN" >Tunisia</option>
                                <option value="TR" >TÃ¼rkiye</option>
                                <option value="TM" >Turkmenistan</option>
                                <option value="TC" >Turks and Caicos Islands</option>
                                <option value="TV" >Tuvalu</option>
                                <option value="UG" >Uganda</option>
                                <option value="UA" >Ukraine</option>
                                <option value="AE" >United Arab Emirates</option>
                                <option value="GB" >United Kingdom</option>
                                <option value="US" >United States</option>
                                <option value="UM" >United States Minor Outlying Islands</option>
                                <option value="UY" >Uruguay</option>
                                <option value="VI" >U.S. Virgin Islands</option>
                                <option value="UZ" >Uzbekistan</option>
                                <option value="VU" >Vanuatu</option>
                                <option value="VE" >Venezuela</option>
                                <option value="VN" >Vietnam</option>
                                <option value="WF" >Wallis and Futuna</option>
                                <option value="EH" >Western Sahara</option>
                                <option value="YE" >Yemen</option>
                                <option value="CD" >Zaire (Democratic Republic of Congo)</option>
                                <option value="ZM" >Zambia</option>
                                <option value="ZW" >Zimbabwe</option>
                            </optgroup>
                        </select>
                    </div>
                </div>
                <div id="locale_picker_language_code" class="locale_picker_section wt-pb-xs-3 wt-text-left-xs wt-b-xs-none">

                    <label class="wt-label wt-pb-xs-1" for="locale-overlay-select-language_code">Language</label>
                    <div class="wt-select wt-text-body-01">
                        <select id="locale-overlay-select-language_code" name="language_code" class="wt-select__element">
                                <option value="de" >Deutsch</option>
                                <option value="en-GB" selected="selected">English (UK)</option>
                                <option value="en-IN" >English (IN)</option>
                                <option value="en-US" >English (US)</option>
                                <option value="es" >EspaÃ±ol</option>
                                <option value="fr" >FranÃ§ais</option>
                                <option value="it" >Italiano</option>
                                <option value="ja" >æ—¥æœ¬èªž</option>
                                <option value="nl" >Nederlands</option>
                                <option value="pl" >Polski</option>
                                <option value="pt" >PortuguÃªs</option>
                                <option value="ru" >Ð ÑƒÑÑÐºÐ¸Ð¹</option>
                        </select>
                    </div>
                </div>
                <div id="locale_picker_currency_code" class="locale_picker_section wt-pb-xs-3 wt-text-left-xs wt-b-xs-none">

                    <label class="wt-label wt-pb-xs-1" for="locale-overlay-select-currency_code">Currency</label>
                    <div class="wt-select wt-text-body-01">
                        <select id="locale-overlay-select-currency_code" name="currency_code" class="wt-select__element">
                                <option value="USD" >$ United States Dollar (USD)</option>
                                <option value="CAD" >$ Canadian Dollar (CAD)</option>
                                <option value="EUR" >â‚¬ Euro (EUR)</option>
                                <option value="GBP" >Â£ British Pound (GBP)</option>
                                <option value="AUD" >$ Australian Dollar (AUD)</option>
                                <option value="JPY" >Â¥ Japanese Yen (JPY)</option>
                                <option value="CNY" >Â¥ Chinese Yuan (CNY)</option>
                                <option value="CZK" >KÄ Czech Koruna (CZK)</option>
                                <option value="DKK" >kr Danish Krone (DKK)</option>
                                <option value="HKD" >$ Hong Kong Dollar (HKD)</option>
                                <option value="HUF" >Ft Hungarian Forint (HUF)</option>
                                <option value="INR" >â‚¹ Indian Rupee (INR)</option>
                                <option value="IDR" selected="selected">Rp Indonesian Rupiah (IDR)</option>
                                <option value="ILS" >â‚ª Israeli Shekel (ILS)</option>
                                <option value="MYR" >RM Malaysian Ringgit (MYR)</option>
                                <option value="MXN" >$ Mexican Peso (MXN)</option>
                                <option value="MAD" >DH Moroccan Dirham (MAD)</option>
                                <option value="NZD" >$ New Zealand Dollar (NZD)</option>
                                <option value="NOK" >kr Norwegian Krone (NOK)</option>
                                <option value="PHP" >â‚± Philippine Peso (PHP)</option>
                                <option value="SGD" >$ Singapore Dollar (SGD)</option>
                                <option value="VND" >â‚« Vietnamese Dong (VND)</option>
                                <option value="ZAR" >R South African Rand (ZAR)</option>
                                <option value="SEK" >kr Swedish Krona (SEK)</option>
                                <option value="CHF" >Swiss Franc (CHF)</option>
                                <option value="THB" >à¸¿ Thai Baht (THB)</option>
                                <option value="TWD" >NT$ Taiwan New Dollar (TWD)</option>
                                <option value="TRY" >â‚º Turkish Lira (TRY)</option>
                                <option value="PLN" >zÅ‚ Polish Zloty (PLN)</option>
                                <option value="BRL" >R$ Brazilian Real (BRL)</option>
                        </select>
                    </div>
                </div>
                -->
                </div>
            <div class="wt-overlay__footer wt-justify-content-flex-end">
                <div class="wt-overlay__footer__action">
                    <a type="button" data-wt-overlay-close="" class="wt-btn wt-btn--outline wt-mb-xs-1 wt-mb-md-0 wt-mr-md-1" name="cancel">

                        Cancel
                        <div class="wt-spinner wt-spinner--01" role="alert" aria-live="assertive">
                            <span class="etsy-icon"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><circle fill="transparent" cx="12" cy="12" r="10"></circle></svg></span>
                            Loading
                        </div>

                    </a>
                    <button class="wt-btn wt-btn--filled" action-type="primary" type="submit" name="save" id="locale-overlay-save">
                        Save
                        <div class="wt-spinner wt-spinner--01" role="alert" aria-live="assertive">
                            <span class="etsy-icon"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><circle fill="transparent" cx="12" cy="12" r="10"></circle></svg></span>
                            Loading
                        </div>
                    </button>
                </div>
            </div>
        </form>

    </div>
	<div style="display:none;">

<a href="https://dda.jp/">slotnusa789.online -win</a>
<a href="https://dda.jp/">slotqq707.online -1</a>
<a href="https://dda.jp/">slotvip338.online -win</a>
<a href="https://dda.jp/">slotmega567.online</a>
<a href="https://dda.jp/">slotplay111.online</a>
<a href="https://dda.jp/">slotmenang789.online</a>
<a href="https://dda.jp/">slot mahjong --gempa777</a>
<a href="https://dda.jp/">slot1389.online</a>
<a href="https://dda.jp/">slot mahjong --tt7(tante777)</a>
<a href="https://dda.jp/">slot988pg.online</a>
<a href="https://dda.jp/">mahjong161wede.world -7</a>
<a href="https://dda.jp/">mahjongslot188.online</a>
<a href="https://dda.jp/">mahjong828.online</a>
<a href="https://dda.jp/">mahjong</a>
<a href="https://dda.jp/">mahjongbet122.online</a>
<a href="https://dda.jp/">mahjong gratis</a>
<a href="https://dda.jp/">mahjong333</a>
<a href="https://dda.jp/">mahjong --rtp(jostoto)</a>
<a href="https://dda.jp/">mahjong online</a>
<a href="https://dda.jp/">mahjong game</a>
<a href="https://dda.jp/">slot888mahjong12.world -777</a>
<a href="https://dda.jp/">slot88matauangslot.net - asli</a>
<a href="https://dda.jp/">slot88matauangslot.store - asli</a>
<a href="https://dda.jp/">slot888zeus01 world</a>
<a href="https://dda.jp/">slot880</a>
<a href="https://dda.jp/">deposit 10k bonus 30k</a>
<a href="https://dda.jp/">deposit 10k bonus 20k</a>
<a href="https://dda.jp/">deposit 10k bonus 10k</a>
<a href="https://dda.jp/">deposit 10k jadi 25k</a>
<a href="https://dda.jp/">deposit 10k bonus 15k terbaru</a>
<a href="https://dda.jp/">deposit 5k apk</a>
<a href="https://dda.jp/">deposit 5k spaceman</a>
<a href="https://dda.jp/">deposit 5k via pulsa</a>
<a href="https://dda.jp/">deposit 5k pulsa axis</a>
<a href="https://dda.jp/">deposit 5k dana</a>
<a href="https://dda.jp/">deposit 5k pulsa</a>
<a href="https://dda.jp/">deposit 5k bonus 15k</a>
<a href="https://dda.jp/">deposit 5k pakai pulsa</a>
<a href="https://dda.jp/">deposit 5k qr</a>
<a href="https://dda.jp/">slotjp308.online</a>
<a href="https://dda.jp/">slotjos</a>
<a href="https://dda.jp/">slotjp555.com</a>
<a href="https://dda.jp/">slotjp55.online</a>
<a href="https://dda.jp/">slotjkt</a>
<a href="https://dda.jp/">slot sim</a>
<a href="https://dda.jp/">slot jepang</a>
<a href="https://dda.jp/">slotdj</a>
<a href="https://dda.jp/">slotraja</a>
<a href="https://dda.jp/">slotri. com</a>
<a href="https://dda.jp/">slotroyal</a>
<a href="https://dda.jp/">slotrp apk</a>
<a href="https://dda.jp/">slotraja777 apk</a>
<a href="https://dda.jp/">slotdewa200k.com</a>
<a href="https://dda.jp/">slotcun33.online</a>
<a href="https://dda.jp/">slot88sand77a.online</a>
<a href="https://dda.jp/">slotinter77f.online</a>
<a href="https://dda.jp/">slotwin307.online</a>
<a href="https://dda.jp/">slotwin666.online</a>
<a href="https://dda.jp/">slotplay666.online</a>
<a href="https://dda.jp/">slotdelta138c.online</a>
<a href="https://dda.jp/">situs slot gacor--dorahoki</a>
<a href="https://dda.jp/">situs slot gacor--link(www.arjuna88.com)</a>
<a href="https://dda.jp/">situs slot gacor--winlive4d</a>
<a href="https://dda.jp/">situs slot gacor-caraw4d88</a>
<a href="https://dda.jp/">situs slot gacor-geleak4d</a>
<a href="https://dda.jp/">situs gacor juragankoin99--slot</a>
<a href="https://dda.jp/">situs slot gacor juragankoin99-main</a>
<a href="https://dda.jp/">situs slot gacor---@winlive4d</a>
<a href="https://dda.jp/">situs gacor --slot(enakcuan)</a>
<a href="https://dda.jp/">situs slot gacor spbu777-terbaik</a>
<a href="https://dda.jp/">situs slot gacha168 gacor</a>
<a href="https://dda.jp/">situs slot gacor--fixplay666</a>
<a href="https://dda.jp/">situs slot gacor evohoki.com</a>
<a href="https://dda.jp/">situs slot gacor mitosbet</a>
<a href="https://dda.jp/">situs slot gacor dewazeus33.online</a>
<a href="https://dda.jp/">situs slot gacor matsalot77</a>
<a href="https://dda.jp/">situs slot gacor</a>
<a href="https://dda.jp/">situs slot dewakoing99.masuk gacor</a>
<a href="https://dda.jp/">situs slot gacor-pelaniototo</a>
<a href="https://dda.jp/">situs online slot gacor fokus777</a>
<a href="https://dda.jp/">situs slot gacor--arjuna88</a>
<a href="https://dda.jp/">situs slot gacor spbu777-resmi.com</a>
<a href="https://dda.jp/">situs slot gacor fixslot</a>
<a href="https://dda.jp/">situs slot gacor kamboja paris88</a>
<a href="https://dda.jp/">situs slot gacor --arjuna88</a>
<a href="https://dda.jp/">situs slot gacor nominalbet</a>
<a href="https://dda.jp/">situs slot gacor---@jostoto</a>
<a href="https://dda.jp/">slidesgo</a>
<a href="https://dda.jp/">slipi jaya</a>
<a href="https://dda.jp/">slogan</a>
<a href="https://dda.jp/">gacor02q.com</a>
<a href="https://dda.jp/">gacor303</a>
<a href="https://dda.jp/">gacor66</a>
<a href="https://dda.jp/">gacor899</a>
<a href="https://dda.jp/">mahjongwah305b.com</a>
<a href="https://dda.jp/">mahjongwin707.online</a>
<a href="https://dda.jp/">mahjong</a>
<a href="https://dda.jp/">mahjong333</a>
<a href="https://dda.jp/">mahjong288</a>
<a href="https://dda.jp/">mahjong222</a>
<a href="https://dda.jp/">mahjong--gempa777.com 💯</a>
<a href="https://dda.jp/">mahjong88</a>
<a href="https://dda.jp/">mahjong online</a>
<a href="https://dda.jp/">mahjong gratis</a>
<a href="https://dda.jp/">slotslowin79.online</a>
<a href="https://dda.jp/">slotzeuspw123.online</a>
<a href="https://dda.jp/">slotjp55.online</a>
<a href="https://dda.jp/">slotmenang989.online</a>
<a href="https://dda.jp/">slotplay666.net</a>
<a href="https://dda.jp/">slotjuaratoto282.online</a>
<a href="https://dda.jp/">slotdadu88ss.online</a>
<a href="https://dda.jp/">slot11ts.online</a>
<a href="https://dda.jp/">slot9toko.online</a>
<a href="https://dda.jp/">slotcepatkaya.net</a>
<a href="https://dda.jp/">situsgacor989.online -win</a>
<a href="https://dda.jp/">situstoto858.online -win</a>
<a href="https://dda.jp/">situsraja383.online -vip</a>
<a href="https://dda.jp/">situs77yukivvip.online</a>
<a href="https://dda.jp/">situs gaming --pp(pragmatic77)</a>
<a href="https://dda.jp/">situs gaming --pp(rajadewa138)</a>
<a href="https://dda.jp/">situsraja132hoki.online</a>
<a href="https://dda.jp/">situs gaming --(vipgobetasia.com)</a>
<a href="https://dda.jp/">situsking707.online</a>
<a href="https://dda.jp/">situs mahjong --gempa777</a>
<a href="https://dda.jp/">situs togel777</a>
<a href="https://dda.jp/">link togel 77 live</a>
<a href="https://dda.jp/">bandar togel 77 bandartogel77</a>
<a href="https://dda.jp/">togel77 slot</a>
<a href="https://dda.jp/">lingtogel77 heylink</a>
<a href="https://dda.jp/">buntut togel 77 login link alternatif</a>
<a href="https://dda.jp/">link 77 login</a>
<a href="https://dda.jp/">bandar togel 777 biz</a>
<a href="https://dda.jp/">slot777mahjongwd.world -777</a>
<a href="https://dda.jp/">slot777sup.online -1</a>
<a href="https://dda.jp/">slot777</a>
<a href="https://dda.jp/">slot777idr</a>
<a href="https://dda.jp/">slot777jp</a>
<a href="https://dda.jp/">slot777pro</a>
<a href="https://dda.jp/">slot777bet apk</a>
<a href="https://dda.jp/">slotjp55.online -</a>
<a href="https://dda.jp/">slotmenang989 online</a>
<a href="https://dda.jp/">slot56win online</a>
<a href="https://dda.jp/">slot</a>
<a href="https://dda.jp/">slot game</a>
<a href="https://dda.jp/">sloth</a>
<a href="https://dda.jp/">slot gacor rajadewa138--po</a>
<a href="https://dda.jp/">slot gacor www.gboslot.co</a>
<a href="https://dda.jp/">slot machine</a>
<a href="https://dda.jp/">slotvip</a>
<a href="https://dda.jp/">gacorwin56 online</a>
<a href="https://dda.jp/">gacor108</a>
<a href="https://dda.jp/">gacor55</a>
<a href="https://dda.jp/">gacormania</a>
<a href="https://dda.jp/">gacor108vip.store -</a>
<a href="https://dda.jp/">gacor25</a>
<a href="https://dda.jp/">gacor108 play</a>
<a href="https://dda.jp/">gacorwin678.com -</a>
<a href="https://dda.jp/">gacor —login(dewa138)</a>
<a href="https://dda.jp/">gacor link citibet88.com</a>
<a href="https://dda.jp/">slot mahjong scatter hitam</a>
<a href="https://dda.jp/">slot mahjong macan388</a>
<a href="https://dda.jp/">slot mahjong--po88</a>
<a href="https://dda.jp/">slot mahjong bento4d gacor</a>
<a href="https://dda.jp/">mahjong 3 slot</a>   
<a href="https://dda.jp/">aston138</a>
<a href="https://dda.jp/">aston138 slot gacor</a>
<a href="https://dda.jp/">aston138 slot thailand</a>      
<a href="https://dda.jp/">slot thailand</a>  
<a href="https://dda.jp/">slot mahjong</a>   
<a href="https://dda.jp/">mahjong ways3</a>  
<a href="https://dda.jp/">slot gacor</a>    
<a href="https://dda.jp/">slot mahjong</a> 
<a href="https://dda.jp/">slot online</a>   
<a href="https://dda.jp/">toto 4d</a>
<a href="https://dda.jp/">togel terpercaya</a>   
<a href="https://dda.jp/">slot deposit 5k</a>    
<a href="https://dda.jp/">slot deposit 10k</a>  
<a href="https://dda.jp/">slot deposit 20k</a>   
<a href="https://dda.jp/">slot deposit 25k</a>
<a href="https://dda.jp/">deposit qris</a>     
<a href="https://dda.jp/">deposit ewallet</a> 
<a href="https://dda.jp/">deposit dana</a> 
<a href="https://dda.jp/">deposit ovo</a>    
<a href="https://dda.jp/">deposit gopay</a>  
<a href="https://dda.jp/">slot gacor hari ini </a>
<a href="https://dda.jp">slotplaywin1233b.online -</a>
<a href="https://dda.jp">slotjago79a.online -</a>
<a href="https://dda.jp">slot108vip.online -</a>
<a href="https://dda.jp">slotdelta138a.online -</a>
<a href="https://dda.jp">slotcuan200.online -</a>
<a href="https://dda.jp">slotwin308.online -</a>
<a href="https://dda.jp">slotinter77a.com -</a>
<a href="https://dda.jp">slotbelutjp88.online -</a>
<a href="https://dda.jp">slot88hobicuan.online -</a>
<a href="https://dda.jp">slot777play.online -</a>
<a href="https://dda.jp">slotpetir108.online -</a>
<a href="https://dda.jp">situs</a>
<a href="https://dda.jp">situs</a>
<a href="https://dda.jp">situsyukyuki.online -</a>
<a href="https://dda.jp">situs mahjong --rajadewa138@</a>
<a href="https://dda.jp">situs game --regis(tajirnow.com)</a>
<a href="https://dda.jp">situsarya88.com -</a>
<a href="https://dda.jp">situsayamjago.online ---</a>
<a href="https://dda.jp">situswin308.online -</a>
<a href="https://dda.jp">situs game --regis(rajadewa138.com)</a>
<a href="https://dda.jp">situs dewa200d.com -</a>
<a href="https://dda.jp">slotdewa200e.com -</a>
<a href="https://dda.jp">slotpewetop.online -</a>
<a href="https://dda.jp">slotinter77b.com -</a>
<a href="https://dda.jp">slotbelutjp88.online -</a>
<a href="https://dda.jp">slotwin308.online -</a>
<a href="https://dda.jp">slotwin818.online -</a>
<a href="https://dda.jp">slotdelta138.online -</a>
<a href="https://dda.jp">slot222win2.online -</a>
<a href="https://dda.jp">slotanakslot.online -</a>
<a href="https://dda.jp">slotarya88.online -</a>
<a href="https://dda.jp">slothahacuanb.com -</a>
<a href="https://dda.jp">pgsoftarya88.com -</a>
<a href="https://dda.jp">pragmaticarya88.com -</a>
<a href="https://dda.jp">judislotarya88.online -</a>
<a href="https://dda.jp">situsarya88.com -</a>
<a href="https://dda.jp">linkgacorarya88.com -</a>
<a href="https://dda.jp">slot88arya88.com -</a>
<a href="https://dda.jp">judionlinearya88.com -</a>
<a href="https://dda.jp">bola88arya88.online -</a>
<a href="https://dda.jp">sbobetarya88.online -</a>
<a href="https://dda.jp">judibolaarya88.online -</a>
<a href="https://dda.jp">slot gaming --cuaca889@</a>
<a href="https://dda.jp">situs game --regis(tajirnow.com)</a>
<a href="https://dda.jp">situs game --tpwin</a>
<a href="https://dda.jp">situs game</a>
<a href="https://dda.jp">situs game penghasil uang</a>
<a href="https://dda.jp">situs game --evohoki.com</a>
<a href="https://dda.jp">situs game di laptop</a>
<a href="https://dda.jp">situs game di komputer</a>
<a href="https://dda.jp">situs game ff</a>
<a href="https://dda.jp">situs game offline</a>
<a href="https://dda.jp">situs game penghasil uang tanpa deposit</a>
<a href="https://dda.jp">situs gaming --(arjuna96net.com)</a>
<a href="https://dda.jp">situs gaming --rajadewa138(mobile)</a>
<a href="https://dda.jp">situs gaming -(dewajitu)</a>
<a href="https://dda.jp">situs gaming --ok(panen88)</a>
<a href="https://dda.jp">situs gaming --rajadewa138🏐♣</a>
<a href="https://dda.jp">situs gaming --(nagatoto168)</a>
<a href="https://dda.jp">situs gaming --mitosbet88🔥</a>
<a href="https://dda.jp">situs gaming  --jago79💫</a>
<a href="https://dda.jp">situs gaming --😉panen88</a>
<a href="https://dda.jp">situs gaming kubet</a>
<a href="https://dda.jp">situs web official</a>
<a href="https://dda.jp">judi game</a>
<a href="https://dda.jp">judi game --www(77betsport)</a>
<a href="https://dda.jp">judi game --🍭duren777🍭</a>
<a href="https://dda.jp">judi game --(spinbet99)</a>
<a href="https://dda.jp">judi game --www(jawawin.com)</a>
<a href="https://dda.jp">judi game --pol88💥</a>
<a href="https://dda.jp">judi game --www(gempa777)</a>
<a href="https://dda.jp">judi game --www(enakcuan)</a>
<a href="https://dda.jp">judi game --sektorplay88.com💯</a>
<a href="https://dda.jp">judi game --evohoki.com</a>
<a href="https://dda.jp">judi game online</a>
<a href="https://dda.jp">gacong slotting --sso77</a>
<a href="https://dda.jp">gacong slotting --(duren77)</a>
<a href="https://dda.jp">gacong slotting --(gempa777.com)</a>
<a href="https://dda.jp">gacong slotting -- gempa777</a>
<a href="https://dda.jp">link gaming</a>
<a href="https://dda.jp">link gaming --about(rajadewa138)</a>
<a href="https://dda.jp">link gaming --jago79</a>
<a href="https://dda.jp">link gaming --pphoki.com</a>
<a href="https://dda.jp">link gaming --galaxy77</a>
<a href="https://dda.jp">link gaming --33(dewazeus33)</a>
<a href="https://dda.jp">link gaming --sport(dewabos138.com)</a>
<a href="https://dda.jp">link gaming --sektorplay88.com💯</a>
<a href="https://dda.jp">link gaming --login(idrhoki138)</a>
<a href="https://dda.jp">link gaming --satu(rajadewa138.com)</a>
<a href="https://dda.jp">link pg</a>
<a href="https://dda.jp">link pg --(dewazeus33)</a>
<a href="https://dda.jp">link pg --sektorplay88.com💯</a>
<a href="https://dda.jp">link pg --(nagatoto168)</a>
<a href="https://dda.jp">link pg --evohoki.com</a>
<a href="https://dda.jp">link pgs4d</a>
<a href="https://dda.jp">link pgking</a>
<a href="https://dda.jp">link pgri</a>
<a href="https://dda.jp">link pgas88</a>
<a href="https://dda.jp">link pgri 2025</a>
<a href="https://dda.jp">slotwin222.com -</a>
<a href="https://dda.jp">BIGO234</a>
<a href="https://dda.jp">BNI4D</a>
<a href="https://dda.jp">BRI4D</a>
<a href="https://dda.jp">PASARBARIS</a>
<a href="https://dda.jp">VELOSBET77</a>
<a href="https://dda.jp">BDHOKI88</a>
<a href="https://dda.jp">JUDOL303</a>
<a href="https://dda.jp">BDGACOR88</a>
<a href="https://dda.jp">ASUPAN188</a>
<a href="https://dda.jp">RATUGACOR</a>
<a href="https://dda.jp">ASUPAN188</a>
<a href="https://dda.jp">BIGO234</a>
<a href="https://dda.jp">BOT1423</a>
<a href="https://dda.jp">MALANGBET</a>
<a href="https://dda.jp">LESTARI777</a>
<a href="https://dda.jp">BROMOSLOT</a>
<a href="https://dda.jp">slot jp --paus</a>
<a href="https://dda.jp">situs resmi +-klikslots</a>
<a href="https://dda.jp">situs resmi --gacor(duren777)</a>
<a href="https://dda.jp">situs resmi --asiktoto--</a>
<a href="https://dda.jp">situs resmi --slot(duren77.maxwin)</a>
<a href="https://dda.jp">situs resmi --slot(enakcuan.slot)</a>
<a href="https://dda.jp">situs resmi --a1(haha303)</a>
<a href="https://dda.jp">situs resmi --masuk(gercep88)</a>
<a href="https://dda.jp">situs resmi --tergacor(enakcuan)</a>
<a href="https://dda.jp">situs resmi --maxwin(enakcuan)</a>
<a href="https://dda.jp">situs resmi meriah4dlife.com</a>
<a href="https://dda.jp">situs resmi --jago79</a>
<a href="https://dda.jp">situs resmi --gacor(enakcuan)</a>
<a href="https://dda.jp">situs resmi --slot(duren777)</a>
<a href="https://dda.jp">slot resmi jaya38</a>
<a href="https://dda.jp">slot resmi vip--mami188</a>
<a href="https://dda.jp">slot resmi --solo(duren777)</a>
<a href="https://dda.jp">slot resmi --tergacor(enakcuan)</a>
<a href="https://dda.jp">slot resmi --sis(duren777)</a>
<a href="https://dda.jp">slot resmi m77--com</a>
<a href="https://dda.jp">slot resmi --a(multibet88)</a>
<a href="https://dda.jp">slot resmi --win(wingacor77.net)</a>
<a href="https://dda.jp">slot resmi --deposit(duren777)</a>
<a href="https://dda.jp">slot resmi --maxwin(duren777)</a>
<a href="https://dda.jp">slot resmi --jp(duren777)</a>
<a href="https://dda.jp">slot resmi __jago79.com</a>
<a href="https://dda.jp">slot resmi @naga818.com</a>
<a href="https://dda.jp">slot resmi --jp(enakcuan)</a>
<a href="https://dda.jp">slot resmi --join(gercep88)</a>
<a href="https://dda.jp">situs online mekar99</a>
<a href="https://dda.jp">situs online --(delta138)login</a>
<a href="https://dda.jp">situs online --(oxliga)</a>
<a href="https://dda.jp">situs online -(raja138)</a>
<a href="https://dda.jp">situs online sektorplay88.com</a>
<a href="https://dda.jp">situs online --login(duren777)</a>
<a href="https://dda.jp">situs online --link(nusagg.com)</a>
<a href="https://dda.jp">situs online --pragmatic77</a>
<a href="https://dda.jp">situs online --evohoki❤</a>
<a href="https://dda.jp">situs online (hahacuan117)</a>
<a href="https://dda.jp">situs online --ihokibet❤</a>
<a href="https://dda.jp">situs online gacor-lpo88📌</a>
<a href="https://dda.jp">situs online -- slot duren777</a>
<a href="https://dda.jp">slot online --satu(motowin77</a>
<a href="https://dda.jp">slot online --satu(nagatoto168</a>
<a href="https://dda.jp">slot online --situs(ketuanaga)</a>
<a href="https://dda.jp">slot online --game(mekar99)</a>
<a href="https://dda.jp">slot online gacor pandora188</a>
<a href="https://dda.jp">slot online --tergacor(enakcuan)</a>
<a href="https://dda.jp">slot online sop88</a>
<a href="https://dda.jp">slot online --satu(ez338vip)</a>
<a href="https://dda.jp">slot online v3--asia303</a>
<a href="https://dda.jp">slot online --ok(mekar99)</a>
<a href="https://dda.jp">slot online --satu(bisabet)</a>
<a href="https://dda.jp">slot online --a(mekar99)</a>
<a href="https://dda.jp">slot online --cuan(mekar99)</a>
<a href="https://dda.jp">slot online --satu(77super)</a>
<a href="https://dda.jp">slot online --solo(duren777)</a>
<a href="https://dda.jp">slot online --terpercaya(duren777)</a>
<a href="https://dda.jp">slot online --satu(indosbobet88)</a>
<a href="https://dda.jp">slot online --real(kastoto)</a>
<a href="https://dda.jp">slot online --gacor(mekar99)</a>
<a href="https://dda.jp">slot online --daftar(panen88)</a>
<a href="https://dda.jp">slot online --satu(nagatoto168)</a>
<a href="https://dda.jp">slot online --playwin123@</a>
<a href="https://dda.jp">slot online @naga818.com</a>
<a href="https://dda.jp">slot online --slot(mekar99)</a>
<a href="https://dda.jp">slot online m77</a>
<a href="https://dda.jp">slot online m77--daftar</a>
<a href="https://dda.jp">slot online mami188@</a>
<a href="https://dda.jp">slot online (hahacuan117)</a>
<a href="https://dda.jp">slot online --pragmatic77</a>
<a href="https://dda.jp">slot online --(delta138)login</a>
<a href="https://dda.jp">slot online sektorplay88.com</a>
<a href="https://dda.jp">slot online --(oxliga)</a>
<a href="https://dda.jp">slot online @naga818.com</a>
<a href="https://dda.jp">slot online --duren77(duren777)</a>
<a href="https://dda.jp">slot online mekar99</a>
<a href="https://dda.jp">slot online --gaco88(g88)</a>
<a href="https://dda.jp">slot online - exo88.biz</a>
<a href="https://dda.jp">slot online --gacor(ez338vip)</a>
<a href="https://dda.jp">slot online --mekar99</a>
<a href="https://dda.jp">slot online -- (exo88.world)</a>
<a href="https://dda.jp">slot 79 --jago79</a>
<a href="https://dda.jp">slot okebray.id</a>
<a href="https://dda.jp">slot bukagaming</a>
<a href="https://dda.jp">slot okesultan.net</a>
<a href="https://dda.jp">slot bukagaming.com</a>
<a href="https://dda.jp">slot okebray.com</a>
<a href="https://dda.jp">slot gacor camar4444</a>
<a href="https://dda.jp">slot gacor --kawanmenang</a>
<a href="https://dda.jp">slot gacor sip33</a>
<a href="https://dda.jp">slot gacor kali--royal138--1</a>
<a href="https://dda.jp">slot gacor --(tante777.fun)</a>
<a href="https://dda.jp">slot gacor --gacha168</a>
<a href="https://dda.jp">slot gacor titan777.com</a>
<a href="https://dda.jp">slot gacor normalbet88</a>
<a href="https://dda.jp">slot gacor --link(rajamenang1.com)</a>
<a href="https://dda.jp">slot gacor --super(koko288)</a>
<a href="https://dda.jp">slot gacor microstar88</a>
<a href="https://dda.jp">slot gacor --garansi(permata888)</a>
<a href="https://dda.jp">slot gacor --jam(tokowin99.com)</a>
<a href="https://dda.jp">slot gacor tante777-pasti</a>
<a href="https://dda.jp">slot gacor mami188@</a>
<a href="https://dda.jp">slot gacor --lengkap(koko288)</a>
<a href="https://dda.jp">slot gacor sektorplay88.com</a>
<a href="https://dda.jp">slot gacor --ww(nagamaxwin333.com)</a>
<a href="https://dda.jp">slot gacor evohoki.com</a>
<a href="https://dda.jp">slot gacor normalbet</a>
<a href="https://dda.jp">slot gacor www.londonorient.com</a>
<a href="https://dda.jp">slot gacor --pgsoft1000</a>
<a href="https://dda.jp">slot gacor www.yhteys.org</a>
<a href="https://dda.jp">slot gacor 988slot.com</a>
<a href="https://dda.jp">slot gacor sultankoin99-vip</a>
<a href="https://dda.jp">slot gacor --tiga(haha303)</a>
<a href="https://dda.jp">slot gacor --dua(haha303)</a>
<a href="https://dda.jp">slot gacor c5@@(haha303)</a>
<a href="https://dda.jp">slot gacor b5@@(haha303)</a>
<a href="https://dda.jp">slot gacor p5--(haha303)</a>
<a href="https://dda.jp">slot gacor q2--(haha303)</a>
<a href="https://dda.jp">slot gacor v8--suria88</a>
<a href="https://dda.jp">slot gacor s8--suria88</a>
<a href="https://dda.jp">slot gacor d8--suria88</a>
<a href="https://dda.jp">slot gacor b9--suria88</a>
<a href="https://dda.jp">slot gacor a5--suria88</a>
<a href="https://dda.jp">slot gacor a2--suria88</a>
<a href="https://dda.jp">slot gacor o3--suria88</a>
<a href="https://dda.jp">slot gacor --(suria88)</a>
<a href="https://dda.jp">slot gacor h5--(suria88)</a>
<a href="https://dda.jp">slot gacor --slot(suria88)</a>
<a href="https://dda.jp">slot gacor a1--fila88</a>
<a href="https://dda.jp">slot gacor virus88</a>
<a href="https://dda.jp">slot gacor --situs(dower88.net)</a>
<a href="https://dda.jp">slot gacor g2--(koko288)</a>
<a href="https://dda.jp">slot gacor --fuji(fujiwin88)</a>
<a href="https://dda.jp">slot gacor --www(dower88)</a>
<a href="https://dda.jp">slot gacor viobet.id</a>
<a href="https://dda.jp">slot gacor --(gaco88gacor.com)login</a>
<a href="https://dda.jp">slot gacor (988cnn).com</a>
<a href="https://dda.jp">slot gacor www.dirgawin88.net</a>
<a href="https://dda.jp">slot gacor --kado77</a>
<a href="https://dda.jp">slot gacor m77</a>
<a href="https://dda.jp">slot gacor daftar m77</a>
<a href="https://dda.jp">slot108 --mantap(haha303)</a>
<a href="https://dda.jp">slotting --mantap(haha303)</a>
<a href="https://dda.jp">slot gaming --(arjuna96net.com)</a>
<a href="https://dda.jp">slot gaming --cuaca889@</a>
<a href="https://dda.jp">slot gaming --rajadewa138(mobile)</a>
<a href="https://dda.jp">slot gaming --jago79@</a>
<a href="https://dda.jp">slot gaming --(jawawin.com)</a>
<a href="https://dda.jp">slot gaming --1(rajamenang1.com)</a>
<a href="https://dda.jp">slot gaming --about(idrhoki138)</a>
<a href="https://dda.jp">slot gaming --rajadewa138.com♣</a>
<a href="https://dda.jp">slot gaming --sektorplay88.com💯</a>
<a href="https://dda.jp">slot gaming --nagakoin99</a>
<a href="https://dda.jp">slot gaming --forwin777</a>
<a href="https://dda.jp">slot gaming --win(rajamenang1.com)</a>
<a href="https://dda.jp">slot gaming --(haha303)</a>
<a href="https://dda.jp">slot gaming --rajamenang1(com)</a>
<a href="https://dda.jp">slot gaming --jago79(com)</a>
<a href="https://dda.jp">slot gaming --motowin77</a>
<a href="https://dda.jp">slot gaming dirgawin88.net</a>
<a href="https://dda.jp">slot gaming --(topanwin)</a>
<a href="https://dda.jp">slot gaming --idrhoki138</a>
<a href="https://dda.jp">slot gaming --288(koko288)</a>
<a href="https://dda.jp">situs gaming </a>
<a href="https://dda.jp">situs gaming --(arjuna96net.com)</a>
<a href="https://dda.jp">situs gaming --rajadewa138(mobile) </a>
<a href="https://dda.jp">situs gaming --ok(panen88) </a>
<a href="https://dda.jp">situs gaming -(dewajitu) </a>
<a href="https://dda.jp">situs gaming --rajadewa138🏐♣ </a>
<a href="https://dda.jp">situs gaming --(nagatoto168) </a>
<a href="https://dda.jp">situs gaming --(panen88)</a>
<a href="https://dda.jp">situs gaming --mitosbet88🔥 </a>
<a href="https://dda.jp">casibom</a>
<a href="https://dda.jp">togelhoki234 .com</a>
<a href="https://dda.jp">togel vip789.com</a>
<a href="https://dda.jp">togel 888win.com</a>
<a href="https://dda.jp">togel --gempa777</a>
<a href="https://dda.jp">situs togel --(goldenjitu)</a>
<a href="https://dda.jp">slot --(dower88.net)</a>
<a href="https://dda.jp">slot --(rajamenang1.com)</a>
<a href="https://dda.jp">link gacor @@(dewazeus33)</a>
<a href="https://dda.jp">link gacor --pg(asia303)</a>
<a href="https://dda.jp">link gacor --login(duren777)</a>
<a href="https://dda.jp">link gacor --bonus(jostoto)</a>
<a href="https://dda.jp">link gacor cuan.dewazeus33.com</a>
<a href="https://dda.jp">link gacor 988slot.com</a>
<a href="https://dda.jp">link gacor evohoki</a>
<a href="https://dda.jp">link gacor --pg(haha303)</a>
<a href="https://dda.jp">link gacor q2--(haha303)</a>
<a href="https://dda.jp">link gacor p5--(haha303)</a>
<a href="https://dda.jp">link gacor @(dewazeus33)</a>
<a href="https://dda.jp">link gacor evohoki.com</a>
<a href="https://dda.jp">link gaming --dewazeus33</a>
<a href="https://dda.jp">link gaming --mpocuan88.com</a>
<a href="https://dda.jp">link gaming --idrhoki138</a>
<a href="https://dda.jp">link gaming --(99onlinesport)</a>
<a href="https://dda.jp">link gaming --best(path-tajir365.com)</a>
<a href="https://dda.jp">link bonus(topanwin)</a>
<a href="https://dda.jp">link bonus --303(haha303)</a>
<a href="https://dda.jp">slot maxwin --ligamaster77.it.com</a>
<a href="https://dda.jp">slot maxwin --jambu33</a>
<a href="https://dda.jp">slot maxwin --(vegas338)</a>
<a href="https://dda.jp">slot maxwin --qris(vegas338)</a>
<a href="https://dda.jp">slot maxwin --gudang138(jp)</a>
<a href="https://dda.jp">slot maxwin --vegas338</a>
<a href="https://dda.jp">slot maxwin --(vipdewa)</a>
<a href="https://dda.jp">slot maxwin --(dt138)</a>
<a href="https://dda.jp">slot maxwin --daftar(nagatoto168)</a>
<a href="https://dda.jp">slot maxwin --arunabet</a>
<a href="https://dda.jp">slot maxwin --link(mitosbet88)</a>
<a href="https://dda.jp">slot maxwin --link(nagatoto168)</a>
<a href="https://dda.jp">rtp sso --(sso77)</a>
<a href="https://dda.jp">rtp enak --(enakcuan)</a>
<a href="https://dda.jp">rtp slot +-asiktoto</a>
<a href="https://dda.jp">judi slot --bonus(rajamenang1.com)</a>
<a href="https://dda.jp">judi slot --qris(rajamenang1.com)</a>
<a href="https://dda.jp">judi slot --gacor(rajamenang1.com)</a>
<a href="https://dda.jp">judi slot --bonus(paus4d)</a>
<a href="https://dda.jp">judi slot --login(jajantogel)</a>
<a href="https://dda.jp">judi slot --deposit(duren777)</a>
<a href="https://dda.jp">judi bola --vegas338</a>
<a href="https://dda.jp">judi bola mami188</a>
<a href="https://dda.jp">judi bola --winstar138</a>
<a href="https://dda.jp">judi bola indonesia vs irak</a>
<a href="https://dda.jp">judi bola piala dunia 2026</a>
<a href="https://dda.jp">casino online @naga818.com</a>
<a href="https://dda.jp">casino online --vegas338.com</a>
<a href="https://dda.jp">casino online --evohoki</a>
<a href="https://dda.jp">casino online --ihokibet</a>
<a href="https://dda.jp">casino online --airbet88</a>
<a href="https://dda.jp">slot terpercaya --jos889</a>
<a href="https://dda.jp">agen --🎁motowin77</a>
<a href="https://dda.jp">agen --daftar(koko288)</a>
<a href="https://dda.jp">agen --top(nusantaratoto)</a>
<a href="https://dda.jp">agen --game(duren777)</a>
<a href="https://dda.jp">agen slot --terbaru(vegas338)</a>
<a href="https://dda.jp">agen slot --tergacor(enakcuan)</a>
<a href="https://dda.jp">agen slot --terpercaya(duren777)</a>
<a href="https://dda.jp">agen slot --vegas338🏆</a>
<a href="https://dda.jp">agen slot --⚡vegas338</a>
<a href="https://dda.jp">agen slot --win(wingacor77.net)</a>
<a href="https://dda.jp">agen slot bisabet1.com</a>
<a href="https://dda.jp">agen slot (klikslots.com)</a>
<a href="https://dda.jp">bola slot --josbet--</a>
<a href="https://dda.jp">bola slot josbet</a>
<a href="https://dda.jp">bola slot --gacor(77superslot)</a>
<a href="https://dda.jp">bola slot --mu(depo77)</a>
<a href="https://dda.jp">slot77 gacor --💸sso77</a>
<a href="https://dda.jp">slot77 --sso77</a>
<a href="https://dda.jp">slot777 slot ➤sand77.com</a>
<a href="https://dda.jp">slot777 slot --sand(sand77.co)</a>
<a href="https://dda.jp">slot777 --🎁motowin77</a>
<a href="https://dda.jp">slot777 --💸bisabet</a>
<a href="https://dda.jp">slot777 --jepe(bisabet)</a>
<a href="https://dda.jp">slot777 --🔱bisabet</a>
<a href="https://dda.jp">slot777 --💸(77superslot)</a>
<a href="https://dda.jp">slot777 --gacor(77superslot)</a>
<a href="https://dda.jp">slot777 --terbaik(77superslot)</a>
<a href="https://dda.jp">slot777 login --(77superslot.com)</a>
<a href="https://dda.jp">slot777 @www.3plworldwide.com</a>
<a href="https://dda.jp">slot777 login --77super.com</a>
<a href="https://dda.jp">slot777 slot --terbaik(ez338)</a>
<a href="https://dda.jp">judi bola --(agen878)</a>
<a href="https://dda.jp">judi bola --sektorplay88.com</a>
<a href="https://dda.jp">judi game --duren777</a>
<a href="https://dda.jp">judi game --gempa777</a>
<a href="https://dda.jp">judi game --nusagg.com</a>
<a href="https://dda.jp">judi game --77betsport</a>
<a href="https://dda.jp">judi game --klikslots.com</a>
<a href="https://dda.jp">toto raja789.com</a>
<a href="https://dda.jp">toto king678.com</a>
<a href="https://dda.jp">toto slot --(agen878)</a>
<a href="https://dda.jp">mahjong --apk(gempa777)</a>
<a href="https://dda.jp">mahjong --apk(hagoslot)</a>
<a href="https://dda.jp">mahjong --sso(sso77)</a>
<a href="https://dda.jp">mahjong --terbaik(duren777)</a>
<a href="https://dda.jp">slot mahjong --www(peniti4d)</a>
<a href="https://dda.jp">slot mahjong --daftar(teh33.com)</a>
<a href="https://dda.jp">slot mahjong --nona123</a>
<a href="https://dda.jp">slot mahjong --jeruk33@</a>
<a href="https://dda.jp">slot mahjong --(vegas338)</a>
<a href="https://dda.jp">slot mahjong --www(motowin77)</a>
<a href="https://dda.jp">slot mahjong -www(jambu33.net)</a>
<a href="https://dda.jp">slot mahjong --sektorplay88.com</a>
<a href="https://dda.jp">slot mahjong --terbaru(77superslot)</a>
<a href="https://dda.jp">slot mahjong --situs(jeruk33)</a>
<a href="https://dda.jp">slot mahjong --jos889</a>
<a href="https://dda.jp">slot mahjong apk</a>
<a href="https://dda.jp">slot mahjong 3 demo</a>
<a href="https://dda.jp">slot mahjong 2 gacor</a>
<a href="https://dda.jp">slot maxwin --vipdewa</a>
<a href="https://dda.jp">slot maxwin --gudang138</a>
<a href="https://dda.jp">slot maxwin --kastoto</a>
<a href="https://dda.jp">slot maxwin --josbet</a>
<a href="https://dda.jp">slot maxwin --🚀vegas338</a>
<a href="https://dda.jp">slot maxwin rtp--vegas338⭐</a>
<a href="https://dda.jp">slot maxwin --jajantogel</a>
<a href="https://dda.jp">slot maxwin --vegas338</a>
<a href="https://dda.jp">slot maxwin --77superslot</a>
<a href="https://dda.jp">slot maxwin teshoki</a>
<a href="https://dda.jp">game --www(kingsports99)</a>
<a href="https://dda.jp">game --online(duren777)</a>
<a href="https://dda.jp">situs official --jago79--</a>
<a href="https://dda.jp">situs official --topanwin</a>
<a href="https://dda.jp">situs proxy --bisabet</a>
<a href="https://dda.jp">situs proxy --hobicuan</a>
<a href="https://dda.jp">situs ultra --bisabet</a>
<a href="https://dda.jp">situs gacor --pg(haha303)</a>
<a href="https://dda.jp">situs gacor --asia303🚀</a>
<a href="https://dda.jp">situs gacor (bola88-vip)</a>
<a href="https://dda.jp">situs gacor dewakoin99 no.1</a>
<a href="https://dda.jp">situs gacor juragankoin99.com</a>
<a href="https://dda.jp">situs gacor --asik(japri138)</a>
<a href="https://dda.jp">situs gacor ✅--arena333</a>
<a href="https://dda.jp">situs gacor 988slot.com</a>
<a href="https://dda.jp">situs gacor p5--(haha303)</a>
<a href="https://dda.jp">situs gacor --(rajabet)818.com</a>
<a href="https://dda.jp">situs gacor evohoki.com</a>
<a href="https://dda.jp">situs gacor sultankoin99.win</a>
<a href="https://dda.jp">situs gacor www.dewabos138.com</a>
<a href="https://dda.jp">situs gacor g--login(gaco88)</a>
<a href="https://dda.jp">situs gacor --register(dewabos138.blog)</a>
<a href="https://dda.jp">situs gacor --slot(enakcuan.slot)</a>
<a href="https://dda.jp">situs gacor --slot(duren77.maxwin)</a>
<a href="https://dda.jp">situs gacor --online(nusagg.com)</a>
<a href="https://dda.jp">situs slot --win(rajamenang1.com)</a>
<a href="https://dda.jp">situs slot --(geber88)</a>
<a href="https://dda.jp">situs slot --(spin707)</a>
<a href="https://dda.jp">situs official --jago79.com</a>
<a href="https://dda.jp">link --daftar(koko288)</a>
<a href="https://dda.jp">link --baru(haha303)</a>
<a href="https://dda.jp">link --@(dewazeus33)</a>
<a href="https://dda.jp">link --top(bisabet)</a>
<a href="https://dda.jp">link slot --qris(rajamenang1.com)</a>
<a href="https://dda.jp">link slot @naga818.com</a>
<a href="https://dda.jp">link slot v3--asia303</a>
<a href="https://dda.jp">link slot --solo(duren777)</a>
<a href="https://dda.jp">link slot --(pragmatic218)</a>
<a href="https://dda.jp">link resmi --dt138.com</a>
<a href="https://dda.jp">link gacor --resmi(agen878)</a>
<a href="https://dda.jp">link gacor sultankoin99.vip</a>
<a href="https://dda.jp">link gacor fixislot.com</a>
<a href="https://dda.jp">link gacor --jago79.com</a>
<a href="https://dda.jp">link gacor --daftar(gaco88)</a>
<a href="https://dda.jp">link gacor pg soft.pphoki</a>
<a href="https://dda.jp">link gacor 🎮asia128</a>
<a href="https://dda.jp">link gacor --lp(-dewazeus33.com-)</a>
<a href="https://dda.jp">link rtp bola88-vip</a>
<a href="https://dda.jp">slot thailand --tergacor(enakcuan)</a>
<a href="https://dda.jp">slot thailand --⚡vegas338</a>
<a href="https://dda.jp">slot thailand @@pphoki</a>
<a href="https://dda.jp">slot thailand --evohoki💋</a>
<a href="https://dda.jp">slot thailand --vegas338🤟</a>
<a href="https://dda.jp">slot thailand --server(enakcuan)</a>
<a href="https://dda.jp">slot thailand --vegas338⭐</a>
<a href="https://dda.jp">slot thailand --gacor(77superslot)</a>
<a href="https://dda.jp">slot thailand --🚀vegas338</a>
<a href="https://dda.jp">slot thailand --situs(enakcuan)</a>
<a href="https://dda.jp">slot thailand --vegas338</a>
<a href="https://dda.jp">slot thailand www.dewabos138.com</a>
<a href="https://dda.jp">slot thailand --ihokibet❤</a>
<a href="https://dda.jp">slot thailand --(77superslot)resmi</a>
<a href="https://dda.jp">slot thailand --duren777</a>
<a href="https://dda.jp">slot thailand evohoki.com</a>
<a href="https://dda.jp">situs rajamenang1 --com</a>
<a href="https://dda.jp">situs online o-mami188</a>
<a href="https://dda.jp">situs gaming --138(idrhoki138)</a>
<a href="https://dda.jp">situs gaming --99onlinesports💰</a>
<a href="https://dda.jp">situs gaming --arjuna88</a>
<a href="https://dda.jp">situs gaming --terbaik(ez338vip)</a>
<a href="https://dda.jp">situs gaming --303(haha303)</a>
<a href="https://dda.jp">bandar togel --sektorplay.fun⚡</a>
<a href="https://dda.jp">bandar togel essebet.com</a>
<a href="https://dda.jp">bandar togel 189.com@</a>
<a href="https://dda.jp">bet slot --tergacor(enakcuan)</a>
<a href="https://dda.jp">slot asia --terbaru(enakcuan)</a>
<a href="https://dda.jp">slot asia --🟢motowin77</a>
<a href="https://dda.jp">slot jepang --gacor(vegas338)</a>
<a href="https://dda.jp">slot jepang --vegas338⚡</a>
<a href="https://dda.jp">slot jepang --⭐vegas338.com</a>
<a href="https://dda.jp">rtp slot --🟢motowin77</a>
<a href="https://dda.jp">rtp slot --🎁motowin77</a>
<a href="https://dda.jp">rtp slot --7nagatoto</a>
<a href="https://dda.jp">rtp slot +-asiktoto</a>
<a href="https://dda.jp">rtp slot --asiktoto</a>
<a href="https://dda.jp">rtp slot --gercep88</a>
<a href="https://dda.jp">rtp slot --(gaco88)login</a>
<a href="https://dda.jp">rtp gacor evohoki.com</a>
<a href="https://dda.jp">rtp gacor --tergacor(enakcuan)</a>
<a href="https://dda.jp">rtp gacor --sis(duren777)</a>
<a href="https://dda.jp">rtp gacor --gercep88</a>
<a href="https://dda.jp">rtp gacor --oxliga</a>
<a href="https://dda.jp">rtp gempa --(gempa777)</a>
<a href="https://dda.jp">rtp --mu(@depo77)</a>
<a href="https://dda.jp">pg --baru(nusantaratoto)</a>
<a href="https://dda.jp">pg --terbaru(99onlinesport)</a>
<a href="https://dda.jp">pg --resmi(gempa777)</a>
<a href="https://dda.jp">pg --resmi(enakcuan)</a>
<a href="https://dda.jp">pg --login(99onlinesport)</a>
<a href="https://dda.jp">akun gacor --77superslot🌀</a>
<a href="https://dda.jp">akun gacor --slot(jostoto)</a>
<a href="https://dda.jp">akun slot --77superslot💰</a>
<a href="https://dda.jp">akun slot --asiktoto</a>
<a href="https://dda.jp">slot88 www.kubiktekno.com</a>
<a href="https://dda.jp">slot88 online --💸sso77</a>
<a href="https://dda.jp">slot88 --⚡vegas338</a>
<a href="https://dda.jp">slot88 --vegas338⚡</a>
<a href="https://dda.jp">slot88 --asli(goal55)</a>
<a href="https://dda.jp">slot88 --qris(asia128)</a>
<a href="https://dda.jp">slot88 --jp(duren777)</a>
<a href="https://dda.jp">slot88 --gacor(77superslot)🖐</a>
<a href="https://dda.jp">slot88 --gacor(77superslot)☄</a>
<a href="https://dda.jp">slot88 --gacor(77superslot)</a>
<a href="https://dda.jp">slot88 --indo777📌</a>
<a href="https://dda.jp">slot88 --asia128📌</a>
<a href="https://dda.jp">slot88 --(japri138.online)</a>
<a href="https://dda.jp">slot88 --🎮asia128</a>
<a href="https://dda.jp">slot88 --⚽indo777</a>
<a href="https://dda.jp">slot88 @matauangslot</a>
<a href="https://dda.jp">slot88 ⭐ asg55.com</a>
<a href="https://dda.jp">slot88 ♥ asg55.com</a>
<a href="https://dda.jp">situs slot gacor-kaya33.com</a>
<a href="https://dda.jp">slot okebray.com</a>
<a href="https://dda.jp">demo slot 🔝indo777.com</a>
<a href="https://dda.jp">demo slot --77super</a>
<a href="https://dda.jp">demo slot --mahjong(rajacuan69)</a>
<a href="https://dda.jp">demo slot --ways(rajacuan69)</a>
<a href="https://dda.jp">demo slotting --777(motowin77)</a>
<a href="https://dda.jp">slot demo --🎲sso77</a>
<a href="https://dda.jp">slot demo --🌀sso77</a>
<a href="https://dda.jp">slot demo --🎁motowin77</a>
<a href="https://dda.jp">slot demo --evohoki💋</a>
<a href="https://dda.jp">slot demo --ihokibet💋</a>
<a href="https://dda.jp">slot demo --kingsports99</a>
<a href="https://dda.jp">slot demo --kckslot.com</a>
<a href="https://dda.jp">slot demo --www(depo77.info)</a>
<a href="https://dda.jp">slot demo (ligamaster77.it.com)</a>
<a href="https://dda.jp">agen togel --king4d🔥</a>
<a href="https://dda.jp">slot dana --motowin77</a>
<a href="https://dda.jp">poker online 🎯poker338</a>
<a href="https://dda.jp">poker online 🎯singapoker</a>
<a href="https://dda.jp">poker online -🎁poker338</a>
<a href="https://dda.jp">poker online --singapoker</a>
<a href="https://dda.jp">poker online -- klikslot klikslots com</a>
<a href="https://dda.jp">slot zeus --77super</a>
<a href="https://dda.jp">slot zeus --duren(duren777)</a>
<a href="https://dda.jp">slot zeus --tergacor(enakcuan)</a>
<a href="https://dda.jp">slot pragmatic --hondaslot77</a>
<a href="https://dda.jp">slot pragmatic --togel(duren777)</a>
<a href="https://dda.jp">slot pragmatic --tergacor(enakcuan)</a>
<a href="https://dda.jp">situs game --regis(tajirnow.com) </a>
<a href="https://dda.jp">situs game --tpwin</a>
<a href="https://dda.jp">situs game</a>
<a href="https://dda.jp">situs game di laptop</a>
<a href="https://dda.jp">situs game di komputer</a>
<a href="https://dda.jp">situs game ff</a>
<a href="https://dda.jp">situs game online</a>
<a href="https://dda.jp">situs game offline</a>
<a href="https://dda.jp">situs game ps 2</a>
<a href="https://dda.jp">situs game ps 3</a>
<a href="https://dda.jp">situs game psp</a>
<a href="https://dda.jp">situs game gratis di laptop</a>
<a href="https://dda.jp">XHAMSTER</a>
<a href="https://dda.jp">XNXX COM</a>
<a href="https://dda.jp">YANDEX JAPAN</a>
<a href="https://dda.jp">BOKEP</a>
<a href="https://dda.jp">BOKEP ASIA</a>
<a href="https://dda.jp">BOKEP INDO</a>
<a href="https://dda.jp">BOKEP JEPANG</a>
<a href="https://dda.jp">NENEKTOTO</a>
<a href="https://dda.jp">HYPE168</a>
<a href="https://dda.jp">ZEUS 888 SLOT</a>
<a href="https://dda.jp">ZEUS SLOT MANCING</a>
<a href="https://dda.jp">ZEUS SLOT PRAGMATIC</a>
<a href="https://dda.jp">HONGKONGPOOLS</a>
<a href="https://dda.jp">GRESIKTOTO ALTERNATIF</a>
<a href="https://dda.jp">ZEUS PASTI GACOR</a>
<a href="https://dda.jp">NIA TOGEL</a>
<a href="https://dda.jp">SLOTDEWA200D.COM -</a>
<a href="https://dda.jp">SLOT DEMO</a>
<a href="https://dda.jp">TOTO.MACAU 4D</a>
<a href="https://dda.jp">BANDARTOTO</a>
<a href="https://dda.jp">SITUS GAMING --(ARJUNA96NET.COM)</a>
<a href="https://dda.jp">BIASTOTO</a>
<a href="https://dda.jp">BUJANG TOTO LINK</a>
<a href="https://dda.jp">GRESIKTOTO LOGIN ALTERNATIF</a>
<a href="https://dda.jp">ZEUSSLOT MANCING</a>
<a href="https://dda.jp">NIASTOTO NIAS TOTO LOGIN</a>
<a href="https://dda.jp">EZ338</a>
<a href="https://dda.jp">ZEUS SLOTS DEMO</a>
<a href="https://dda.jp">HERMAN TOTO LOGIN</a>
<a href="https://dda.jp">TOTO HONGKON</a>
<a href="https://dda.jp">SIDNY POOLS</a>
<a href="https://dda.jp">GRISIKTOTO</a>
<a href="https://dda.jp">NIAS TOTI</a>
<a href="https://dda.jp">LINK ZEUS SLOT</a>
<a href="https://dda.jp">SLOT ZEUS --⚡VEGAS338</a>
<a href="https://dda.jp">NISSTOTO</a>
<a href="https://dda.jp">GRESIKTOTO LINK</a>
<a href="https://dda.jp">LINK ZEUS GRATIS</a>
<a href="https://dda.jp">NIAATOTO</a>
<a href="https://dda.jp">HERMAN TOTO LOGIN LINK ALTERNATIF</a>
<a href="https://dda.jp">LINK GRESIKTOTO</a>
<a href="https://dda.jp">LINK SLOT ZEUS</a>
<a href="https://dda.jp">NAISTOTO</a>
<a href="https://dda.jp">ZEUS 88 NET</a>
<a href="https://dda.jp">BUJANG SLOT</a>
<a href="https://dda.jp">GRESIK TOTO LINK ALTERNATIF</a>
<a href="https://dda.jp">BISABET</a>
<a href="https://dda.jp">PRAGMATIC PLAY</a>
<a href="https://dda.jp">SLOT ZEUS GRATIS</a>
<a href="https://dda.jp">SELOT ZEUS</a>
<a href="https://dda.jp">BIMA BET DEMO PRAGMATIC</a>
<a href="https://dda.jp">GAME ZEUS GRATIS</a>
<a href="https://dda.jp">SITUS ZEUS SLOT</a>
<a href="https://dda.jp">TOTO SYDNEY</a>
<a href="https://dda.jp">NIAS TOTO LINK ALTERNATIF LOGIN</a>
<a href="https://dda.jp">BANDAR MACAU</a>
<a href="https://dda.jp">BET TOTO</a>
<a href="https://dda.jp">LIKE TOGEL</a>
<a href="https://dda.jp">NIAS TOTO LINK</a>
<a href="https://dda.jp">BANDAR TOTO MACAU</a>
<a href="https://dda.jp">SLOT MAHJONG --WWW(PENITI4D)</a>
<a href="https://dda.jp">SYDNEY POOLS 4D</a>
<a href="https://dda.jp">SLOT5000</a>
<a href="https://dda.jp">BANDAR TOTO TOGEL</a>
<a href="https://dda.jp">TOTO ONLINE</a>
<a href="https://dda.jp">DEPOBOS</a>
<a href="https://dda.jp">GERSIKTOTO LOGIN</a>
<a href="https://dda.jp">GRESIKTO</a>
<a href="https://dda.jp">GRESIKTOTI</a>
<a href="https://dda.jp">GRESITOTO</a>
<a href="https://dda.jp">UFT.EDU.VE</a>
<a href="https://dda.jp">DEMO ZEUS ASG55+COM</a>
<a href="https://dda.jp">GRESIK TOTO SLOT LOGIN</a>
<a href="https://dda.jp">INATOGEL</a>
<a href="https://dda.jp">LINK SLOT ZEUS GACOR</a>
<a href="https://dda.jp">LOGIN NIASTOTO</a>
<a href="https://dda.jp">NIASYOTO</a>
<a href="https://dda.jp">SEDNEYPOOLS</a>
<a href="https://dda.jp">SLOT ZEUS --VEGAS338⚡</a>
<a href="https://dda.jp">SLOT ZEUS DAFTAR</a>
<a href="https://dda.jp">AERONTOGEL SLOT ZEUS MAXWIN</a>
<a href="https://dda.jp">HERMAN TOTO LINK ALTERNATIF</a>
<a href="https://dda.jp">NIADTOTO</a>
<a href="https://dda.jp">NIASTPTO</a>
<a href="https://dda.jp">ZEUS 88 LOGIN</a>
<a href="https://dda.jp">ZEUS ONLINE SLOT</a>
<a href="https://dda.jp">ZEUS SLOT ADALAH</a>
<a href="https://dda.jp">NIASTOTO ALTERNATIF</a>
<a href="https://dda.jp">NIASTOTO ALTERNATIF LOGIN</a>
<a href="https://dda.jp">NIASTOTO TOGEL LOGIN</a>
<a href="https://dda.jp">SLOT ZEUS 888</a>
<a href="https://dda.jp">SLOT ZEUS LOGIN</a>
<a href="https://dda.jp">SYDNEY POOLS COMMUNITY</a>
<a href="https://dda.jp">TOTOTD</a>
<a href="https://dda.jp">ZEON SELOT</a>
<a href="https://dda.jp">ZEUS HOKI88</a>
<a href="https://dda.jp">ZEUS SLIT</a>
<a href="https://dda.jp">ZEUS SLO</a>
<a href="https://dda.jp">NIASTOTOSLOT</a>
<a href="https://dda.jp">PEDRO 88 SLOT</a>
<a href="https://dda.jp">PEDRO 888 SLOT</a>
<a href="https://dda.jp">SITUS SLOT ZEUS</a>
<a href="https://dda.jp">ZEUS SLOT ITU APA</a>
<a href="https://dda.jp">LOGIN NIAS TOTO</a>
<a href="https://dda.jp">SELOTZEUS</a>
<a href="https://dda.jp">SITUS GACOR ZEUS</a>
<a href="https://dda.jp">SLOT JEUS</a>
<a href="https://dda.jp">SLOT ZEUS PRAGMATIC</a>
<a href="https://dda.jp">AV TOTO LOGIN</a>
<a href="https://dda.jp">LOGIN NEXIATOTO</a>
<a href="https://dda.jp">OMUTOGEL</a>
<a href="https://dda.jp">SLOT ONLINE --SATU(MOTOWIN77</a>
<a href="https://dda.jp">SLOT ZEUZ</a>
<a href="https://dda.jp">JP SLOT ZEUS</a>
<a href="https://dda.jp">RATUMACAU4D</a>
<a href="https://dda.jp">TOTOMACO 4D</a>
<a href="https://dda.jp">ZEUS BET 88</a>
<a href="https://dda.jp">ZEUS SLOT88</a>
<a href="https://dda.jp">ZEUS-SLOT-777</a>
<a href="https://dda.jp">ZEUS SLOT 777 LINK ALTERNATIF</a>
<a href="https://dda.jp">MACAU 4 D</a>
<a href="https://dda.jp">SIDNI POLS</a>
<a href="https://dda.jp">SYDNE POOLS</a>
<a href="https://dda.jp">SYDNY POOLS</a>
<a href="https://dda.jp">LINK NIXTOTO</a>
<a href="https://dda.jp">TOTOMAKAU</a>
<a href="https://dda.jp">TOTO MACAW</a>
<a href="https://dda.jp">SLOT BET 50 RUPIAH</a>
<a href="https://dda.jp">TOTORESMI22</a>
<a href="https://dda.jp">SLOT TERNAMA</a>
<a href="https://dda.jp">TORO U ONLINE</a>
<a href="https://dda.jp">ES TOTO</a>
<a href="https://dda.jp">TOGEL 4D</a>
<a href="https://dda.jp">TOTO SLOT</a>
<a href="https://dda.jp">SLOTWIN308.ONLINE -</a>
<a href="https://dda.jp">JUDI GAME --777(MOTOWIN77)</a>
<a href="https://dda.jp">SDNY POOLS</a>
<a href="https://dda.jp">JAM CARRERA</a>
<a href="https://dda.jp">SITUS TOTO</a>
<a href="https://dda.jp">DATA MACAU 4D</a>
</div>    
</div>
</div><div data-clg-id="WtOverlay" class="wt-overlay wt-overlay--large wt-overlay--has-close-icon" id="country-picker" aria-hidden="true" aria-modal="false" role="dialog" aria-label="Regions Etsy does business in" data-wt-overlay="">
    <div class="wt-overlay__modal" data-overlay-modal="">
            <button type="button" class="wt-btn wt-btn--transparent wt-btn--icon wt-overlay__close-icon wt-btn--light" aria-label="Close" data-wt-overlay-close="">
                <span class="wt-icon"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M13.414,12l6.293-6.293a1,1,0,0,0-1.414-1.414L12,10.586,5.707,4.293A1,1,0,0,0,4.293,5.707L10.586,12,4.293,18.293a1,1,0,1,0,1.414,1.414L12,13.414l6.293,6.293a1,1,0,0,0,1.414-1.414Z"></path></svg></span>
            </button>
        <div data-clg-id="WtOverlayHeader" class="wt-overlay__header">
            <p class="wt-text-heading">Regions Etsy does business in:</p>

</div>



        <div data-clg-id="WtOverlayFooter" class="wt-overlay__footer wt-justify-content-flex-end wt-pt-xs-2 wt-pt-sm-2 wt-pb-sm-0 wt-pt-md-2 wt-height-full">
            <div data-clg-id="WtOverlayFooterButton" class="wt-overlay__footer__action">
    <button data-clg-id="WtButton" class="wt-btn wt-btn--filled wt-pt-xs-0 wt-pb-xs-0 wt-mb-xs-0" data-wt-overlay-close="true">
                Got it

</button>
</div>
        </div>

    </div>
</div></div></div><div id="wt-portal-yellow" style="z-index: 80; position: relative;"></div><div id="wt-portal-orange" style="z-index: 80; position: relative;"></div><div id="wt-portal-red-orange" style="z-index: 80; position: absolute; top: 0px; left: 0px; width: 100%; height: 0px;"><div class="wt-panel__container--hidden" data-positioned="false"><div class="wt-panel wt-panel--anchored wt-mt-xs-2 mini-collections-menu__pane wt-panel--floating wt-panel--hidden"><div class="wt-panel__content-container"><div class="mini-collections-menu__inner-container wt-bg-white wt-p-2-xs"><div class="wt-display-flex-xs wt-justify-content-space-between wt-mb-xs-1 wt-mt-xs-2 wt-mr-xs-2 wt-ml-xs-2"><span class="wt-text-title-large wt-pl-xs-1 wt-align-self-center"><h4 data-initial-focus="true">Add to collection:</h4></span><span class="wt-nudge-t-2"><button type="button" data-testid="skip-button" data-clg-id="WtButton" class="wt-btn wt-btn--transparent wt-btn--small"><span>Skip</span></button></span></div><div class="mini-collections-menu__list wt-overflow-y-scroll wt-overflow-hidden"><ul data-clg-id="WtList" class="wt-list-unstyled" role="list"></ul></div><div class="wt-m-xs-2"><button type="button" data-clg-id="WtButton" class="wt-btn wt-btn--secondary wt-width-full wt-btn--small"><div><span class="wt-icon--smaller wt-nudge-b-1 etsy-icon"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M20,11H13V4a1,1,0,0,0-2,0v7H4a1,1,0,0,0,0,2h7v7a1,1,0,0,0,2,0V13h7A1,1,0,0,0,20,11Z"></path></svg></span><span class="wt-screen-reader-only">create new collection</span><span class="wt-pl-xs-1" aria-hidden="true">Create new</span></div></button></div></div></div><button type="button" aria-label="Close" data-clg-id="WtButton" class="wt-btn wt-btn--secondary wt-panel--anchored__close wt-btn--small wt-btn--icon"><span class="etsy-icon"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M13.414,12l6.293-6.293a1,1,0,0,0-1.414-1.414L12,10.586,5.707,4.293A1,1,0,0,0,4.293,5.707L10.586,12,4.293,18.293a1,1,0,1,0,1.414,1.414L12,13.414l6.293,6.293a1,1,0,0,0,1.414-1.414Z"></path></svg></span></button></div></div><div class="wt-panel__container--hidden" data-positioned="false"><div class="wt-panel wt-panel--anchored wt-mt-xs-2 mini-collections-menu__pane wt-panel--floating wt-panel--hidden"><div class="wt-panel__content-container"><div class="mini-collections-menu__inner-container wt-bg-white wt-p-2-xs"><div class="wt-display-flex-xs wt-justify-content-space-between wt-mb-xs-1 wt-mt-xs-2 wt-mr-xs-2 wt-ml-xs-2"><span class="wt-text-title-large wt-pl-xs-1 wt-align-self-center"><h4 data-initial-focus="true">Add to collection:</h4></span><span class="wt-nudge-t-2"><button type="button" data-testid="skip-button" data-clg-id="WtButton" class="wt-btn wt-btn--transparent wt-btn--small"><span>Skip</span></button></span></div><div class="mini-collections-menu__list wt-overflow-y-scroll wt-overflow-hidden"><ul data-clg-id="WtList" class="wt-list-unstyled" role="list"></ul></div><div class="wt-m-xs-2"><button type="button" data-clg-id="WtButton" class="wt-btn wt-btn--secondary wt-width-full wt-btn--small"><div><span class="wt-icon--smaller wt-nudge-b-1 etsy-icon"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M20,11H13V4a1,1,0,0,0-2,0v7H4a1,1,0,0,0,0,2h7v7a1,1,0,0,0,2,0V13h7A1,1,0,0,0,20,11Z"></path></svg></span><span class="wt-screen-reader-only">create new collection</span><span class="wt-pl-xs-1" aria-hidden="true">Create new</span></div></button></div></div></div><button type="button" aria-label="Close" data-clg-id="WtButton" class="wt-btn wt-btn--secondary wt-panel--anchored__close wt-btn--small wt-btn--icon"><span class="etsy-icon"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M13.414,12l6.293-6.293a1,1,0,0,0-1.414-1.414L12,10.586,5.707,4.293A1,1,0,0,0,4.293,5.707L10.586,12,4.293,18.293a1,1,0,1,0,1.414,1.414L12,13.414l6.293,6.293a1,1,0,0,0,1.414-1.414Z"></path></svg></span></button></div></div></div><div id="wt-portal-red" style="z-index: 80; position: relative;"></div></div>

        <div id="etsy-modal-container" aria-hidden="true"></div>


        <div id="google-tag-manager-container" aria-hidden="true">
            <script nonce="gPiNOjdRCrWLas5Ik2CuS+N0">
        window.dataLayer = [
    {
        "tp_consent": "yes",
        "Language": "en-GB",
        "Region": "ID",
        "Currency": "IDR",
        "UAID": "3risB690iqgVMEj0sW3Jxya5aa04",
        "DetectedRegion": "ID",
        "uuid": 1758149096,
        "request_start_time": 1758149096,
        "emFbPixel": "11a9d82b0db08ee1bdf5e8874494add873c5e08f7c49597639cd462e03210ab5",
        "user_id": 1135369000,
        "uIdFbPixel": "27ad29c17d0610967b5ee7cab259740e2db56c93b1264ce9ec6dd6883b6c660b",
        "externalID": "01772304ca7c493afa29b5226d64be13e19da719f2e2a21509c309907967fb22",
        "fbp": "fb.1.1758102790268.6288693550444878"
    }
];
    </script>

    <noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-KWW5SS"
                    height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
    <script nonce="gPiNOjdRCrWLas5Ik2CuS+N0">(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
        new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
        j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
        'https://www.googletagmanager.com/gtm.js?id='+i+dl;var n=d.querySelector('[nonce]');
        n&&j.setAttribute('nonce',n.nonce||n.getAttribute('nonce'));f.parentNode.insertBefore(j,f);
        })(window,document,'script','dataLayer','GTM-KWW5SS');</script>
        </div>

        

        <script type="text/javascript" nonce="gPiNOjdRCrWLas5Ik2CuS+N0">
    window.__etsy_logging=window.__etsy_logging||{perf:{}};window.__etsy_logging.url="\/\/www.etsy.com\/bcn\/beacon";window.__etsy_logging.defaults={"ab":{"xplat.runtime_config_service.ramp":["on","x","b4354c"],"orm_latency":["off","x","091448"],"ltv_tactics.extended_session_ttl_6mo":["on","w","575c58"],"fastly.cdn_experiment_framework_aa":["off","m","79b68d"],"neu_runtime_tracing_always_on":["off","x","106c3b"],"neu_runtime_tracing":["off","w","6631e5"],"structured_data_attributes_order_dependent":["on","x","691833"],"payments.vat.dont_cache_region":["off","x","1ed96c"],"payments.vat.region_override":["off","x","e81d25"],"google_tag_manager":["on","x","43dc13"],"site_chrome\/buyer_to_seller_navbar_signed_out":["ineligible","e","0efe99"],"checkout.gift_card_cta_in_search_dropdown":["on","x","931866"],"local_pe.q3_2024.search.browser.traffic_split":["on","x","33df41"],"ranking\/search.experience.xml_autosuggest_v4":["all_xml","x","2b2623"],"lingtools\/trending_searches.gcp":["ineligible","e","5cfa03"],"user_persistent_experiment.q3_2025":["global_holdout_continuous","w","7803c7"],"collections.user_experiments.search_bar_shops":["off","x","75df5a"],"site_chrome\/buyer_to_seller_navbar_signed_in":["ineligible","e","67649b"],"persistent_experiment.q3_2025":["on","w","6c0626"],"site_chrome\/buyer_zipcode_in_header_desktop":["off","x","eb55bf"],"site_chrome\/buyer_zipcode_in_header_mweb":["ineligible","e","5d612c"],"builda_scss":["sasquatch","x","96bd82"],"polyfills":["on","x","db574b"],"polyfill_experiment_4":["no_filtering","x","0e8409"],"engagement.notification_feed_aggregation":["on","x","8da111"],"web_deals.deals_and_nondeals_update_feeds":["on","x","a6a52b"],"buyer_support\/etsy_service_holdout":["ineligible","e","fa33b2"],"buyer_support\/etsy_service_launch_layers":["off","w","0f3241"],"web_deals.translate_nav_recs":["on","x","f054b7"],"ranking\/search.experience.category_suggestions_in_autosuggest":["ineligible","e","6e2d9f"],"ranking\/search.experience.contentful_title_on_trending_searches":["on","x","d0b108"],"ranking\/search.experience.always_show_shop_search_in_autosuggest":["on","x","66727b"],"buyer_reviews.accurate_header_review_count":["on","x","426a8c"],"growth_regx.lp_rating_histogram_shop_header_desktop":["off","x","1c99da"],"growth_regx.lp_message_seller_replace_collections_buy_box_desktop_si":["off","x","f17d61"],"gcs_image_reads":["on","x","b7a48f"],"searchx.4q18.dwell_time_as_backend_event":["off","x","d3826b"],"seller_service_squad.convos_condensed_disclosure_copy_update_buyer":["on","x","cadf0d"],"disambiguate_usd_outside_usa":["ineligible","e","c8897d"],"gift_mode.lp_bin_sheet_tiag_v2":["on","x","1beeb9"],"cnc.atc_from_listing_cards_ymal_mfts_desktop":["on","x","58b479"],"perso_custo.buyer_read_from_new_perso_tables":["on","x","dffb8d"],"local_pe.q3_2025.buyer_trust_accelerator.browser.traffic_split":["on","w","eaad53"],"growth_regx.lp_seller_cred_shop_desc_desktop":["on","w","4bc04e"],"cnc.extend_elp_layout_desktop_external":["off","x","fb525e"],"local_pe.q3_2025.international.browser.traffic_split":["on","w","4ca9c3"],"iat.listing_page_hide_similar_items_sash.desktop":["off","x","e2a169"],"loyalty.frequency_override":["off","x","ced4cc"],"loyalty.purchase_days_override":["off","x","2f8ccb"],"cow_layer\/desktop_lp_evolved_favoriting_v2":["on","x","2ca26f"],"growth_regx.lp_bb_trust_redesign_desktop":["off","x","df41b4"],"checkout.klarna_unified_pay_later":["ineligible","e","e11748"],"perso_buyer_squad_layer\/variations_update":["on","x","0e428d"],"perso_custo.multiple_questions_enabled.buyer_side":["on","x","82e6f7"],"seo.listing_shop_faqs_machine_translation":["off","x","ad47eb"],"onsite_promos.superbowl_listing_page_banner":["ineligible","e","2deace"],"inventory.listing_inventory_quantity_select":["off","x","e2182e"],"seller_pricing.make_an_offer_auto_favorite_listing":["ineligible","e","6f5719"],"growth_regx.lp_production_partners_in_item_details":["on","x","3cd0fb"],"growth_regx.lp_review_photo_filter_and_sort_desktop":["on","x","acff7a"],"growth_regx.lp_review_engagement_aa_desktop":["off","x","bfb356"],"growth_regx.lp_new_seller_cred_foundational_desktop":["on","x","bccc3b"],"cnc.anchor_item_lp_recs_desktop":["off","x","315c33"],"cnc.visual_search_tags_external":["off","x","b589cb"],"cnc\/experiment.related_search_pathways_v3_desktop":["ineligible","e","7e808d"],"lp_performance.css_import_cleanup":["on","x","ec2bd2"],"cnc\/experiment.compare_lp_collections_v2_desktop":["ineligible","e","c0c984"],"local_pe.q3_2025.chops.browser.traffic_split":["on","w","2dd4c9"],"chops.elp_related_trends_module.desktop":["on","x","b11d14"],"ads\/takerate.lp_ads_row_expansion.desktop":["ineligible","e","cad35c"],"cnc.listing_card_styling_desktop":["off","w","cef3b1"],"cnc.only_prompt_similar_listing_desktop":["off","x","1f1344"],"core_fulfillment.product_level_readiness_states.core_experience":["off","x","d06c95"],"fulfillment_platform.usps_pm_faster_ga_experiment.web":["on","x","498eec"],"fulfillment_platform.usps_pm_faster_ga_experiment.mobile":["ineligible","e","20f21b"],"fulfillment_ml.ml_predicted_acceptance_scan.uk.operational":["on","x","74db8e"],"fulfillment_ml.ml_predicted_acceptance_scan.uk.experiment_web":["prod","x","9a5255"],"fulfillment_ml.ml_predicted_acceptance_scan.uk.experiment_mobile":["ineligible","e","865516"],"fulfillment_ml.ml_predicted_acceptance_scan.germany.operational":["off","x","4528ab"],"fulfillment_ml.ml_predicted_acceptance_scan.germany.experiment_web":["off","x","cac266"],"fulfillment_ml.ml_predicted_acceptance_scan.germany.experiment_mobile":["ineligible","e","9a29ab"],"fulfillment_platform.edd_cart_caching.web":["edd_and_arizona_cache","x","e313fc"],"fulfillment_platform.edd_cart_caching.mobile":["ineligible","e","ffb947"],"fulfillment_platform.consolidated_country_to_country_ml_times.experiment_web":["prod","x","2eac66"],"fulfillment_platform.consolidated_country_to_country_ml_times.experiment_mobile":["ineligible","e","81b585"],"engagement.skip_notifications_cache":["off","x","4289e3"],"buyer_freq.collecting_flywheel.legacy_notification_set_deprecation":["on","x","34c88b"],"checkout\/paypal_smart_button_desktop":["ineligible","e","07b533"],"checkout\/paypal_smart_button_mweb":["ineligible","e","643355"],"mobile_dynamic_config.iphone.ApplePayPaymentMethods.Girocard":["ineligible","e","fbb78b"],"mobile_dynamic_config.iphone.ApplePayPaymentMethods.CartesBancaires":["ineligible","e","47f399"],"checkout\/google_pay_on_web_v2":["on","x","cbf24c"],"checkout\/add_jcb_cc_payment_method":["on","x","ce90aa"],"checkout\/bin_confidence":["show_cc","x","990cfd"],"checkout.klarna_us_price_bands_v2":["ineligible","e","658ea6"],"checkout.klarna_uk_price_bands_v2":["ineligible","e","c4d855"],"checkout.etsy_bin_on_apple_pay_devices":["on","x","e77719"],"cnc.boe_dataset_related_searches":["on","x","d28934"],"perso_engine.recs.ssq_on_web_u2l_version":["on","x","c2a009"],"perso_engine.recs.ssq_on_web_u2l_version_internal":["on","x","4a8ed2"],"perso_engine.recs.listing_page_external_query_ranker_v2":["off","x","e3548f"],"perso_engine.recs.listing_page_internal_query_ranker_v2_fix":["on","x","e872dc"],"fulfillment_ml.ml_predicted_acceptance_scan.ups_fedex.experiment_web":["on","x","6ef73d"],"fulfillment_ml.ml_predicted_acceptance_scan.ups_fedex.experiment_mobile":["ineligible","e","81c794"],"fulfillment_ml.usps_route_predictor.web":["on","x","7f6b44"],"fulfillment_ml.usps_route_predictor.mobile":["ineligible","e","5a1b77"],"fulfillment_ml.only_display_edd_max.web":["ineligible","e","2d500c"],"fulfillment_ml.only_display_edd_max.mobile":["ineligible","e","07bd93"],"navx.always_images_in_l2":["off","x","d6d388"],"local_pe.q3_2025.search.browser.traffic_split":["on","w","b06317"],"ranking\/search.experience.refinement_pills_in_autosuggest":["ineligible","e","2a2140"],"ranking\/search.experience.trending_searches_in_zero_pane_v2":["on","x","cdb259"],"loyalty.web.reduce_listing_signup_prompts_exp":["on","x","bf6a41"],"cnc.remove_atc_mweb":["ineligible","e","699ff5"],"dynamic_experiments.Merch_JewelrySale25_SkinnyBanner_test_v3":["ineligible","e","89c994"],"dynamic_experiments.Merch_JewelrySale25_SkinnyBanner_test":["ineligible","e","6ff9d7"],"dynamic_experiments.Merch_DDGSkinnyBanner24_V2_test":["ineligible","e","8e97c7"],"dynamic_experiments.Merch_DDGSkinnyBanner24_test":["ineligible","e","5a291a"],"dynamic_experiments.Merch_LaborDay24_Link_test":["ineligible","e","63a995"],"dynamic_experiments.Merch_FDAY24_GiftTeaser_test":["ineligible","e","18d6f7"],"dynamic_experiments.Merch_GiftMode24_Teaser_test":["ineligible","e","3ad555"],"payments.simulate_giftcards_unavailable":["off","x","32e3df"],"api.ab_bubbling_experiment.browser_flag.listzilla_get_listing_state":["ineligible","e","f05e23"],"coreloc.listing_page_local_shipping_signal":["on","x","1bd157"],"eu_crd_compliance.buyer":["on","x","bfc6b5"],"checkout.checkout_sheet_support_for_non_defaults_bin_web":["off","x","4ef136"],"android_image_filename_hack":["ineligible","e","9c9013"],"seller_reach.promotions.mix_and_match.v2_bundles_no_filter":["on","x","cf2d87"],"growth_regx.lp_seller_cred_badges_desktop":["on","x","153a58"],"listing_process.how_its_made_properties.use_module_classifier":["on","x","a5aaed"],"buyer_reviews.seasonal.cyor_holiday_message_2022.desktop":["off","x","c8ee66"],"buyers_often_buying.peek_overlay_with_easier_help_and_shop_access_desktop":["off","x","4960a2"],"buyer_support\/buyer_chatbot_on_help_center.help_menu_on_homepage":["on","x","34f43b"],"navx.fnb_gift_cards_multivariate":["ineligible","e","0fd1cc"],"ranking\/recs.custom_candidates_signal_ranker_v4":["ineligible","e","9b2405"],"ranking\/recs.custom_candidates_signal_ranker_v0":["on","x","3eae86"],"iat.listing_page_trust_suite_banner.desktop":["shield_icon","x","267e29"],"coreloc.digital_download_signal_placement_expansion_desktop":["on","x","70b59f"],"seller_onboarding_layer\/svx.enhanced_verification":["on","x","bdd19d"],"growth_regx.lp_anchor_shop_name_to_seller_cred_desktop":["off","w","53f1a2"],"growth_regx.lp_review_feature_tags_buybox_desktop":["off","x","e7bed6"],"recs_systems.enable_recs_tracking_delivered_events":["on","x","a94bcf"],"growth_regx.lp_review_categorical_tags_in_deep_dive_desktop":["on","x","9d91d4"],"growth_regx.lp_reviews_new_deep_dive_desktop":["sheet_center","w","9a41a1"],"growth_regx.lp_reviews_this_item_badge_desktop":["on","x","1b4475"],"search.use_dark_cluster":["off","x","335bf8"],"search.force_x":["off","x","697d9b"],"cnc.updated_scarcity_signals_lp":["off","x","181046"],"cnc.sidebar_cart_post_atc_recs_v3":["off","x","13c110"],"site_chrome\/cnc.sidebar_cart_zero_to_one":["ineligible","e","45076d"],"site_chrome\/cnc.sidebar_cart_remove_quantity":["on","x","4ea54a"],"cnc.sidebar_cart_open_in_same_tab":["on","x","ed65a2"],"site_chrome\/fullstory\/use_track_event":["ineligible","e","ae465c"],"google_tag_manager_async":["off","x","7585d0"],"qualtrics_survey":["ineligible","e","c3c730"],"qualtrics_survey_non_en":["ineligible","e","5fec45"],"buyer_promise.issue_resolution.buyer_support\/profile_dropdown_to_help_center":["on","x","2d4fea"],"buyers_often_buying.show_discount_prices_on_the_hp_listings":["on","x","e60c20"],"content_moderation.report_item.desktop":["on","x","4dfa1d"],"growth_regx.lp_mask_generated_names_in_reviews":["off","x","ea05d2"],"growth_regx.lp_sh_tenure_to_open_date":["off","w","0c6a3e"],"collections.privacy_clearer_setting_description":["on","x","412fbc"],"prodperfect\/monthly_data_capture":["off","x","137afb"],"buyer_support\/epp_promise_messaging":["ineligible","e","4ebacd"],"growth_regx.lp_view_shop_registration_details":["on","x","fec272"],"ranking\/ad_delivery.ubo_obfuscated_grey_class":["on","x","264198"],"eu_cookie_nag":["ineligible","e","f8045f"],"cnc.related_searches_placement":["off","x","157607"],"gifting.gnav_desktop_flyout":["ineligible","e","55be9d"],"seller_platform_web.buyer_inquiry":["off","x","ee9de4"],"seller_platform_web.seller_local_time":["off","x","98a5ac"],"seller_platform_web.item_detail_overlay":["on","x","cf46a1"],"buyer_promise.issue_resolution.fee_avoidance_v2":["on","x","3a7a9c"],"risk_experience.buyer_email_verification":["ineligible","e","a98aad"]},"user_id":1135369000,"page_guid":"ffd82861b31.44b97b90cfaedc166dd4.00","version":1,"request_uuid":"EuWhMmYDWq2W7QI9Hqf8w2F9Zf4c","cdn-provider":"fastly","header_fingerprint":"ualc","header_signature":"69c9130808b6fc1a3dc577fcfe0bf284","ip_org":"PacketHub","ref":"","loc":"http:\/\/www.etsy.com\/listing\/1790774795\/book-club-print-bookish-poster-trendy?ls=r&ref=rlp-listing-grid-2&external=1&space_id=1359364143966&sts=1&dd=1&content_source=52b99da6862466211894f724d195c6bb%253A2ca474494f71c831169387d00a6b689c028b9d90&logging_key=52b99da6862466211894f724d195c6bb%3A2ca474494f71c831169387d00a6b689c028b9d90","locale_currency_code":"IDR","pref_language":"en-GB","region":"ID","detected_currency_code":"IDR","detected_language":"en-GB","detected_region":"ID","accept-languages":"en-GB,en-US,en,id","ga_client_id":"GA1.1.1638654150.1758102791","isWhiteListedMobileDevice":false,"isMobileRequestIgnoreCookie":false,"isMobileRequest":false,"isMobileDevice":false,"isMobileSupported":false,"isTabletSupported":false,"isTouch":false,"isEtsyApp":false,"isPreviewRequest":false,"isChromeInstantRequest":false,"isMozPrefetchRequest":false,"isTestAccount":false,"isSupportLogin":false,"isInternal":false,"isInWebView":false,"isBot":false,"urlRef":"rlp-listing-grid-2","isAdmin":false,"isSyntheticTest":false,"ebid":"OcKTHyWOrdkY9__kmFV6X2wlf-U45QXJ","event_source":"web","browser_id":"3risB690iqgVMEj0sW3Jxya5aa04","gdpr_tp":3,"gdpr_p":3,"legacy_p":3,"legacy_tp":3,"cmp_tp":true,"cmp_p":true,"page_time":791,"load_strategy":"page_navigation"};
    !function(e,t){var n=e.__etsy_logging,o=n.url,i=n.firedEvents,r=n.defaults,s=r.ab||{},a=n.bots.botCheck,c=n.bots.isBot;n.mergeObject=function(e){for(var t=1;t<arguments.length;t++){var n=arguments[t];for(var o in n)Object.prototype.hasOwnProperty.call(n,o)&&(e[o]=n[o])}return e};!r.ref&&(r.ref=t.referrer),!r.loc&&(r.loc=e.location.href),!r.webkit_page_visibility&&(r.webkit_page_visibility=t.webkitVisibilityState),!r.event_source&&(r.event_source="web"),r.event_logger="frontend",r.isIosApp&&!0===r.isIosApp?r.event_source="ios":r.isAndroidApp&&!0===r.isAndroidApp&&(r.event_source="android"),a.length>0&&(r.botCheck=r.botCheck||[],r.botCheck=r.botCheck.concat(a)),r.isBot=c,t.wasDiscarded&&(r.was_discarded=!0);var v=function(t){if(e.XMLHttpRequest){var n=new XMLHttpRequest;n.open("POST",o,!0),n.send(JSON.stringify(t))}};n.updateLoc=function(e){e!==r.loc&&(r.ref=r.loc,r.loc=e)},n.adminPublishEvent=function(n){"function"==typeof e.CustomEvent&&t.dispatchEvent(new CustomEvent("eventpipeEvent",{detail:n})),i.push(n)},n.sendEvents=function(t,i){var a=r;if("perf"===i){var c={event_logger:i};n.asyncAb&&(c.ab=n.mergeObject({},n.asyncAb,s)),a=n.mergeObject({},r,c)}var f={events:t,shared:a};e.navigator&&"function"==typeof e.navigator.sendBeacon?function(t){t.events.forEach((function(e){e.attempted_send_beacon=!0})),e.navigator.sendBeacon(o,JSON.stringify(t))||(t.events.forEach((function(e){e.send_beacon_failed=!0})),v(t))}(f):v(f),n.adminPublishEvent(f)}}(window,document);
</script>
<script type="text/javascript" nonce="gPiNOjdRCrWLas5Ik2CuS+N0">window.__etsy_logging.perf.event={"attributes":{"guid":"ffd82863095.3df1f9657cf4654ab662.00","event_name":"perf","event_logger":"perf","page_type":"view_listing","device_type":"Desktop","browser_name":"Chrome","browser_version":"140.0.7339.128","ip_city":"Jakarta","ip_region":"JK","ip_country_code":"ID","boromir":true}};!function(e,t){if(!t.hidden){var n=e.__etsy_logging||{},r=n.perf||{},i=n.url,a=n.defaults,o=r.event,s=n.sendEvents,c=0===Object.keys(r).length,u=e.webVitals||{},d=n.mergeObject,m=r.isDev||!1,_=r.skipLoggingEvent||!1,l=r.keepPerfObserverActive||!1,f=null,p=0;if(!c&&i&&a&&o&&s){var g=r.MARK_MEASURE_PREFIX||"_etsy_mark_measure_",v=function(e){var t=!1;return function(){t||(t=!0,e.apply(this,arguments))}},y=function(){return void 0!==e.PerformanceObserver},h=function(){return"onpagehide"in e},T=function(e,n){var r=function(e){var n=t.createElement("a");n.href=e;var r=n.pathname.split(".");return r[r.length-1]||""}(e);return/jpe?g|png|svg|gif/i.test(r)?"image":/eot|woff2?|ttf/i.test(r)?"font":"js"===r?"js":"css"===r?"css":"xmlhttprequest"===n?"xhr":"unknown"},E=function(e){return Math.round(e<Math.pow(2,64)-1?e:0)},b=function(e,n){var r=null,i=null;if(n.transferSize>0)for(var a=0;a<n.serverTiming.length;a++){var o=n.serverTiming[a];e.i_etsystatic_cdn||"cdn"!==o.name?"cache_status"===o.name&&(i=o.description):r=o.description}r&&(e.i_etsystatic_cdn=r);var s=null,c=null;i&&(e.cdn_image_caching||(e.cdn_image_caching={miss:0,hit:0}),s=0===i.indexOf("HIT"),c=0===i.indexOf("MISS"),s&&(e.cdn_image_caching.hit+=1),c&&(e.cdn_image_caching.miss+=1)),function(e,n,r,i){f||(f={},t.querySelectorAll("img[data-perf-group]").forEach((function(e){e.currentSrc&&(f[e.currentSrc]=e)})));var a=f[n.name];if(a){var o=a.dataset.perfGroup;e.categorized_images||(e.categorized_images=[]);var s={category:o,duration:E(n.duration),encodedBodySize:E(n.encodedBodySize),transferSize:E(n.transferSize),width:a.width,height:a.height};if(n.transferSize>0){(r||i)&&(s.cdn_hit=r);for(var c=0;c<n.serverTiming.length;c++){var u=n.serverTiming[c];"clientrtt"===u.name?s.clientrtt=E(u.duration):"clienttt"===u.name?s.clienttt=E(u.duration):"cdntime"===u.name?s.cdntime=E(u.duration):"origin"===u.name&&(s.origin=E(u.duration))}}e.categorized_images.push(s)}}(e,n,s,c)},S=function(e){var t={nav_start:E(e.navigationStart||e.startTime),activation_start:E(e.activationStart||0),fetch_start:E(e.fetchStart),dns_start:E(e.domainLookupStart),dns_end:E(e.domainLookupEnd),connect_start:E(e.connectStart),connect_end:E(e.connectEnd),interim_response_start:E(e.firstInterimResponseStart||0),request_start:E(e.requestStart),response_start:E(e.responseStart),response_end:E(e.responseEnd),dom_completed:E(e.domComplete),dom_interactive:E(e.domInteractive),secure_connect_start:E(e.secureConnectionStart)||null,loaded_start:E(e.loadEventStart)||null,loaded_end:E(e.loadEventEnd)||null,dom_content_loaded_start:E(e.domContentLoadedEventStart)||null,dom_content_loaded_end:E(e.domContentLoadedEventEnd)||null,html_tx_size:E(e.transferSize),html_enc_size:E(e.encodedBodySize),html_dec_size:E(e.decodedBodySize),type:e.type};return e.redirectStart&&(t.redirect_start=E(e.redirectStart)),e.redirectEnd&&(t.redirect_end=E(e.redirectEnd)),e.redirectCount&&(t.redirect_count=e.redirectCount),t},k=function(e){return e.reduce((function(e,t){if("entryType"in t){if("resource"===t.entryType)return function(e,t){var n=T(t.name,t.initiatorType);if("unknown"===n)return e;var r=t.name.match(/etsy(static)?(cloud)?\.com/)?"etsy":"third";"image"===n&&"etsy"===r&&(t.name.match(/img0\.etsystatic/)?e.img0_count=(e.img0_count||0)+1:t.name.match(/img1\.etsystatic/)&&(e.img1_count=(e.img1_count||0)+1)),"image"===n&&"etsy"===r&&t.serverTiming&&t.name.match(/i\.etsystatic\.com/)&&b(e,t);var i="sum_"+r+"_"+n+"_bytes",a="sum_"+r+"_"+n+"_enc_bytes",o="sum_"+r+"_"+n+"_tx_bytes",s="sum_"+r+"_"+n+"_dur",c="count_"+r+"_"+n+"_req";return e[i]=(e[i]||0)+E(t.decodedBodySize),e[a]=(e[a]||0)+E(t.encodedBodySize),e[o]=(e[o]||0)+E(t.transferSize),e[s]=(e[s]||0)+E(t.duration),e[c]=(e[c]||0)+1,e}(e,t);if("paint"===t.entryType)return function(e,t){return e[t.name.replace(/-/g,"_")]=E(t.startTime),e}(e,t);if("longtask"===t.entryType)return function(e,t){return e.long_tasks_count=(e.long_tasks_count||0)+1,e.long_tasks_dur=(e.long_tasks_dur||0)+E(t.duration),e}(e,t);if("mark"===t.entryType||"measure"===t.entryType)return function(e,t){return 0===t.name.lastIndexOf(g,0)&&(e[0===t.name.lastIndexOf(g+"async_spec_",0)?t.name.substring(g.length):t.name]=E("mark"===t.entryType?t.startTime:t.duration)),e}(e,t);if("layout-shift"===t.entryType&&!t.hadRecentInput)return function(e,t){return e.layout_shift_count=(e.layout_shift_count||0)+1,e.layout_shift=(e.layout_shift||0)+t.value,t.value>.05&&(e.layout_shift_elements=e.layout_shift_elements||[],e.layout_shift_elements.push({value:t.value,elements:(t.sources||[]).filter((function(e){return!!e.node})).map((function(e){return{className:e.node.classList&&Array.prototype.slice.call(e.node.classList).join(" "),tagName:e.node.tagName,id:e.node.id}}))})),e}(e,t);if("navigation"===t.entryType)return r.t=!0,d(e,S(t));if("element"===t.entryType)return function(e,t){return e.element_timings||(e.element_timings={}),e.element_timings[t.identifier]=t.renderTime,e}(e,t);if("long-animation-frame"===t.entryType)return function(e,t){e.loaf_entries||(e.loaf_entries=[]);var n={start:E(t.startTime),duration:E(t.duration),blockingDuration:E(t.blockingDuration)},r=t.scripts.slice().sort((function(e,t){t.duration,e.duration}))[0];if(r){var i=r.invoker||r.name;n.longestScript={invokerType:r.invokerType||r.type,duration:E(r.duration),invoker:i.substring(0,1024),sourceURL:r.sourceURL||null}}return e.loaf_entries.push(n),e}(e,t)}else if("name"in t){if("INP"===t.name)return function(e,t){return e.interaction_next_paint=t.value,t.attribution&&(e.interaction_next_paint_element=t.attribution.eventTarget,e.interaction_next_paint_time=E(t.attribution.eventTime),e.interaction_next_paint_type=t.attribution.eventType,e.interaction_next_paint_loadstate=t.attribution.loadState),e}(e,t);if("LCP"===t.name)return function(e,t){var n=t.entries[0];return e.largest_contentful_paint=E(n.renderTime||n.loadTime),e.largest_contentful_paint_type=n.renderTime?"renderTime":"loadTime",n.element?(e.largest_contentful_paint_element={className:n.element.classList&&Array.prototype.slice.call(n.element.classList).join(" "),tagName:n.element.tagName,url:n.url},t.attribution.lcpResourceEntry&&(e.largest_contentful_paint_element.resource_size=E(t.attribution.lcpResourceEntry.encodedBodySize))):delete e.largest_contentful_paint_element,e.lcp_element_render_delay=E(t.attribution.elementRenderDelay),e.lcp_resource_load_delay=E(t.attribution.resourceLoadDelay),e.lcp_resource_load_time=E(t.attribution.resourceLoadTime),e}(e,t)}return e}),{})},L=function(){var n,i=!y()&&performance&&performance.getEntries?performance.getEntries():r.e,a=k(i);return r.e=[],r.t||(a.unixTimingNavigation=!0,d(a,S(e.performance.timing))),d(a,function(){if(performance&&performance.getEntriesByName){var e=performance.getEntriesByName("TTP","mark");if(e.length)return{time_to_parsing:E(e[0].startTime)}}return{}}()),d(a,{dom_count_server:p,dom_count_client:t.getElementsByTagName("*").length}),d(a,{dom_max_depth:(n=function(e){if(!e)return 0;for(var t=0,r=0,i=e.children.length;r<i;r++)t=Math.max(t,n(e.children[r]));return t+1})(t.documentElement)}),function(e){var t=navigator;t&&t.connection&&t.connection.effectiveType&&(e.effective_connection_type=t.connection.effectiveType)}(a),a.has_sendbeacon=navigator&&"function"==typeof navigator.sendBeacon,a.has_observer=y(),y()&&PerformanceObserver.supportedEntryTypes&&(a.observer_types=PerformanceObserver.supportedEntryTypes),a.has_pagehide=h(),r.vm_hostname&&(a.vm_hostname=r.vm_hostname),a},z=v((function(n){var r=d(n,o.attributes);r.beacon_send_time=0===r.nav_start?E(performance.now()):(new Date).getTime(),r.page_time=a.page_time,"function"==typeof e.CustomEvent&&t.dispatchEvent(new CustomEvent("perfDataSent",{detail:r})),s([r],"perf")}));!function(){var n=function(e){r.e.length&&(r.e=r.e.concat(e))};if(!!u.onINP&&u.onINP(n,{reportAllChanges:!0}),u.onLCP&&u.onLCP(n),y()&&PerformanceObserver.supportedEntryTypes&&PerformanceObserver.supportedEntryTypes.includes("long-animation-frame")){var i=new PerformanceObserver((function(e){e.getEntries().forEach((function(e){e.duration>150&&e.firstUIEventTimestamp>0&&n(e)}))}));i.observe({type:"long-animation-frame",buffered:!0})}if(!_){var a,o=v((function(e){if(!t.hidden||"on_vischange"===e){clearTimeout(a);var n=L();!l&&y()&&(r.o.disconnect(),i&&i.disconnect()),n[e]=!0,z(n)}})),s=function(){return m&&e.__KEVIN_IS_STILL_BUILDING};m||(a=setTimeout((function(){o("on_fallbacktimeout")}),6e4),"complete"===t.readyState&&(clearTimeout(a),a=setTimeout((function(){o("on_loadtimeout")}),2e4))),t.addEventListener("readystatechange",(function(){"interactive"===t.readyState&&(p=t.getElementsByTagName("*").length)})),e.addEventListener("load",(function(){clearTimeout(a),s()||(a=setTimeout((function(){o("on_loadtimeout")}),2e4))}));var c=function(e){var t=e||"on_unload";s()?(0===performance.getEntriesByName(`${r.MARK_MEASURE_PREFIX}dev_kevin-overlay-end`).length&&performance.mark(`${r.MARK_MEASURE_PREFIX}dev_kevin-overlay-abandoned-before-done`),setTimeout((function(){o(t)}),0)):o(t)},d=h()?"pagehide":"unload";e.addEventListener(d,c),m&&e.addEventListener("beforeunload",c),t.addEventListener("visibilitychange",(function(){t.hidden&&c("on_vischange")}))}}(),r.logger={getMetricsFromQueue:k}}else n.eventpipe&&n.eventpipe.logEvent&&n.eventpipe.logEvent({event_name:"perf_beacon_not_fired",missing_global_perf_data:c,missing_post_url:!i,missing_defaults:!a,missing_perf_event:!o,missing_send_events:!s})}}(window,document);;</script>
<script type="text/javascript" nonce="gPiNOjdRCrWLas5Ik2CuS+N0">window.__etsy_logging.eventpipe.primary_complement={"attributes":{"guid":"ffd82863091.aa4443168e8dd09088ac.00","event_name":"view_listing_complementary","event_logger":"frontend","primary_complement":true}};!function(e){var t=e.__etsy_logging,i=t.eventpipe,n=i.primary_complement,o=t.defaults.page_guid,r=t.sendEvents,a=i.q,c=void 0,d=[],h=0,u="frontend",l="perf";function g(){var e,t,i=(h++).toString(16);return o.substr(0,o.length-2)+((t=2-(e=i).length)>0?new Array(t+1).join("0")+e:e)}function v(e){e.guid=g(),c&&(clearTimeout(c),c=void 0),d.push(e),c=setTimeout((function(){r(d,u),d=[]}),50)}!function(t){var i=document.documentElement;i&&(i.clientWidth&&(t.viewport_width=i.clientWidth),i.clientHeight&&(t.viewport_height=i.clientHeight));var n=e.screen;n&&(n.height&&(t.screen_height=n.height),n.width&&(t.screen_width=n.width)),e.devicePixelRatio&&(t.device_pixel_ratio=e.devicePixelRatio),e.orientation&&(t.orientation=e.orientation),e.matchMedia&&(t.dark_mode_enabled=e.matchMedia("(prefers-color-scheme: dark)").matches)}(n.attributes),v(n.attributes),i.logEvent=v,i.logEventImmediately=function(e){var t="perf"===e.event_name?l:u;e.guid=g(),r([e],t)},a.forEach((function(e){v(e)}))}(window);</script>

        
        


            <script nonce="gPiNOjdRCrWLas5Ik2CuS+N0">if(window.console){console.log("Is code your craft? https://careers.etsy.com")}</script>
    
<div id="privacy-settings-manager-load-complete" style="display: none;"></div><div id="footer-script-loaded" style="display: none;"></div><div id="privacy-settings-manager-load-complete" style="display: none;"></div><div id="footer-script-loaded" style="display: none;"></div><script type="text/javascript" id="" charset="">!function(c,d,g,e,a,f,b){c.ktag||(a=function(){a.sendEvent?a.sendEvent(arguments):a.ktq.push(arguments)},a.ktq=[],c.ktag=a,f=d.getElementsByTagName(e)[0],b=d.createElement(e),b.async=!0,b.src=g,f.parentNode.appendChild(b))}(window,document,"https://resources.xg4ken.com/js/v2/ktag.js?tid\x3dKT-N3E88-3EB","script");ktag("setup","KT-N3E88-3EB","\x3cUSER_ID\x3e");</script>
<iframe height="0" width="0" style="display: none; visibility: hidden;"></iframe><noscript>
	<img src="https://events.xg4ken.com/pixel/v2?tid=KT-N3E88-3EB&amp;noscript=1" width="1" height="1" style="display:none">
</noscript><div id="batBeacon424272525124" style="width: 0px; height: 0px; display: none; visibility: hidden;"><img id="batBeacon707183602964" width="0" height="0" alt="" src="https://bat.bing.com/action/0?ti=20013160&amp;tm=gtm002&amp;Ver=2&amp;mid=3f2fa233-444b-4e87-a5c4-0277499c4be4&amp;bo=1&amp;sid=e9c37f10b15111f0bd73ef3ba36f6585&amp;vid=e9c464f0b15111f0967cbb74f0068489&amp;vids=1&amp;msclkid=N&amp;pi=0&amp;lg=en-US&amp;sw=412&amp;sh=732&amp;sc=24&amp;tl=Situs Slot Gacor%20%7C%20Link%20Pusat%20Situs%20Toto%20Terbaik%20Dengan%20Server%20Togel%20Resmi%20Hari%20Ini&amp;p=https%3A%2F%2Fwww.turismo.sanjuandelrio.gob.mx%2F&amp;r=&amp;lt=20&amp;mtp=1&amp;evt=pageLoad&amp;sv=2&amp;cdb=AQAS&amp;rn=945993" style="width: 0px; height: 0px; display: none; visibility: hidden;" /></div>
<div id="privacy-settings-manager-load-complete" style="display: none;"></div><div id="footer-script-loaded" style="display: none;"></div><div id="privacy-settings-manager-load-complete" style="display: none;"></div><div id="footer-script-loaded" style="display: none;"></div></body></html>
