#!/usr/bin/env python3
import os, zlib, base64, random, string, sys

def rnd(k=8):
    import random, string
    return ''.join(random.choice(string.ascii_letters) for _ in range(k))

def hard_encode_html(input_file, output_file):
    if not os.path.exists(input_file):
        print(f"[!] File {input_file} tidak ditemukan")
        return
    
    # baca file asli
    with open(input_file, "rb") as f:
        raw = f.read()

    # compress + base64
    comp = zlib.compress(raw, 9)
    b64 = base64.b64encode(comp).decode("ascii")

    # pecah string jadi beberapa bagian acak, lalu balik tiap chunk
    chunks, i, n = [], 0, len(b64)
    while i < n:
        size = random.randint(200, 600)
        chunk = b64[i:i+size]
        chunks.append(chunk[::-1])
        i += size

    # obfuscasi nama variabel
    var_chunks = rnd(10)
    var_out = rnd(8)
    func_run = rnd(10)
    doc_msg = rnd(6)

    # buat JS loader
    js_lines = [f"var {var_chunks} = [];"]
    for c in chunks:
        esc = c.replace("\\", "\\\\").replace('"', '\\"').replace("'", "\\'")
        js_lines.append(f"{var_chunks}.push('{esc}');")
    js_lines.append(f"function {func_run}(){{")
    js_lines.append(f"  try{{")
    js_lines.append(f"    for(var i=0;i<{var_chunks}.length;i++){{ {var_chunks}[i] = {var_chunks}[i].split('').reverse().join(''); }}")
    js_lines.append(f"    var joined = {var_chunks}.join('');")
    js_lines.append(f"    var bin = atob(joined);")
    js_lines.append(f"    var bytes = new Uint8Array(bin.length);")
    js_lines.append(f"    for(var i=0;i<bin.length;i++) bytes[i] = bin.charCodeAt(i);")
    js_lines.append(f"    var {var_out} = window.pako.inflate(bytes, {{to:'string'}});")
    js_lines.append(f"    document.open(); document.write({var_out}); document.close();")
    js_lines.append(f"  }}catch(e){{ document.getElementById('{doc_msg}').innerText = 'Decode error: '+e; }}")
    js_lines.append(f"}}")

    js_code = "\n".join(js_lines)
    js_b64 = base64.b64encode(js_code.encode("utf-8")).decode("ascii")

    # final HTML wrapper
    html = f"""<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Protected</title>
<meta name="viewport" content="width=device-width,initial-scale=1">
<style>body{{background:#0b0b0b;color:#e6e6e6;font-family:system-ui;padding:18px}}</style>
</head>
<body>
<p id="{doc_msg}">Initializing...</p>
<noscript><p style="color:orange">Enable JavaScript to view this page.</p></noscript>
<script>
(function(){{
  function loadScript(url, cb){{var s=document.createElement('script');s.src=url;s.onload=cb;s.onerror=cb;document.head.appendChild(s);}}
  var run = function(){{
    try{{
      var __code = atob("{js_b64}");
      (1,eval)(__code);
      if(typeof {func_run} === 'function') {{ {func_run}(); }}
    }}catch(e){{ document.getElementById("{doc_msg}").innerText='Loader error: '+e; }}
  }};
  if(window.pako && window.pako.inflate) run();
  else loadScript('https://cdnjs.cloudflare.com/ajax/libs/pako/2.1.0/pako.min.js', run);
}})();
</script>
</body>
</html>"""

    with open(output_file, "w", encoding="utf-8") as f:
        f.write(html)

    print(f"[+] Hasil encode tersimpan di {output_file}")


if __name__ == "__main__":
    if len(sys.argv) != 3:
        print("Usage: python3 hard_encode_html.py <input.html> <output.html>")
        sys.exit(1)

    inp, outp = sys.argv[1], sys.argv[2]
    hard_encode_html(inp, outp)
