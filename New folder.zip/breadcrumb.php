<?php
/**
 * Breadcrumb helper functions
 *
 * @package Education_Hub
 */

if ( ! function_exists( 'education_hub_breadcrumb' ) ) :
    /**
     * Display breadcrumb.
     */
    function education_hub_breadcrumb() {
        $breadcrumb_type = education_hub_get_theme_option( 'breadcrumb_type' );
        
        if ( 'disabled' === $breadcrumb_type ) {
            return;
        }
        
        if ( ! function_exists( 'breadcrumb_trail' ) ) {
            require_once get_template_directory() . '/inc/breadcrumb-trail/breadcrumb-trail.php';
        }
        
        $args = array(
            'container'     => 'div',
            'show_browse'   => false,
            'labels'        => array(
                'home' => esc_html__( 'Home', 'education-hub' ),
            ),
        );
        
        breadcrumb_trail( $args );
    }
endif;
?>