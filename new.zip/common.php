<?php
/**
 * Common helper functions for Education Hub Theme
 *
 * @package Education_Hub
 */

if ( ! function_exists( 'education_hub_get_theme_options' ) ) :
    /**
     * Get theme options.
     */
    function education_hub_get_theme_options() {
        return wp_parse_args(
            get_option( 'education_hub_theme_options', array() ),
            education_hub_get_default_theme_options()
        );
    }
endif;

if ( ! function_exists( 'education_hub_get_default_theme_options' ) ) :
    /**
     * Get default theme options.
     */
    function education_hub_get_default_theme_options() {
        $default_options = array(
            'logo_position'          => 'left',
            'show_search'           => true,
            'breadcrumb_type'       => 'simple',
            'sidebar_position'      => 'right',
            'excerpt_length'        => 40,
            'read_more_text'        => __( 'Read More', 'education-hub' ),
            'footer_copyright_text' => sprintf( __( 'Copyright &copy; %1$s %2$s. All Rights Reserved.', 'education-hub' ), date( 'Y' ), get_bloginfo( 'name' ) ),
        );
        return apply_filters( 'education_hub_default_theme_options', $default_options );
    }
endif;

if ( ! function_exists( 'education_hub_get_page_layout' ) ) :
    /**
     * Get page layout.
     */
    function education_hub_get_page_layout() {
        global $post;
        $layout = 'right-sidebar';
        
        if ( is_singular() ) {
            $page_layout = get_post_meta( $post->ID, 'education_hub_page_layout', true );
            if ( ! empty( $page_layout ) ) {
                $layout = $page_layout;
            }
        }
        
        return apply_filters( 'education_hub_page_layout', $layout );
    }
endif;
?>