<?php
/**
 * Custom helper functions for Education Hub Theme
 *
 * @package Education_Hub
 */

if ( ! function_exists( 'education_hub_custom_css' ) ) :
    /**
     * Output custom CSS from theme options.
     */
    function education_hub_custom_css() {
        $custom_css = education_hub_get_theme_option( 'custom_css' );
        if ( ! empty( $custom_css ) ) {
            echo '<style type="text/css">' . esc_html( $custom_css ) . '</style>';
        }
    }
endif;
add_action( 'wp_head', 'education_hub_custom_css' );

if ( ! function_exists( 'education_hub_entry_footer' ) ) :
    /**
     * Prints HTML with meta information for the categories, tags and comments.
     */
    function education_hub_entry_footer() {
        // Hide category and tag text for pages.
        if ( 'post' === get_post_type() ) {
            /* translators: used between list items, there is a space after the comma */
            $categories_list = get_the_category_list( esc_html__( ', ', 'education-hub' ) );
            if ( $categories_list ) {
                printf( '<span class="cat-links">' . esc_html__( 'Posted in %1$s', 'education-hub' ) . '</span>', $categories_list );
            }

            /* translators: used between list items, there is a space after the comma */
            $tags_list = get_the_tag_list( '', esc_html__( ', ', 'education-hub' ) );
            if ( $tags_list ) {
                printf( '<span class="tags-links">' . esc_html__( 'Tagged %1$s', 'education-hub' ) . '</span>', $tags_list );
            }
        }

        if ( ! is_single() && ! post_password_required() && ( comments_open() || get_comments_number() ) ) {
            echo '<span class="comments-link">';
            comments_popup_link(
                esc_html__( 'Leave a comment', 'education-hub' ),
                esc_html__( '1 Comment', 'education-hub' ),
                esc_html__( '% Comments', 'education-hub' )
            );
            echo '</span>';
        }

        edit_post_link(
            sprintf(
                esc_html__( 'Edit %s', 'education-hub' ),
                the_title( '<span class="screen-reader-text">"', '"</span>', false )
            ),
            '<span class="edit-link">',
            '</span>'
        );
    }
endif;
?>