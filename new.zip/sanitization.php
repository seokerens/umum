<?php
/**
 * Sanitization functions for theme options
 *
 * @package Education_Hub
 */

if ( ! function_exists( 'education_hub_sanitize_select' ) ) :
    /**
     * Sanitize select.
     */
    function education_hub_sanitize_select( $input, $setting ) {
        $input = sanitize_key( $input );
        $choices = $setting->manager->get_control( $setting->id )->choices;
        return ( array_key_exists( $input, $choices ) ? $input : $setting->default );
    }
endif;

if ( ! function_exists( 'education_hub_sanitize_checkbox' ) ) :
    /**
     * Sanitize checkbox.
     */
    function education_hub_sanitize_checkbox( $checked ) {
        return ( ( isset( $checked ) && true == $checked ) ? true : false );
    }
endif;

if ( ! function_exists( 'education_hub_sanitize_number_range' ) ) :
    /**
     * Sanitize number range.
     */
    function education_hub_sanitize_number_range( $input, $setting ) {
        $input = absint( $input );
        $atts = $setting->manager->get_control( $setting->id )->input_attrs;
        $min = ( isset( $atts['min'] ) ? $atts['min'] : $input );
        $max = ( isset( $atts['max'] ) ? $atts['max'] : $input );
        $step = ( isset( $atts['step'] ) ? $atts['step'] : 1 );
        return ( $min <= $input && $input <= $max && is_int( $input / $step ) ? $input : $setting->default );
    }
endif;

if ( ! function_exists( 'education_hub_sanitize_textarea' ) ) :
    /**
     * Sanitize textarea.
     */
    function education_hub_sanitize_textarea( $input ) {
        return wp_kses_post( $input );
    }
endif;
?>